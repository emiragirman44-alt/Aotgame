# Implemented AOT-inspired game updates

- Titan transformation is now locked until a Titan power is earned from a completed raid.
- Raid difficulty scales with player level: EASY/NORMAL/HARD/EXTREME/NIGHTMARE.
- Raid rewards now grant bonus gold and XP and roll for a rare Titan power.
- Titan power rarity tiers: COMMON, RARE, EPIC, LEGENDARY, MYTHIC.
- Raid pity counter increases after unsuccessful reward rolls and guarantees a reward at 10.
- Titan power and raid pity persist in localStorage.
- HUD shows Titan power status and raid pity.
- Mobile Kes and Dev'e Dönüşme buttons have swapped positions.
- Existing ODM, quests, Titan AI, special Titans, horses, shop, multiplayer/P2P, day/night and save systems remain in place.

Build note: dependency installation/typecheck could not be completed in the sandbox because the workspace did not have node_modules and npm dependency installation timed out.
