import { i as WORLD_SIZE, n as TEAMS, r as WALLS } from "./routes-C-jHN7lU.mjs";
import { A as RepeatWrapping, C as MeshStandardMaterial, D as PointLight, E as PlaneGeometry, F as Vector2, I as Vector3, M as SRGBColorSpace, N as Scene, O as Quaternion, P as SphereGeometry, S as MeshBasicMaterial, T as PerspectiveCamera, _ as Line, a as CanvasTexture, b as Matrix4, c as ConeGeometry, d as DynamicDrawUsage, f as Euler, g as InstancedMesh, h as HemisphereLight, i as BufferGeometry, j as RingGeometry, k as Raycaster, l as CylinderGeometry, m as Group, n as AmbientLight, o as CircleGeometry, p as Fog, r as BoxGeometry, s as Color, t as WebGLRenderer, u as DirectionalLight, v as LineBasicMaterial, w as NearestFilter, x as Mesh, y as MathUtils } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-C7DcX2UP.js
var GAME_CODES = /* @__PURE__ */ new Set([
	"KeyW",
	"KeyA",
	"KeyS",
	"KeyD",
	"ArrowUp",
	"ArrowDown",
	"ArrowLeft",
	"ArrowRight",
	"ShiftLeft",
	"ShiftRight",
	"KeyQ",
	"KeyF",
	"KeyE",
	"KeyH",
	"KeyR",
	"KeyX",
	"KeyG",
	"Space",
	"KeyP"
]);
var Input = class {
	keys = /* @__PURE__ */ new Set();
	injected = /* @__PURE__ */ new Set();
	queued = /* @__PURE__ */ new Set();
	joyX = 0;
	joyY = 0;
	joyActive = false;
	sprintToggle = false;
	lookDx = 0;
	lookDy = 0;
	pointerLocked = false;
	unbind = [];
	attach(target) {
		const onDown = (e) => {
			if (GAME_CODES.has(e.code)) e.preventDefault();
			if (e.repeat) return;
			this.keys.add(e.code);
			if (e.code === "KeyQ") this.queued.add("hook");
			if (e.code === "KeyF") this.queued.add("attack");
			if (e.code === "KeyE" || e.code === "Space") this.queued.add("transform");
			if (e.code === "KeyH") this.queued.add("heal");
			if (e.code === "KeyR") this.queued.add("roar");
			if (e.code === "KeyX") this.queued.add("harden");
			if (e.code === "KeyG") this.queued.add("mount");
		};
		const onUp = (e) => {
			this.keys.delete(e.code);
		};
		const clear = () => this.keys.clear();
		const onMouse = (e) => {
			if (!this.pointerLocked) return;
			this.lookDx += e.movementX;
			this.lookDy += e.movementY;
		};
		const onLockChange = () => {
			this.pointerLocked = document.pointerLockElement === target;
		};
		window.addEventListener("keydown", onDown);
		window.addEventListener("keyup", onUp);
		window.addEventListener("blur", clear);
		document.addEventListener("visibilitychange", () => {
			if (document.hidden) clear();
		});
		document.addEventListener("mousemove", onMouse);
		document.addEventListener("pointerlockchange", onLockChange);
		this.unbind.push(() => {
			window.removeEventListener("keydown", onDown);
			window.removeEventListener("keyup", onUp);
			window.removeEventListener("blur", clear);
			document.removeEventListener("mousemove", onMouse);
			document.removeEventListener("pointerlockchange", onLockChange);
		});
	}
	pulse(action) {
		this.queued.add(action);
	}
	consumeLook() {
		const x = this.lookDx;
		const y = this.lookDy;
		this.lookDx = 0;
		this.lookDy = 0;
		return {
			x,
			y
		};
	}
	consumeActions() {
		const q = this.queued;
		this.queued = /* @__PURE__ */ new Set();
		return q;
	}
	sampleMove() {
		const codes = this.codes();
		let x = 0;
		let y = 0;
		if (codes.has("KeyA") || codes.has("ArrowLeft")) x -= 1;
		if (codes.has("KeyD") || codes.has("ArrowRight")) x += 1;
		if (codes.has("KeyW") || codes.has("ArrowUp")) y += 1;
		if (codes.has("KeyS") || codes.has("ArrowDown")) y -= 1;
		if (this.joyActive) {
			x = this.joyX;
			y = this.joyY;
		}
		const mag = Math.hypot(x, y);
		if (mag > 1) {
			x /= mag;
			y /= mag;
		}
		const sprint = this.sprintToggle || codes.has("ShiftLeft") || codes.has("ShiftRight");
		return {
			x,
			y,
			sprint
		};
	}
	codes() {
		if (this.injected.size === 0) return this.keys;
		const s = new Set(this.keys);
		this.injected.forEach((c) => s.add(c));
		return s;
	}
	setKeys(codes) {
		this.injected = new Set(codes);
	}
	dispose() {
		this.unbind.forEach((fn) => fn());
		this.unbind = [];
	}
};
var GameAudio = class {
	ctx = null;
	master = null;
	sfx = null;
	roarBuf = null;
	loading = false;
	visBound = false;
	unlock() {
		if (!this.ctx) {
			this.ctx = new AudioContext({ latencyHint: "interactive" });
			this.master = this.ctx.createGain();
			this.master.gain.value = .85;
			this.master.connect(this.ctx.destination);
			this.sfx = this.ctx.createGain();
			this.sfx.gain.value = .9;
			this.sfx.connect(this.master);
			this.loadRoar();
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
		if (!this.visBound) {
			this.visBound = true;
			document.addEventListener("visibilitychange", () => {
				if (!document.hidden && this.ctx?.state === "suspended") this.ctx.resume();
			});
		}
	}
	async loadRoar() {
		if (this.loading || this.roarBuf || !this.ctx) return;
		this.loading = true;
		for (const url of ["/sfx/titan-roar.ogg", "/sfx/titan-roar.mp3"]) try {
			const res = await fetch(url);
			if (!res.ok) continue;
			const arr = await res.arrayBuffer();
			this.roarBuf = await this.ctx.decodeAudioData(arr.slice(0));
			return;
		} catch {}
	}
	envGain(duration, peak = .4) {
		if (!this.ctx || !this.sfx) return null;
		const g = this.ctx.createGain();
		const now = this.ctx.currentTime;
		g.gain.setValueAtTime(1e-4, now);
		g.gain.exponentialRampToValueAtTime(peak, now + .02);
		g.gain.exponentialRampToValueAtTime(.01, now + duration);
		g.connect(this.sfx);
		return g;
	}
	roar() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx || !this.sfx) return;
		const now = ctx.currentTime;
		if (this.roarBuf) {
			const src = ctx.createBufferSource();
			src.buffer = this.roarBuf;
			src.playbackRate.value = .92 + Math.random() * .1;
			const g = ctx.createGain();
			g.gain.setValueAtTime(1e-4, now);
			g.gain.exponentialRampToValueAtTime(.52, now + .04);
			g.gain.exponentialRampToValueAtTime(.01, now + Math.min(6.2, this.roarBuf.duration));
			src.connect(g);
			g.connect(this.sfx);
			src.start(now);
			return;
		}
		const osc = ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(48, now);
		osc.frequency.exponentialRampToValueAtTime(210, now + .5);
		osc.frequency.exponentialRampToValueAtTime(36, now + 3.4);
		const f = ctx.createBiquadFilter();
		f.type = "lowpass";
		f.frequency.setValueAtTime(1200, now);
		const g = this.envGain(3.4, .55);
		if (!g) return;
		osc.connect(f);
		f.connect(g);
		osc.start(now);
		osc.stop(now + 3.4);
	}
	slash() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		osc.type = "square";
		osc.frequency.setValueAtTime(880, now);
		osc.frequency.exponentialRampToValueAtTime(140, now + .18);
		const g = this.envGain(.2, .18);
		if (!g) return;
		osc.connect(g);
		osc.start(now);
		osc.stop(now + .2);
	}
	drySlash() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		osc.type = "triangle";
		osc.frequency.setValueAtTime(220, now);
		osc.frequency.exponentialRampToValueAtTime(90, now + .12);
		const g = this.envGain(.12, .12);
		if (!g) return;
		osc.connect(g);
		osc.start(now);
		osc.stop(now + .12);
	}
	gas() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const noise = ctx.createBuffer(1, ctx.sampleRate * .25, ctx.sampleRate);
		const data = noise.getChannelData(0);
		for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
		const src = ctx.createBufferSource();
		src.buffer = noise;
		const f = ctx.createBiquadFilter();
		f.type = "highpass";
		f.frequency.value = 1400;
		const g = this.envGain(.22, .2);
		if (!g) return;
		src.connect(f);
		f.connect(g);
		src.start(now);
		src.stop(now + .25);
	}
	thunder() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(90, now);
		osc.frequency.exponentialRampToValueAtTime(28, now + .8);
		const g = this.envGain(.85, .5);
		if (!g) return;
		osc.connect(g);
		osc.start(now);
		osc.stop(now + .85);
	}
	horn() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		osc.type = "sawtooth";
		osc.frequency.setValueAtTime(180, now);
		osc.frequency.setValueAtTime(140, now + .35);
		const g = this.envGain(1.1, .28);
		if (!g) return;
		osc.connect(g);
		osc.start(now);
		osc.stop(now + 1.1);
	}
	coin() {
		this.unlock();
		const ctx = this.ctx;
		if (!ctx) return;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		osc.type = "sine";
		osc.frequency.setValueAtTime(880, now);
		osc.frequency.exponentialRampToValueAtTime(1320, now + .08);
		const g = this.envGain(.18, .12);
		if (!g) return;
		osc.connect(g);
		osc.start(now);
		osc.stop(now + .18);
	}
};
function canvas(size) {
	const c = document.createElement("canvas");
	c.width = size;
	c.height = size;
	const ctx = c.getContext("2d");
	if (!ctx) throw new Error("2d context");
	return {
		c,
		ctx
	};
}
function tex(c, repeatX = 1, repeatY = 1, nearest = false) {
	const t = new CanvasTexture(c);
	t.wrapS = RepeatWrapping;
	t.wrapT = RepeatWrapping;
	t.repeat.set(repeatX, repeatY);
	t.anisotropy = 8;
	t.colorSpace = SRGBColorSpace;
	if (nearest) {
		t.magFilter = NearestFilter;
		t.minFilter = NearestFilter;
	} else t.needsUpdate = true;
	t.needsUpdate = true;
	return t;
}
function speckle(ctx, size, count, color, radius) {
	ctx.fillStyle = color;
	for (let i = 0; i < count; i++) {
		ctx.beginPath();
		ctx.arc(Math.random() * size, Math.random() * size, Math.random() * radius, 0, Math.PI * 2);
		ctx.fill();
	}
}
function createTextures() {
	const all = [];
	const push = (t) => {
		all.push(t);
		return t;
	};
	{
		const { c, ctx } = canvas(1024);
		ctx.fillStyle = "#3d5c28";
		ctx.fillRect(0, 0, 1024, 1024);
		for (let i = 0; i < 2400; i++) {
			const g = 70 + Math.random() * 70;
			ctx.fillStyle = `rgb(${40 + Math.random() * 30},${g},${28 + Math.random() * 24})`;
			ctx.beginPath();
			ctx.ellipse(Math.random() * 1024, Math.random() * 1024, 6 + Math.random() * 18, 3 + Math.random() * 8, Math.random() * Math.PI, 0, Math.PI * 2);
			ctx.fill();
		}
		speckle(ctx, 1024, 600, "rgba(20,40,10,0.25)", 4);
		var grass = push(tex(c, 70, 70));
	}
	{
		const { c, ctx } = canvas(512);
		ctx.fillStyle = "#5a4632";
		ctx.fillRect(0, 0, 512, 512);
		speckle(ctx, 512, 900, "#6b533c", 7);
		speckle(ctx, 512, 500, "#4a3828", 5);
		var dirt = push(tex(c, 8, 8));
	}
	{
		const { c, ctx } = canvas(512);
		ctx.fillStyle = "#6a5646";
		ctx.fillRect(0, 0, 512, 512);
		const bh = 28;
		const bw = 56;
		for (let y = 0; y < 512; y += bh) {
			const off = y / bh % 2 === 0 ? 0 : bw / 2;
			for (let x = -56; x < 512; x += bw) {
				const shade = 90 + Math.random() * 35;
				ctx.fillStyle = `rgb(${shade + 20},${shade - 10},${shade - 28})`;
				ctx.fillRect(x + off + 2, y + 2, 52, 24);
			}
		}
		var brick = push(tex(c, 2, 2));
	}
	{
		const { c, ctx } = canvas(1024);
		ctx.fillStyle = "#7a7468";
		ctx.fillRect(0, 0, 1024, 1024);
		const bh = 48;
		const bw = 96;
		for (let y = 0; y < 1024; y += bh) {
			const off = y / bh % 2 === 0 ? 0 : bw / 2;
			for (let x = -96; x < 1024; x += bw) {
				const n = 118 + Math.random() * 28;
				ctx.fillStyle = `rgb(${n},${n - 6},${n - 16})`;
				ctx.fillRect(x + off + 3, y + 3, 90, 42);
				ctx.strokeStyle = "rgba(40,38,32,0.35)";
				ctx.strokeRect(x + off + 3, y + 3, 90, 42);
			}
		}
		speckle(ctx, 1024, 1200, "rgba(30,28,24,0.18)", 3);
		var stone = push(tex(c, 8, 2));
	}
	{
		const { c, ctx } = canvas(256);
		ctx.fillStyle = "#5a3a22";
		ctx.fillRect(0, 0, 256, 256);
		for (let x = 0; x < 256; x += 8) {
			ctx.fillStyle = Math.random() > .5 ? "#6b4528" : "#4a3018";
			ctx.fillRect(x, 0, 6, 256);
		}
		var wood = push(tex(c, 1, 1, true));
	}
	{
		const { c, ctx } = canvas(256);
		ctx.fillStyle = "#2f5a24";
		ctx.fillRect(0, 0, 256, 256);
		speckle(ctx, 256, 400, "#3d7a30", 10);
		speckle(ctx, 256, 200, "#1e3d16", 8);
		var leaves = push(tex(c, 1, 1, true));
	}
	{
		const { c, ctx } = canvas(256);
		ctx.fillStyle = "#7a2e24";
		ctx.fillRect(0, 0, 256, 256);
		for (let y = 0; y < 256; y += 10) {
			ctx.fillStyle = y % 20 === 0 ? "#8a3a2c" : "#6a241c";
			ctx.fillRect(0, y, 256, 8);
		}
		var roof = push(tex(c, 1, 1));
	}
	{
		const { c, ctx } = canvas(512);
		ctx.fillStyle = "#8a3426";
		ctx.fillRect(0, 0, 512, 512);
		ctx.strokeStyle = "#5c1e14";
		ctx.lineWidth = 2;
		for (let i = 0; i < 512; i += 7) {
			ctx.beginPath();
			ctx.moveTo(0, i);
			ctx.bezierCurveTo(160, i + Math.random() * 16, 320, i - Math.random() * 16, 512, i + Math.random() * 10);
			ctx.stroke();
		}
		speckle(ctx, 512, 200, "rgba(40,10,8,0.25)", 4);
		var muscle = push(tex(c, 2, 2));
	}
	{
		const { c, ctx } = canvas(512);
		ctx.fillStyle = "#6a655c";
		ctx.fillRect(0, 0, 512, 512);
		for (let y = 0; y < 512; y += 22) for (let x = 0; x < 512; x += 22) {
			const n = 90 + Math.random() * 40;
			ctx.fillStyle = `rgb(${n},${n - 4},${n - 12})`;
			ctx.fillRect(x + 1, y + 1, 20, 20);
		}
		var cobble = push(tex(c, 6, 6));
	}
	{
		const { c, ctx } = canvas(128);
		ctx.clearRect(0, 0, 128, 128);
		for (let i = 0; i < 7; i++) {
			const x = 64 + (i - 3) * 10;
			ctx.strokeStyle = `rgba(${40 + i * 6},${110 + i * 8},40,0.92)`;
			ctx.lineWidth = 4;
			ctx.beginPath();
			ctx.moveTo(x, 124);
			ctx.quadraticCurveTo(x + (i - 3) * 8, 60, x + (i - 3) * 4, 8);
			ctx.stroke();
		}
		var bladeGrass = push(tex(c, 1, 1));
	}
	{
		const { c, ctx } = canvas(256);
		ctx.fillStyle = "#3d4a34";
		ctx.fillRect(0, 0, 256, 256);
		ctx.strokeStyle = "#e8e2d0";
		ctx.fillStyle = "#e8e2d0";
		ctx.lineWidth = 6;
		ctx.beginPath();
		ctx.moveTo(128, 70);
		ctx.lineTo(70, 190);
		ctx.lineTo(128, 150);
		ctx.lineTo(186, 190);
		ctx.closePath();
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(128, 48);
		ctx.quadraticCurveTo(40, 110, 48, 200);
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(128, 48);
		ctx.quadraticCurveTo(216, 110, 208, 200);
		ctx.stroke();
		var cloak = push(tex(c, 1, 1));
	}
	{
		const { c, ctx } = canvas(512);
		const g = ctx.createLinearGradient(0, 0, 0, 512);
		g.addColorStop(0, "#8fb4cc");
		g.addColorStop(.45, "#a9c3d4");
		g.addColorStop(.72, "#c5c2a8");
		g.addColorStop(1, "#d7c9a4");
		ctx.fillStyle = g;
		ctx.fillRect(0, 0, 512, 512);
		var sky = push(tex(c, 1, 1));
	}
	return {
		grass,
		dirt,
		brick,
		stone,
		wood,
		leaves,
		roof,
		muscle,
		cobble,
		bladeGrass,
		cloak,
		sky,
		all
	};
}
function disposeTextures(t) {
	t.all.forEach((x) => x.dispose());
}
function add(parent, geo, mat, x, y, z, opts = {}) {
	const m = new Mesh(geo, mat);
	m.position.set(x, y, z);
	if (opts.sx || opts.sy || opts.sz) m.scale.set(opts.sx ?? 1, opts.sy ?? 1, opts.sz ?? 1);
	if (opts.rx) m.rotation.x = opts.rx;
	if (opts.ry) m.rotation.y = opts.ry;
	if (opts.rz) m.rotation.z = opts.rz;
	m.castShadow = opts.cast !== false;
	m.receiveShadow = true;
	if (opts.name) m.name = opts.name;
	parent.add(m);
	return m;
}
function createAttackTitan(textures) {
	const group = new Group();
	const skin = new MeshStandardMaterial({
		color: 12868163,
		roughness: .46,
		map: textures.muscle
	});
	const muscle = new MeshStandardMaterial({
		color: 9057318,
		roughness: .38,
		map: textures.muscle
	});
	const dark = new MeshStandardMaterial({
		color: 7218200,
		roughness: .5
	});
	const hair = new MeshStandardMaterial({
		color: 657930,
		roughness: .92
	});
	const teeth = new MeshStandardMaterial({
		color: 15920870,
		roughness: .28
	});
	const eye = new MeshBasicMaterial({ color: 4063168 });
	const nail = new MeshStandardMaterial({
		color: 14206128,
		roughness: .4
	});
	const napeMat = new MeshStandardMaterial({
		color: 8000532,
		roughness: .6,
		emissive: 3802373,
		emissiveIntensity: .4
	});
	const skinMats = [
		skin,
		muscle,
		dark
	];
	const sph = (r, seg = 10) => new SphereGeometry(r, seg, seg);
	const cyl = (t, b, h, seg = 10) => new CylinderGeometry(t, b, h, seg);
	const box = (x, y, z) => new BoxGeometry(x, y, z);
	const leftLeg = new Group();
	leftLeg.position.set(-1.15, 6.15, 0);
	group.add(leftLeg);
	const rightLeg = new Group();
	rightLeg.position.set(1.15, 6.15, 0);
	group.add(rightLeg);
	add(leftLeg, cyl(1.05, .78, 3.15, 12), muscle, 0, -1.55, .08);
	add(leftLeg, sph(.7, 10), skin, 0, -3.2, .05);
	add(leftLeg, cyl(.62, .48, 2.55, 10), skin, 0, -4.55, .02);
	add(leftLeg, sph(.55, 8), muscle, -.08, -4.35, -.22);
	add(leftLeg, sph(.55, 8), muscle, .08, -4.35, -.22);
	add(leftLeg, box(1.15, .38, 2.15), skin, 0, -5.95, .42);
	add(leftLeg, box(.18, .1, .28), nail, -.35, -5.82, 1.42);
	add(leftLeg, box(.18, .1, .28), nail, 0, -5.82, 1.48);
	add(leftLeg, box(.18, .1, .28), nail, .35, -5.82, 1.42);
	add(rightLeg, cyl(1.05, .78, 3.15, 12), muscle, 0, -1.55, .08);
	add(rightLeg, sph(.7, 10), skin, 0, -3.2, .05);
	add(rightLeg, cyl(.62, .48, 2.55, 10), skin, 0, -4.55, .02);
	add(rightLeg, sph(.55, 8), muscle, -.08, -4.35, -.22);
	add(rightLeg, sph(.55, 8), muscle, .08, -4.35, -.22);
	add(rightLeg, box(1.15, .38, 2.15), skin, 0, -5.95, .42);
	add(rightLeg, box(.18, .1, .28), nail, -.35, -5.82, 1.42);
	add(rightLeg, box(.18, .1, .28), nail, 0, -5.82, 1.48);
	add(rightLeg, box(.18, .1, .28), nail, .35, -5.82, 1.42);
	add(group, sph(1.35, 12), muscle, 0, 6.2, 0, {
		sx: 1.55,
		sy: .95,
		sz: 1.15
	});
	add(group, sph(.85, 10), muscle, -.7, 5.85, -.55);
	add(group, sph(.85, 10), muscle, .7, 5.85, -.55);
	const torso = new Group();
	torso.position.set(0, 6.4, 0);
	torso.rotation.x = .06;
	group.add(torso);
	add(torso, cyl(2.05, 1.55, 2.2, 12), skin, 0, 1.4, 0);
	add(torso, cyl(2.7, 2.05, 3.6, 12), skin, 0, 3.9, .05);
	add(torso, sph(1.15, 12), muscle, -.95, 4.85, 1.05, {
		sx: 1.15,
		sy: .75,
		sz: .7
	});
	add(torso, sph(1.15, 12), muscle, .95, 4.85, 1.05, {
		sx: 1.15,
		sy: .75,
		sz: .7
	});
	add(torso, box(2.4, .18, .35), dark, 0, 5.55, .9);
	add(torso, box(.22, 1.6, .22), dark, 0, 3.6, 1.15);
	for (let row = 0; row < 3; row++) {
		add(torso, box(1.05, .62, .7), muscle, -.62, 2.7 - row * .78, 1.12);
		add(torso, box(1.05, .62, .7), muscle, .62, 2.7 - row * .78, 1.12);
	}
	add(torso, box(.7, 1.8, .9), muscle, -1.7, 2.6, .55, { rz: .35 });
	add(torso, box(.7, 1.8, .9), muscle, 1.7, 2.6, .55, { rz: -.35 });
	for (let i = 0; i < 4; i++) {
		add(torso, box(.55, .18, .7), dark, -2.05, 3.5 - i * .28, .7, { rz: .4 });
		add(torso, box(.55, .18, .7), dark, 2.05, 3.5 - i * .28, .7, { rz: -.4 });
	}
	add(torso, sph(1.2, 10), muscle, -1.6, 4.4, -.55, {
		sx: .9,
		sy: 1.1,
		sz: .7
	});
	add(torso, sph(1.2, 10), muscle, 1.6, 4.4, -.55, {
		sx: .9,
		sy: 1.1,
		sz: .7
	});
	add(torso, sph(.85, 8), muscle, -.55, 5.7, -.7);
	add(torso, sph(.85, 8), muscle, .55, 5.7, -.7);
	add(torso, box(.35, 2.4, .3), dark, 0, 3.6, -1.15);
	add(torso, cyl(.72, .9, 1.15, 10), skin, 0, 6.35, .15);
	const nape = add(torso, box(.9, .85, .38), napeMat, 0, 6.55, -.85, { name: "nape" });
	const head = new Group();
	head.position.set(0, 13.35, .2);
	group.add(head);
	add(head, sph(1.15, 16), skin, 0, .15, 0, {
		sx: 1.05,
		sy: 1.28,
		sz: 1.12
	});
	add(head, box(1.7, .38, .7), dark, 0, .42, .72);
	add(head, box(.32, .4, .5), skin, 0, -.05, 1.15);
	add(head, box(1.55, .55, 1.15), teeth, 0, -.72, .45);
	for (let i = 0; i < 8; i++) add(head, box(.12, .32, .1), teeth, -.7 + i * .2, -.52, 1);
	add(head, new ConeGeometry(.28, 1.15, 5), skin, -1.15, .15, -.1, { rz: Math.PI / 2.6 });
	add(head, new ConeGeometry(.28, 1.15, 5), skin, 1.15, .15, -.1, { rz: -Math.PI / 2.6 });
	add(head, sph(.2, 8), eye, -.38, .22, 1.05);
	add(head, sph(.2, 8), eye, .38, .22, 1.05);
	add(head, sph(.07, 6), new MeshBasicMaterial({ color: 397838 }), -.38, .22, 1.2);
	add(head, sph(.07, 6), new MeshBasicMaterial({ color: 397838 }), .38, .22, 1.2);
	for (let i = 0; i < 11; i++) {
		const spike = add(head, new ConeGeometry(.55, 2.8, 5), hair, (i - 5) * .28, 1.15, -.35);
		spike.rotation.x = -.55 - Math.abs(i - 5) * .04;
	}
	add(head, new ConeGeometry(.4, 2.2, 5), hair, -.9, .5, -.2, {
		rz: .5,
		rx: -.3
	});
	add(head, new ConeGeometry(.4, 2.2, 5), hair, .9, .5, -.2, {
		rz: -.5,
		rx: -.3
	});
	const leftArm = new Group();
	leftArm.position.set(-3.35, 11.15, 0);
	group.add(leftArm);
	const rightArm = new Group();
	rightArm.position.set(3.35, 11.15, 0);
	group.add(rightArm);
	const buildArm = (arm, side) => {
		add(arm, sph(1.35, 12), muscle, 0, 0, 0);
		add(arm, sph(.7, 8), muscle, side * .15, .45, -.35);
		add(arm, cyl(.85, .62, 3.4, 10), skin, side * .15, -1.85, 0);
		add(arm, sph(.7, 8), muscle, side * .05, -1.35, .45);
		add(arm, sph(.55, 8), muscle, side * .05, -1.55, -.4);
		add(arm, sph(.48, 8), skin, 0, -3.55, 0);
		add(arm, cyl(.55, .42, 3.1, 10), skin, 0, -5.05, .05);
		add(arm, sph(.42, 8), muscle, 0, -4.55, .28);
		add(arm, box(.7, .45, 1.05), skin, 0, -6.7, .15);
		for (let f = 0; f < 4; f++) {
			add(arm, box(.14, .14, .55), skin, -.28 + f * .18, -6.7, .7);
			add(arm, box(.12, .08, .16), nail, -.28 + f * .18, -6.7, 1);
		}
	};
	buildArm(leftArm, -1);
	buildArm(rightArm, 1);
	return {
		group,
		limbs: {
			leftLeg,
			rightLeg,
			leftArm,
			rightArm
		},
		skinMats,
		nape
	};
}
function createScout(textures, cloakHex = 4017974) {
	const group = new Group();
	const skin = new MeshStandardMaterial({
		color: 15123104,
		roughness: .55
	});
	const coat = new MeshStandardMaterial({
		color: cloakHex,
		roughness: .7
	});
	const pants = new MeshStandardMaterial({
		color: 14210248,
		roughness: .65
	});
	const leather = new MeshStandardMaterial({
		color: 3810328,
		roughness: .6
	});
	const steel = new MeshStandardMaterial({
		color: 12109004,
		metalness: .85,
		roughness: .25
	});
	const blade = new MeshStandardMaterial({
		color: 15265522,
		metalness: .95,
		roughness: .12
	});
	const hair = new MeshStandardMaterial({
		color: 1708558,
		roughness: .9
	});
	const cloakMat = new MeshStandardMaterial({
		map: textures.cloak,
		color: cloakHex,
		roughness: .75,
		side: 2
	});
	const leftLeg = new Group();
	leftLeg.position.set(-.2, .95, 0);
	group.add(leftLeg);
	const rightLeg = new Group();
	rightLeg.position.set(.2, .95, 0);
	group.add(rightLeg);
	add(leftLeg, new CylinderGeometry(.13, .11, .95, 8), pants, 0, -.48, 0);
	add(leftLeg, new BoxGeometry(.22, .12, .4), leather, 0, -.95, .08);
	add(rightLeg, new CylinderGeometry(.13, .11, .95, 8), pants, 0, -.48, 0);
	add(rightLeg, new BoxGeometry(.22, .12, .4), leather, 0, -.95, .08);
	add(group, new CylinderGeometry(.32, .28, .85, 10), coat, 0, 1.4, 0);
	add(group, new SphereGeometry(.26, 12, 12), skin, 0, 2.05, 0);
	add(group, new SphereGeometry(.28, 8, 8), hair, 0, 2.18, -.04, {
		sy: .7,
		sz: .85
	});
	add(group, new PlaneGeometry(.9, 1.25), cloakMat, 0, 1.35, -.28);
	const leftArm = new Group();
	leftArm.position.set(-.42, 1.7, 0);
	group.add(leftArm);
	const rightArm = new Group();
	rightArm.position.set(.42, 1.7, 0);
	group.add(rightArm);
	add(leftArm, new CylinderGeometry(.1, .08, .7, 8), coat, 0, -.35, 0);
	add(rightArm, new CylinderGeometry(.1, .08, .7, 8), coat, 0, -.35, 0);
	const hipL = new Group();
	hipL.position.set(-.38, 1.05, .05);
	group.add(hipL);
	const hipR = new Group();
	hipR.position.set(.38, 1.05, .05);
	group.add(hipR);
	add(hipL, new CylinderGeometry(.12, .12, .42, 10), steel, 0, 0, 0, { rx: Math.PI / 2 });
	add(hipR, new CylinderGeometry(.12, .12, .42, 10), steel, 0, 0, 0, { rx: Math.PI / 2 });
	add(hipL, new BoxGeometry(.05, .08, .95), blade, 0, .15, .35);
	add(hipR, new BoxGeometry(.05, .08, .95), blade, 0, .15, .35);
	add(group, new BoxGeometry(.55, .18, .28), leather, 0, 1.08, .18);
	return {
		group,
		limbs: {
			leftLeg,
			rightLeg,
			leftArm,
			rightArm
		},
		hips: {
			left: hipL,
			right: hipR
		}
	};
}
function napeMat() {
	return new MeshStandardMaterial({
		color: 16720418,
		emissive: 6689041,
		emissiveIntensity: .65,
		roughness: .5
	});
}
function createPureTitan(kind = "normal") {
	const group = new Group();
	let s = .9 + Math.random() * .55;
	let speed = .75 + Math.random() * .45;
	let hp = 1;
	const skin = new MeshStandardMaterial({
		color: kind === "fast" ? 13666928 : kind === "plated" ? 11889234 : 13533030,
		roughness: .62
	});
	const face = new MeshStandardMaterial({
		color: 11887435,
		roughness: .55
	});
	const plate = new MeshStandardMaterial({
		color: 9075304,
		roughness: .35,
		metalness: .45
	});
	if (kind === "fast") {
		s = .7 + Math.random() * .2;
		speed = 1.85 + Math.random() * .4;
		hp = 1;
	} else if (kind === "plated") {
		s = 1.05 + Math.random() * .25;
		speed = .48;
		hp = 2;
	} else if (kind === "huge") {
		s = 1.7 + Math.random() * .45;
		speed = .38;
		hp = 2;
	}
	const leftLeg = new Group();
	leftLeg.position.set(-.65 * s, 3.4 * s, 0);
	leftLeg.name = "leftLeg";
	group.add(leftLeg);
	const rightLeg = new Group();
	rightLeg.position.set(.65 * s, 3.4 * s, 0);
	rightLeg.name = "rightLeg";
	group.add(rightLeg);
	add(leftLeg, new CylinderGeometry(.5 * s, .34 * s, 3.4 * s, 8), skin, 0, -1.7 * s, 0);
	add(rightLeg, new CylinderGeometry(.5 * s, .34 * s, 3.4 * s, 8), skin, 0, -1.7 * s, 0);
	add(leftLeg, new BoxGeometry(.7 * s, .22 * s, 1.1 * s), skin, 0, -3.4 * s, .2 * s);
	add(rightLeg, new BoxGeometry(.7 * s, .22 * s, 1.1 * s), skin, 0, -3.4 * s, .2 * s);
	add(group, new CylinderGeometry(1.25 * s, .85 * s, 5.2 * s, 10), skin, 0, 6 * s, 0);
	add(group, new SphereGeometry(1.35 * s, 12, 12), face, 0, 9.15 * s, 0, {
		sx: 1.1,
		sy: 1.25,
		sz: 1.05
	});
	const eye = new MeshBasicMaterial({ color: 16119280 });
	const pupil = new MeshBasicMaterial({ color: 1118481 });
	add(group, new SphereGeometry(.22 * s, 8, 8), eye, -.42 * s, 9.35 * s, 1.15 * s);
	add(group, new SphereGeometry(.22 * s, 8, 8), eye, .42 * s, 9.35 * s, 1.15 * s);
	add(group, new SphereGeometry(.1 * s, 6, 6), pupil, -.42 * s, 9.35 * s, 1.32 * s);
	add(group, new SphereGeometry(.1 * s, 6, 6), pupil, .42 * s, 9.35 * s, 1.32 * s);
	add(group, new BoxGeometry(1.4 * s, .28 * s, .7 * s), face, 0, 8.55 * s, .9 * s);
	const nape = add(group, new BoxGeometry(.85 * s, .85 * s, .35 * s), napeMat(), 0, 9.05 * s, -1.25 * s, {
		name: "nape",
		cast: false
	});
	const leftArm = new Group();
	leftArm.position.set(-1.7 * s, 7.6 * s, 0);
	leftArm.name = "leftArm";
	group.add(leftArm);
	const rightArm = new Group();
	rightArm.position.set(1.7 * s, 7.6 * s, 0);
	rightArm.name = "rightArm";
	group.add(rightArm);
	add(leftArm, new CylinderGeometry(.48 * s, .38 * s, 3.6 * s, 8), skin, 0, -1.7 * s, 0);
	add(rightArm, new CylinderGeometry(.48 * s, .38 * s, 3.6 * s, 8), skin, 0, -1.7 * s, 0);
	if (kind === "plated") {
		add(group, new BoxGeometry(2.4 * s, 2.2 * s, .35 * s), plate, 0, 7.2 * s, 1.15 * s);
		add(group, new BoxGeometry(1.6 * s, 1.4 * s, .3 * s), plate, 0, 9.1 * s, 1.2 * s);
		add(leftArm, new BoxGeometry(.7 * s, 1.6 * s, .28 * s), plate, 0, -1.2 * s, .35 * s);
		add(rightArm, new BoxGeometry(.7 * s, 1.6 * s, .28 * s), plate, 0, -1.2 * s, .35 * s);
	}
	if (kind === "fast") {
		leftArm.rotation.z = .35;
		rightArm.rotation.z = -.35;
	}
	if (kind === "huge") add(group, new SphereGeometry(1.7 * s, 10, 10), face, 0, 9.4 * s, .1 * s, { sy: 1.15 });
	return {
		group,
		nape,
		scale: s,
		stunned: 0,
		hasLeftArm: true,
		hasRightArm: true,
		hasLeftLeg: true,
		hasRightLeg: true,
		speed,
		kind,
		hp,
		maxHp: hp,
		throwCd: 0,
		walkT: Math.random() * 10,
		limbs: {
			leftLeg,
			rightLeg,
			leftArm,
			rightArm
		},
		special: false,
		raid: false
	};
}
function createSpecialTitan(kind) {
	const group = new Group();
	let s = 1.35;
	let speed = .7;
	let hp = 4;
	const skin = new MeshStandardMaterial({
		color: 12937810,
		roughness: .5
	});
	const dark = new MeshStandardMaterial({
		color: 8010280,
		roughness: .45
	});
	const plate = new MeshStandardMaterial({
		color: 6969928,
		metalness: .55,
		roughness: .32
	});
	const crystal = new MeshStandardMaterial({
		color: 10147048,
		metalness: .4,
		roughness: .18,
		transparent: true,
		opacity: .85
	});
	const fur = new MeshStandardMaterial({
		color: 4863012,
		roughness: .92
	});
	const hair = new MeshStandardMaterial({
		color: 14206058,
		roughness: .7
	});
	if (kind === "armored") {
		s = 1.55;
		speed = .62;
		hp = 5;
		add(group, new CylinderGeometry(2.1 * s, 1.5 * s, 6.4 * s, 10), skin, 0, 5.8 * s, 0);
		add(group, new BoxGeometry(3.6 * s, 3.8 * s, 2.6 * s), plate, 0, 6.4 * s, .15 * s);
		add(group, new BoxGeometry(2.4 * s, 2.2 * s, 2.2 * s), plate, 0, 10.2 * s, .2 * s);
		add(group, new SphereGeometry(1.2 * s, 10, 10), dark, 0, 11.6 * s, .15 * s);
		for (const x of [-1.4, 1.4]) add(group, new BoxGeometry(1.5 * s, 4.4 * s, 1.5 * s), plate, x * s, 3.2 * s, 0);
	} else if (kind === "female") {
		s = 1.25;
		speed = 1.55;
		hp = 4;
		add(group, new CylinderGeometry(1.15 * s, .72 * s, 6.2 * s, 10), skin, 0, 5.4 * s, 0);
		add(group, new SphereGeometry(1.05 * s, 12, 12), skin, 0, 9.1 * s, 0, { sy: 1.2 });
		add(group, new ConeGeometry(1.1 * s, 2.4 * s, 8), hair, 0, 10.3 * s, -.15 * s);
		add(group, new BoxGeometry(1.8 * s, 1.6 * s, .22 * s), crystal, 0, 6.4 * s, 1.05 * s);
	} else if (kind === "jaw") {
		s = .72;
		speed = 2.35;
		hp = 3;
		add(group, new CylinderGeometry(1.05 * s, .8 * s, 3.6 * s, 10), skin, 0, 3.6 * s, 0);
		add(group, new SphereGeometry(1.35 * s, 10, 10), dark, 0, 5.9 * s, .35 * s, {
			sx: 1.25,
			sy: .9,
			sz: 1.35
		});
		add(group, new BoxGeometry(2.2 * s, .7 * s, 1.8 * s), dark, 0, 5.35 * s, .9 * s);
		const teeth = new MeshStandardMaterial({
			color: 15920870,
			roughness: .3
		});
		for (let i = 0; i < 6; i++) add(group, new ConeGeometry(.12 * s, .55 * s, 4), teeth, (-.7 + i * .28) * s, 5.15 * s, 1.6 * s, { rx: Math.PI });
	} else {
		s = 1.7;
		speed = .42;
		hp = 4;
		add(group, new SphereGeometry(2.4 * s, 12, 10), fur, 0, 4.6 * s, 0, {
			sy: 1.15,
			sz: .9
		});
		add(group, new SphereGeometry(1.5 * s, 10, 10), fur, 0, 8.2 * s, .4 * s);
		add(group, new SphereGeometry(.35 * s, 8, 8), new MeshBasicMaterial({ color: 15654280 }), -.45 * s, 8.4 * s, 1.55 * s);
		add(group, new SphereGeometry(.35 * s, 8, 8), new MeshBasicMaterial({ color: 15654280 }), .45 * s, 8.4 * s, 1.55 * s);
	}
	const leftLeg = new Group();
	leftLeg.position.set(-.85 * s, 2.6 * s, 0);
	leftLeg.name = "leftLeg";
	group.add(leftLeg);
	const rightLeg = new Group();
	rightLeg.position.set(.85 * s, 2.6 * s, 0);
	rightLeg.name = "rightLeg";
	group.add(rightLeg);
	const legH = kind === "beast" ? 3.2 * s : 3.8 * s;
	add(leftLeg, new CylinderGeometry(.55 * s, .4 * s, legH, 8), kind === "beast" ? fur : skin, 0, -legH / 2, 0);
	add(rightLeg, new CylinderGeometry(.55 * s, .4 * s, legH, 8), kind === "beast" ? fur : skin, 0, -legH / 2, 0);
	const leftArm = new Group();
	leftArm.position.set(-(kind === "beast" ? 2.4 : 1.9) * s, (kind === "beast" ? 6.2 : 7.4) * s, 0);
	leftArm.name = "leftArm";
	group.add(leftArm);
	const rightArm = new Group();
	rightArm.position.set((kind === "beast" ? 2.4 : 1.9) * s, (kind === "beast" ? 6.2 : 7.4) * s, 0);
	rightArm.name = "rightArm";
	group.add(rightArm);
	const armH = kind === "beast" ? 5.2 * s : 3.8 * s;
	add(leftArm, new CylinderGeometry(.48 * s, .38 * s, armH, 8), kind === "beast" ? fur : skin, 0, -armH / 2, 0);
	add(rightArm, new CylinderGeometry(.48 * s, .38 * s, armH, 8), kind === "beast" ? fur : skin, 0, -armH / 2, 0);
	if (kind === "armored") {
		add(leftArm, new BoxGeometry(.9 * s, armH * .7, .4 * s), plate, 0, -armH * .3, .2 * s);
		add(rightArm, new BoxGeometry(.9 * s, armH * .7, .4 * s), plate, 0, -armH * .3, .2 * s);
	}
	const napeY = kind === "jaw" ? 5.8 * s : kind === "beast" ? 8.6 * s : 9.4 * s;
	return {
		group,
		nape: add(group, new BoxGeometry(.9 * s, .8 * s, .4 * s), napeMat(), 0, napeY, -1.35 * s, {
			name: "nape",
			cast: false
		}),
		scale: s,
		stunned: 0,
		hasLeftArm: true,
		hasRightArm: true,
		hasLeftLeg: true,
		hasRightLeg: true,
		speed,
		kind,
		hp,
		maxHp: hp,
		throwCd: kind === "beast" ? 1.5 : 0,
		walkT: 0,
		limbs: {
			leftLeg,
			rightLeg,
			leftArm,
			rightArm
		},
		special: true,
		raid: false
	};
}
function createHorse() {
	const group = new Group();
	const hide = new MeshStandardMaterial({
		color: 4863012,
		roughness: .8
	});
	const dark = new MeshStandardMaterial({
		color: 1708558,
		roughness: .7
	});
	const leather = new MeshStandardMaterial({
		color: 5913122,
		roughness: .6
	});
	add(group, new BoxGeometry(.55, .7, 1.35), hide, 0, .95, 0);
	add(group, new BoxGeometry(.32, .55, .4), hide, 0, 1.35, .72);
	add(group, new BoxGeometry(.28, .22, .38), hide, 0, 1.28, 1.05);
	add(group, new BoxGeometry(.08, .35, .08), dark, 0, 1.05, -.72);
	add(group, new BoxGeometry(.5, .12, .55), leather, 0, 1.32, -.05);
	for (const [x, z] of [
		[-.18, .45],
		[.18, .45],
		[-.18, -.45],
		[.18, -.45]
	]) add(group, new BoxGeometry(.12, .7, .12), dark, x, .35, z);
	return {
		group,
		occupied: false
	};
}
var SPECIAL_NAMES = {
	armored: "Zırhlı Titan",
	female: "Dişi Titan",
	jaw: "Çene Titanı",
	beast: "Canavar Titan",
	fast: "Anormal (hızlı)",
	plated: "Zırhlı saf",
	huge: "Dev saf",
	normal: "Saf Dev"
};
var _m = new Matrix4();
var _p = new Vector3();
var _q = new Quaternion();
var _s = new Vector3();
var _e = new Euler();
function setInst(mesh, i, x, y, z, sx, sy, sz, ry = 0) {
	_p.set(x, y, z);
	_e.set(0, ry, 0);
	_q.setFromEuler(_e);
	_s.set(sx, sy, sz);
	_m.compose(_p, _q, _s);
	mesh.setMatrixAt(i, _m);
}
function createWorld(scene, textures, quality) {
	const hookables = [];
	const signs = [];
	const supplies = [];
	const horseSpawns = [];
	const raidAnchors = [];
	const torches = [];
	scene.background = new Color(9417932);
	const fog = new Fog(11125716, 80, quality === "high" ? 560 : 400);
	scene.fog = fog;
	const hemi = new HemisphereLight(12966122, 4016680, .62);
	scene.add(hemi);
	const amb = new AmbientLight(16777215, .28);
	scene.add(amb);
	const sun = new DirectionalLight(16773584, 1.35);
	sun.position.set(160, 280, 90);
	sun.castShadow = true;
	sun.shadow.mapSize.set(quality === "high" ? 2048 : 1024, quality === "high" ? 2048 : 1024);
	sun.shadow.camera.near = 10;
	sun.shadow.camera.far = 520;
	const sh = 110;
	sun.shadow.camera.left = -110;
	sun.shadow.camera.right = sh;
	sun.shadow.camera.top = sh;
	sun.shadow.camera.bottom = -110;
	sun.shadow.bias = -25e-5;
	sun.shadow.normalBias = .035;
	scene.add(sun);
	scene.add(sun.target);
	const moon = new DirectionalLight(10204372, 0);
	moon.position.set(-80, 120, -40);
	scene.add(moon);
	const skyMat = new MeshBasicMaterial({
		map: textures.sky,
		side: 1
	});
	const sky = new Mesh(new SphereGeometry(700, 24, 16), skyMat);
	scene.add(sky);
	const ground = new Mesh(new PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 1, 1), new MeshStandardMaterial({
		map: textures.grass,
		roughness: .92
	}));
	ground.rotation.x = -Math.PI / 2;
	ground.receiveShadow = true;
	scene.add(ground);
	const cobbleMat = new MeshStandardMaterial({
		map: textures.cobble,
		roughness: .85
	});
	const plaza = (x, z, r) => {
		const m = new Mesh(new CircleGeometry(r, 32), cobbleMat);
		m.rotation.x = -Math.PI / 2;
		m.position.set(x, .04, z);
		m.receiveShadow = true;
		scene.add(m);
	};
	plaza(0, WALLS.maria - 55, 48);
	plaza(0, WALLS.rose - 48, 36);
	plaza(0, 0, 42);
	const stoneMat = new MeshStandardMaterial({
		map: textures.stone,
		roughness: .78,
		color: 13157044
	});
	const brickMat = new MeshStandardMaterial({
		map: textures.brick,
		roughness: .82
	});
	const roofMat = new MeshStandardMaterial({
		map: textures.roof,
		roughness: .7
	});
	const woodMat = new MeshStandardMaterial({
		map: textures.wood,
		roughness: .75
	});
	const leafMat = new MeshStandardMaterial({
		map: textures.leaves,
		roughness: .8
	});
	const crateMat = new MeshStandardMaterial({
		color: 6967864,
		roughness: .7,
		map: textures.wood
	});
	const wallHeight = 50;
	const wallThick = 12;
	const segGeo = new BoxGeometry(1, 1, 1);
	const crenGeo = new BoxGeometry(1, 1, 1);
	const wallSpecs = [
		{
			name: "SUR SINA",
			r: WALLS.sina,
			segs: 72,
			color: 13814976
		},
		{
			name: "SUR ROSE",
			r: WALLS.rose,
			segs: 96,
			color: 12893616
		},
		{
			name: "SUR MARIA",
			r: WALLS.maria,
			segs: 120,
			color: 12038307
		}
	];
	for (const spec of wallSpecs) {
		const gateWidth = .12;
		const usable = [];
		for (let i = 0; i < spec.segs; i++) {
			const a = i / spec.segs * Math.PI * 2;
			if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < gateWidth) continue;
			usable.push(i);
		}
		const wall = new InstancedMesh(segGeo, stoneMat, usable.length);
		wall.castShadow = true;
		wall.receiveShadow = true;
		wall.name = spec.name;
		const arc = Math.PI * 2 * spec.r / spec.segs;
		usable.forEach((i, idx) => {
			const a = i / spec.segs * Math.PI * 2;
			const x = Math.sin(a) * spec.r;
			const z = Math.cos(a) * spec.r;
			setInst(wall, idx, x, wallHeight / 2, z, wallThick, wallHeight, arc * 1.08, a);
		});
		wall.instanceMatrix.needsUpdate = true;
		scene.add(wall);
		hookables.push(wall);
		const cren = new InstancedMesh(crenGeo, stoneMat, usable.length);
		cren.castShadow = true;
		usable.forEach((i, idx) => {
			const a = i / spec.segs * Math.PI * 2;
			const x = Math.sin(a) * spec.r;
			const z = Math.cos(a) * spec.r;
			if (idx % 2 === 0) setInst(cren, idx, x, 52.2, z, wallThick * .9, 4.4, arc * .55, a);
			else setInst(cren, idx, x, 50.6, z, wallThick * .9, 1.2, arc * .55, a);
		});
		cren.instanceMatrix.needsUpdate = true;
		scene.add(cren);
		hookables.push(cren);
		for (const side of [-1, 1]) {
			const a = side * .13;
			const x = Math.sin(a) * spec.r;
			const z = Math.cos(a) * spec.r;
			const tower = new Mesh(new BoxGeometry(16, 62, 16), stoneMat);
			tower.position.set(x, 31, z);
			tower.castShadow = true;
			tower.receiveShadow = true;
			scene.add(tower);
			hookables.push(tower);
		}
		const sign = makeSign(spec.name);
		sign.position.set(0, 28, spec.r - 8);
		scene.add(sign);
		signs.push({
			name: spec.name,
			x: 0,
			z: spec.r
		});
	}
	const bMax = quality === "high" ? 180 : 100;
	const positions = [];
	const spawnZ = WALLS.maria - 55;
	const placeCluster = (cx, cz, n, spread, minR = 0, maxR = 9999) => {
		let tries = 0;
		while (positions.length < bMax && n > 0 && tries < n * 8) {
			tries++;
			const x = cx + (Math.random() - .5) * spread;
			const z = cz + (Math.random() - .5) * spread;
			const r = Math.hypot(x, z);
			if (r < minR || r > maxR) continue;
			if ([
				WALLS.sina,
				WALLS.rose,
				WALLS.maria
			].some((wr) => Math.abs(r - wr) < 18)) continue;
			if (Math.hypot(x, z) < 18) continue;
			if (Math.hypot(x, z - spawnZ) < 32) continue;
			if (Math.hypot(x, z - (WALLS.rose - 48)) < 24) continue;
			n--;
			positions.push({
				x,
				z,
				w: 8 + Math.random() * 8,
				h: 10 + Math.random() * 16,
				d: 8 + Math.random() * 8,
				ry: Math.random() * Math.PI
			});
		}
	};
	placeCluster(0, 0, 28, 90, 22, WALLS.sina - 22);
	placeCluster(0, WALLS.maria - 52, 34, 78, WALLS.maria - 95, WALLS.maria - 22);
	placeCluster(0, WALLS.rose - 48, 26, 64, WALLS.rose - 90, WALLS.rose - 22);
	placeCluster(0, 0, 22, 400, WALLS.sina + 22, WALLS.rose - 22);
	placeCluster(0, 0, 18, 520, WALLS.rose + 22, WALLS.maria - 22);
	const bodies = new InstancedMesh(new BoxGeometry(1, 1, 1), brickMat, positions.length);
	const roofs = new InstancedMesh(new BoxGeometry(1, 1, 1), roofMat, positions.length);
	bodies.castShadow = true;
	bodies.receiveShadow = true;
	roofs.castShadow = true;
	positions.forEach((b, i) => {
		setInst(bodies, i, b.x, b.h / 2, b.z, b.w, b.h, b.d, b.ry);
		setInst(roofs, i, b.x, b.h + 1.2, b.z, b.w * 1.12, 2.4, b.d * 1.12, b.ry);
	});
	bodies.instanceMatrix.needsUpdate = true;
	roofs.instanceMatrix.needsUpdate = true;
	scene.add(bodies);
	scene.add(roofs);
	hookables.push(bodies, roofs);
	const palace = new Group();
	const keep = new Mesh(new BoxGeometry(28, 36, 22), stoneMat);
	keep.position.y = 18;
	keep.castShadow = true;
	palace.add(keep);
	const dome = new Mesh(new SphereGeometry(8, 12, 10), roofMat);
	dome.position.y = 40;
	palace.add(dome);
	for (const sx of [-16, 16]) {
		const t = new Mesh(new BoxGeometry(8, 44, 8), stoneMat);
		t.position.set(sx, 22, 0);
		t.castShadow = true;
		palace.add(t);
	}
	palace.position.set(0, 0, -18);
	scene.add(palace);
	hookables.push(palace);
	const treeN = quality === "high" ? 140 : 70;
	const trunks = new InstancedMesh(new BoxGeometry(1, 1, 1), woodMat, treeN);
	const canopies = new InstancedMesh(new BoxGeometry(1, 1, 1), leafMat, treeN);
	trunks.castShadow = true;
	canopies.castShadow = true;
	let ti = 0;
	let guard = 0;
	while (ti < treeN && guard < treeN * 12) {
		guard++;
		const a = Math.random() * Math.PI * 2;
		const r = 40 + Math.random() * 480;
		const x = Math.cos(a) * r;
		const z = Math.sin(a) * r;
		const rr = Math.hypot(x, z);
		if ([
			WALLS.sina,
			WALLS.rose,
			WALLS.maria
		].some((w) => Math.abs(rr - w) < 16)) continue;
		if (rr < 30) continue;
		const th = 5 + Math.random() * 4;
		setInst(trunks, ti, x, th / 2, z, 1.3, th, 1.3, 0);
		setInst(canopies, ti, x, th + 2.2, z, 4.6 + Math.random(), 3.6, 4.6 + Math.random(), 0);
		ti++;
	}
	trunks.count = ti;
	canopies.count = ti;
	trunks.instanceMatrix.needsUpdate = true;
	canopies.instanceMatrix.needsUpdate = true;
	scene.add(trunks);
	scene.add(canopies);
	hookables.push(trunks, canopies);
	const grassN = quality === "high" ? 6500 : 2200;
	const bladeGeo = new PlaneGeometry(.85, 1.6);
	bladeGeo.translate(0, .75, 0);
	const bladeMat = new MeshStandardMaterial({
		map: textures.bladeGrass,
		transparent: true,
		alphaTest: .35,
		side: 2,
		roughness: .9
	});
	const grass = new InstancedMesh(bladeGeo, bladeMat, grassN);
	grass.instanceMatrix.setUsage(DynamicDrawUsage);
	scene.add(grass);
	const addSupply = (x, z) => {
		const crate = new Mesh(new BoxGeometry(1.6, 1.1, 1.2), crateMat);
		crate.position.set(x, .55, z);
		crate.castShadow = true;
		scene.add(crate);
		const flag = new Mesh(new BoxGeometry(.08, 2.4, .08), new MeshStandardMaterial({ color: 2762783 }));
		flag.position.set(x + .9, 1.2, z);
		scene.add(flag);
		supplies.push(new Vector3(x, 0, z));
	};
	addSupply(8, WALLS.maria - 48);
	addSupply(-6, WALLS.rose - 42);
	addSupply(10, 12);
	horseSpawns.push(new Vector3(-10, 0, WALLS.maria - 62), new Vector3(14, 0, WALLS.maria - 50), new Vector3(-18, 0, WALLS.rose - 40), new Vector3(16, 0, WALLS.rose - 55), new Vector3(-22, 0, 18), new Vector3(20, 0, -8));
	raidAnchors.push({
		name: "Shiganshina",
		x: 0,
		z: WALLS.maria - 55
	}, {
		name: "Trost",
		x: 0,
		z: WALLS.rose - 48
	}, {
		name: "Mitras",
		x: 0,
		z: 8
	});
	const torchPos = [
		[8, WALLS.maria - 8],
		[-8, WALLS.maria - 8],
		[8, WALLS.rose - 8],
		[-8, WALLS.rose - 8],
		[6, WALLS.sina - 8],
		[-6, WALLS.sina - 8],
		[0, WALLS.maria - 55],
		[0, WALLS.rose - 48]
	];
	for (const [tx, tz] of torchPos) {
		const light = new PointLight(16756838, 0, 28, 2);
		light.position.set(tx, 4.5, tz);
		scene.add(light);
		torches.push(light);
	}
	return {
		hookables,
		grass,
		grassCount: grassN,
		sun,
		hemi,
		amb,
		moon,
		sky,
		skyMat,
		torches,
		supplies,
		horseSpawns,
		raidAnchors,
		signs,
		fog
	};
}
function scatterGrass(grass, count, cx, cz, radius) {
	for (let i = 0; i < count; i++) {
		const a = Math.random() * Math.PI * 2;
		const r = Math.sqrt(Math.random()) * radius;
		const x = cx + Math.cos(a) * r;
		const z = cz + Math.sin(a) * r;
		const s = .7 + Math.random() * 1.1;
		_p.set(x, 0, z);
		_e.set(0, Math.random() * Math.PI, (Math.random() - .5) * .2);
		_q.setFromEuler(_e);
		_s.set(s, s, s);
		_m.compose(_p, _q, _s);
		grass.setMatrixAt(i, _m);
	}
	grass.instanceMatrix.needsUpdate = true;
}
function makeSign(text) {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = 128;
	const ctx = c.getContext("2d");
	ctx.fillStyle = "#2a281f";
	ctx.fillRect(0, 0, 512, 128);
	ctx.strokeStyle = "#d8d0c0";
	ctx.lineWidth = 8;
	ctx.strokeRect(8, 8, 496, 112);
	ctx.fillStyle = "#ece8dc";
	ctx.font = "700 48px Cinzel, serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText(text, 256, 68);
	const t = new CanvasTexture(c);
	t.colorSpace = SRGBColorSpace;
	const mat = new MeshBasicMaterial({ map: t });
	return new Mesh(new PlaneGeometry(22, 5.5), mat);
}
var KEY = "aot-campaign-v2";
var SAVE_VERSION = 2;
var defaults = () => ({
	version: SAVE_VERSION,
	gold: 40,
	xp: 0,
	level: 1,
	kills: 0,
	team: "scout",
	gasBonus: 0,
	bladeBonus: 0,
	odmBonus: 0,
	energyBonus: 0,
	horseBonus: 0
});
function xpForLevel(level) {
	return 80 + level * 45;
}
function loadProgress() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return defaults();
		const parsed = JSON.parse(raw);
		return {
			...defaults(),
			...parsed,
			version: SAVE_VERSION
		};
	} catch {
		return defaults();
	}
}
function saveProgress(p) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			...p,
			version: SAVE_VERSION
		}));
	} catch {}
}
function addXp(p, amount) {
	p.xp += amount;
	let leveled = false;
	while (p.xp >= xpForLevel(p.level)) {
		p.xp -= xpForLevel(p.level);
		p.level += 1;
		p.gold += 25 + p.level * 4;
		leveled = true;
	}
	return leveled;
}
function goldMul(p) {
	return p.team === "mp" ? 1.25 : 1;
}
function gasMax(p) {
	return 100 + p.gasBonus;
}
function bladeMax(p) {
	const team = p.team === "garrison" ? 20 : 0;
	return 100 + p.bladeBonus + team;
}
function energyMax(p) {
	return 100 + p.energyBonus;
}
function odmForce(p) {
	const team = p.team === "scout" ? 8 : 0;
	return 42 + p.odmBonus + team;
}
function horseSpeed(p) {
	return 22 + p.horseBonus;
}
function shopCatalog(p) {
	return [
		{
			id: "gas",
			name: "Gaz tankı",
			desc: "+25 kapasite",
			cost: 70 + p.gasBonus * 2,
			owned: p.gasBonus / 25,
			cap: 3
		},
		{
			id: "blade",
			name: "Ultra çelik bıçak",
			desc: "+20 dayanıklılık",
			cost: 65 + p.bladeBonus * 2,
			owned: p.bladeBonus / 20,
			cap: 3
		},
		{
			id: "odm",
			name: "ODM itiş",
			desc: "Daha güçlü kanca",
			cost: 110 + p.odmBonus * 4,
			owned: p.odmBonus / 8,
			cap: 3
		},
		{
			id: "energy",
			name: "Titan çekirdeği",
			desc: "+20 dönüşüm enerjisi",
			cost: 130 + p.energyBonus * 3,
			owned: p.energyBonus / 20,
			cap: 3
		},
		{
			id: "horse",
			name: "Savaş eyeri",
			desc: "At hızı +",
			cost: 90 + p.horseBonus * 6,
			owned: p.horseBonus / 5,
			cap: 2
		}
	];
}
function buyUpgrade(p, id) {
	const item = shopCatalog(p).find((x) => x.id === id);
	if (!item || item.owned >= item.cap || p.gold < item.cost) return false;
	p.gold -= item.cost;
	if (id === "gas") p.gasBonus += 25;
	if (id === "blade") p.bladeBonus += 20;
	if (id === "odm") p.odmBonus += 8;
	if (id === "energy") p.energyBonus += 20;
	if (id === "horse") p.horseBonus += 5;
	saveProgress(p);
	return true;
}
var POOL = [
	{
		id: "k5",
		type: "kills",
		title: "Ense avı",
		desc: "Saf devlerin ensesini kes",
		target: 5
	},
	{
		id: "k8",
		type: "kills",
		title: "Temizlik",
		desc: "Sekiz dev düşür",
		target: 8
	},
	{
		id: "def",
		type: "defend",
		title: "Şehri tut",
		desc: "Bir titan saldırısını savuştur",
		target: 1
	},
	{
		id: "mitras",
		type: "reach",
		title: "Mitras'a rapor",
		desc: "Sur Sina içine gir",
		target: 1
	},
	{
		id: "spec",
		type: "special",
		title: "Özel hedef",
		desc: "Zırhlı, Dişi, Çene veya Canavar Titan'ı düşür",
		target: 1
	},
	{
		id: "night",
		type: "night",
		title: "Gece nöbeti",
		desc: "Gece boyunca iki dev kes",
		target: 2
	}
];
function makeQuest(index, level) {
	const base = POOL[index % POOL.length];
	const scale = 1 + level * .12;
	return {
		...base,
		progress: 0,
		gold: Math.round((55 + level * 12) * scale),
		xp: Math.round((40 + level * 10) * scale)
	};
}
function inMitras(x, z) {
	return Math.hypot(x, z) < WALLS.sina - 12;
}
var _v1 = new Vector3();
var _v2 = new Vector3();
var _v3 = new Vector3();
var _fwd = new Vector3();
var _right = new Vector3();
var _up = new Vector3(0, 1, 0);
var _bg = new Color();
var _fogDay = new Color(11125716);
var _fogNight = new Color(1185308);
var PURE_KINDS = [
	"normal",
	"normal",
	"normal",
	"fast",
	"fast",
	"plated",
	"huge"
];
var SPECIALS = [
	"armored",
	"female",
	"jaw",
	"beast"
];
function createGame(canvas, onHud, flash) {
	const quality = window.innerWidth < 700 || matchMedia("(pointer: coarse)").matches ? "low" : "high";
	const textures = createTextures();
	const scene = new Scene();
	const camera = new PerspectiveCamera(60, 1, .15, 900);
	const renderer = new WebGLRenderer({
		canvas,
		antialias: quality === "high",
		powerPreference: "high-performance"
	});
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, quality === "high" ? 2 : 1.35));
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 4;
	renderer.toneMappingExposure = 1.12;
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = quality === "high" ? 2 : 1;
	const world = createWorld(scene, textures, quality);
	const progress = loadProgress();
	const scout = createScout(textures, TEAMS[progress.team].cloak);
	scene.add(scout.group);
	const titan = createAttackTitan(textures);
	titan.group.visible = false;
	scene.add(titan.group);
	scout.group.position.set(0, 0, WALLS.maria - 55);
	titan.group.position.copy(scout.group.position);
	const input = new Input();
	input.attach(canvas);
	const audio = new GameAudio();
	const boltLight = new PointLight(16774080, 0, 80, 2);
	scene.add(boltLight);
	const ringGeo = new RingGeometry(.6, 1.1, 32);
	const ringMat = new MeshBasicMaterial({
		color: 16764006,
		transparent: true,
		opacity: 0,
		side: 2
	});
	const shockwave = new Mesh(ringGeo, ringMat);
	shockwave.rotation.x = -Math.PI / 2;
	shockwave.visible = false;
	scene.add(shockwave);
	let shockT = 0;
	const enemies = [];
	const horses = [];
	world.horseSpawns.forEach((p) => {
		const h = createHorse();
		h.group.position.copy(p);
		scene.add(h.group);
		horses.push(h);
	});
	const allies = [];
	const spawnAlly = (ox, oz) => {
		const s = createScout(textures, TEAMS[progress.team].cloak);
		s.group.position.set(scout.group.position.x + ox, 0, scout.group.position.z + oz);
		scene.add(s.group);
		allies.push({
			scout: s,
			hp: 100,
			offset: new Vector3(ox, 0, oz),
			walkT: Math.random() * 4
		});
	};
	const pickPureKind = () => PURE_KINDS[Math.floor(Math.random() * PURE_KINDS.length)];
	const spawnEnemy = (rMin, rMax, raid = false, kind) => {
		const k = kind ?? pickPureKind();
		const e = k === "armored" || k === "female" || k === "jaw" || k === "beast" ? createSpecialTitan(k) : createPureTitan(k);
		const a = Math.random() * Math.PI * 2;
		const r = rMin + Math.random() * (rMax - rMin);
		e.group.position.set(Math.sin(a) * r, 0, Math.cos(a) * r);
		e.raid = raid;
		scene.add(e.group);
		world.hookables.push(e.group);
		enemies.push(e);
		return e;
	};
	for (let i = 0; i < 5; i++) spawnEnemy(WALLS.maria + 20, WALLS.maria + 90);
	for (let i = 0; i < 4; i++) spawnEnemy(WALLS.rose + 30, WALLS.maria - 30);
	for (let i = 0; i < 2; i++) spawnEnemy(WALLS.sina + 25, WALLS.rose - 25);
	const cableMat = new MeshStandardMaterial({
		color: 14542058,
		metalness: .9,
		roughness: .25
	});
	const cableGeo = new CylinderGeometry(.035, .035, 1, 5);
	const tipGeo = new ConeGeometry(.08, .28, 6);
	const makeHook = () => {
		const cable = new Mesh(cableGeo, cableMat);
		const tip = new Mesh(tipGeo, cableMat);
		cable.visible = false;
		tip.visible = false;
		scene.add(cable, tip);
		return {
			flying: false,
			attached: false,
			pos: new Vector3(),
			target: new Vector3(),
			cable,
			tip
		};
	};
	const hooks = [makeHook(), makeHook()];
	const pGeo = new SphereGeometry(.28, 6, 6);
	const particles = [];
	for (let i = 0; i < 180; i++) {
		const mesh = new Mesh(pGeo, new MeshBasicMaterial({
			color: 15658734,
			transparent: true,
			opacity: .7
		}));
		mesh.visible = false;
		scene.add(mesh);
		particles.push({
			mesh,
			vel: new Vector3(),
			life: 0,
			steam: false
		});
	}
	const rockGeo = new SphereGeometry(.7, 6, 6);
	const rockMat = new MeshStandardMaterial({
		color: 6972764,
		roughness: .9
	});
	const rocks = [];
	const raycaster = new Raycaster();
	raycaster.far = 200;
	let started = false;
	let paused = false;
	let isTitan = false;
	let isHardened = false;
	let energy = energyMax(progress);
	let gas = gasMax(progress);
	let blades = bladeMax(progress);
	let kills = progress.kills;
	let yaw = 0;
	let pitch = .12;
	let camYaw = Math.PI;
	let vel = new Vector3();
	let walkT = 0;
	let trauma = 0;
	let hitstop = 0;
	let attackT = 0;
	let grassAt = new Vector3(999, 0, 999);
	let hudAcc = 0;
	let last = performance.now();
	let running = true;
	let fov = 60;
	let tod = .38;
	let toast = "";
	let toastT = 0;
	let questIndex = 0;
	let quest = makeQuest(0, progress.level);
	let raid = null;
	let raidCd = 42;
	let specialCd = 28;
	let mounted = null;
	let nightKills = 0;
	const WORLD_LIMIT = 520;
	const titanRest = titan.skinMats.map((m) => ({
		color: m.color.getHex(),
		metal: m.metalness,
		rough: m.roughness
	}));
	let drag = null;
	scatterGrass(world.grass, world.grassCount, scout.group.position.x, scout.group.position.z, 48);
	const resize = () => {
		const w = canvas.clientWidth || window.innerWidth;
		const h = canvas.clientHeight || window.innerHeight;
		renderer.setSize(w, h, false);
		camera.aspect = w / Math.max(1, h);
		camera.updateProjectionMatrix();
	};
	resize();
	window.addEventListener("resize", resize);
	const ro = new ResizeObserver(resize);
	ro.observe(canvas.parentElement ?? canvas);
	const say = (msg) => {
		toast = msg;
		toastT = 3.4;
	};
	const persist = () => {
		progress.kills = kills;
		saveProgress(progress);
	};
	const emit = (pos, color, n, steam = false) => {
		let left = n;
		for (const p of particles) {
			if (left <= 0) break;
			if (p.life > 0) continue;
			p.life = steam ? .7 : .45;
			p.steam = steam;
			p.mesh.visible = true;
			p.mesh.material.color.setHex(color);
			p.mesh.material.opacity = steam ? .55 : .9;
			p.mesh.scale.setScalar(steam ? 1.2 : .7);
			p.mesh.position.copy(pos).add(_v1.set((Math.random() - .5) * 1.4, Math.random() * 1.2, (Math.random() - .5) * 1.4));
			p.vel.set((Math.random() - .5) * (steam ? 1.2 : 6), 1 + Math.random() * (steam ? 2 : 5), (Math.random() - .5) * (steam ? 1.2 : 6));
			left--;
		}
	};
	const placeCable = (hook, from, to) => {
		const len = from.distanceTo(to);
		hook.cable.visible = true;
		hook.tip.visible = true;
		hook.cable.position.lerpVectors(from, to, .5);
		hook.cable.scale.set(1, Math.max(.1, len), 1);
		_v1.subVectors(to, from).normalize();
		hook.cable.quaternion.setFromUnitVectors(_up, _v1);
		hook.tip.position.copy(to);
		hook.tip.quaternion.copy(hook.cable.quaternion);
	};
	const clearHooks = () => {
		for (const h of hooks) {
			h.flying = false;
			h.attached = false;
			h.cable.visible = false;
			h.tip.visible = false;
		}
	};
	const active = () => isTitan ? titan.group : scout.group;
	const limbs = () => isTitan ? titan.limbs : scout.limbs;
	const districtOf = (x, z) => {
		const r = Math.hypot(x, z);
		if (r < WALLS.sina - 8) return "Mitras  ·  Sur Sina";
		if (Math.hypot(x, z - (WALLS.rose - 48)) < 55 && r < WALLS.rose) return "Trost  ·  Sur Rose";
		if (r < WALLS.rose - 8) return "Sina — Rose arası";
		if (Math.abs(z - (WALLS.maria - 55)) < 70 && Math.abs(x) < 70 && r < WALLS.maria) return "Shiganshina  ·  Sur Maria";
		if (r < WALLS.maria - 8) return "Rose — Maria arası";
		return "Maria'nın ötesi";
	};
	const clockLabel = () => {
		if (tod < .22) return "Gece";
		if (tod < .32) return "Şafak";
		if (tod < .68) return "Gündüz";
		if (tod < .78) return "Akşam";
		return "Gece";
	};
	const isNight = () => tod < .22 || tod > .78;
	const nearSupply = () => {
		const p = active().position;
		return world.supplies.some((s) => p.distanceTo(s) < 8);
	};
	const nearestHorse = () => {
		const p = scout.group.position;
		let best = null;
		let d = 4.2;
		for (const h of horses) {
			if (h.occupied) continue;
			const dist = p.distanceTo(h.group.position);
			if (dist < d) {
				d = dist;
				best = h;
			}
		}
		return best;
	};
	const wallPush = (pos, radius) => {
		const r = Math.hypot(pos.x, pos.z);
		if (pos.y > 52) return;
		for (const wr of [
			WALLS.sina,
			WALLS.rose,
			WALLS.maria
		]) {
			const inner = wr - 6 - radius;
			const outer = wr + 6 + radius;
			if (r > inner && r < outer) {
				const ang = Math.atan2(pos.x, pos.z);
				if (Math.abs(ang) < .13) continue;
				const target = r < (inner + outer) / 2 ? inner : outer;
				pos.x = Math.sin(ang) * target;
				pos.z = Math.cos(ang) * target;
			}
		}
	};
	const dismount = () => {
		if (!mounted) return;
		mounted.occupied = false;
		scout.group.position.y = 0;
		mounted = null;
	};
	const fireHooks = () => {
		if (isTitan || gas < 8) return;
		if (mounted) dismount();
		gas -= 8;
		audio.gas();
		const origin = active().position.clone().add(_v1.set(0, 1.2, 0));
		raycaster.setFromCamera(new Vector2(0, 0), camera);
		const hits = raycaster.intersectObjects(world.hookables, true);
		let target;
		if (hits.length && hits[0].distance < 180 && hits[0].point.y > 1.2) target = hits[0].point.clone();
		else {
			camera.getWorldDirection(_v2);
			vel.addScaledVector(_v2, 18);
			emit(origin, 13421772, 8, true);
			return;
		}
		[scout.hips.left, scout.hips.right].forEach((hip, i) => {
			hip.getWorldPosition(hooks[i].pos);
			hooks[i].target.copy(target).add(_v3.set(i === 0 ? -1.2 : 1.2, 0, 0));
			hooks[i].flying = true;
			hooks[i].attached = false;
		});
		emit(origin, 13421772, 10, true);
	};
	const completeQuestIf = (type, amount = 1) => {
		if (quest.type !== type) return;
		quest.progress = Math.min(quest.target, quest.progress + amount);
		if (quest.progress >= quest.target) {
			const g = Math.round(quest.gold * goldMul(progress));
			progress.gold += g;
			const leveled = addXp(progress, quest.xp);
			audio.coin();
			say(`${quest.title} tamam · +${g} para` + (leveled ? " · Seviye atladın" : ""));
			questIndex += 1;
			quest = makeQuest(questIndex, progress.level);
			persist();
		}
	};
	const killEnemy = (e, i) => {
		emit(e.nape.getWorldPosition(_v2), 11145489, 28);
		emit(_v2, 15658734, 18, true);
		trauma = Math.min(1, trauma + .55);
		hitstop = .07;
		if (flash.impact) {
			flash.impact.style.opacity = "1";
			setTimeout(() => {
				if (flash.impact) flash.impact.style.opacity = "0";
			}, 110);
		}
		const wasRaid = e.raid;
		const wasSpecial = e.special;
		scene.remove(e.group);
		const hi = world.hookables.indexOf(e.group);
		if (hi >= 0) world.hookables.splice(hi, 1);
		enemies.splice(i, 1);
		kills++;
		const pay = Math.round((wasSpecial ? 55 : 12 + e.scale * 6) * goldMul(progress));
		progress.gold += pay;
		addXp(progress, wasSpecial ? 40 : 12);
		energy = Math.min(energyMax(progress), energy + (isTitan ? 8 : 18));
		completeQuestIf("kills");
		if (wasSpecial) completeQuestIf("special");
		if (isNight()) {
			nightKills++;
			completeQuestIf("night");
		}
		persist();
		if (wasRaid && !enemies.some((x) => x.raid)) {
			if (raid) {
				say(`${raid.name} savundu`);
				completeQuestIf("defend");
				raid = null;
			}
		}
		setTimeout(() => {
			if (!running) return;
			spawnEnemy(WALLS.maria + 30, WALLS.maria + 110);
		}, wasSpecial ? 18e3 : 2600);
	};
	const doAttack = () => {
		attackT = .28;
		const pos = active().position;
		if (!isTitan) {
			if (blades < 6) {
				audio.drySlash();
				say("Bıçaklar kırık — ikmal sandığına git");
				return;
			}
			blades = Math.max(0, blades - (8 + Math.random() * 4));
		}
		audio.slash();
		if (!isTitan) emit(pos.clone().add(_v1.set(0, 1.4, 0)), 8970495, 12);
		const range = isTitan ? isHardened ? 28 : 20 : 9;
		for (let i = enemies.length - 1; i >= 0; i--) {
			const e = enemies[i];
			if (pos.distanceTo(e.group.position) > range + e.scale * 4) continue;
			e.nape.getWorldPosition(_v2);
			if (pos.distanceTo(_v2) < (isTitan ? 12 : 5.5) || isTitan && isHardened) {
				e.hp -= isTitan ? isHardened ? 2 : 1 : 1;
				if (e.hp <= 0) killEnemy(e, i);
				else {
					emit(_v2, 11145489, 16);
					e.stunned = 1.2;
					say(`${SPECIAL_NAMES[e.kind] ?? "Dev"}  ${e.hp}/${e.maxHp}`);
				}
			} else {
				const avail = [
					"leftArm",
					"rightArm",
					"leftLeg",
					"rightLeg"
				].filter((n) => {
					if (n === "leftArm") return e.hasLeftArm;
					if (n === "rightArm") return e.hasRightArm;
					if (n === "leftLeg") return e.hasLeftLeg;
					return e.hasRightLeg;
				});
				if (!avail.length) continue;
				const pick = avail[Math.floor(Math.random() * avail.length)];
				const child = e.group.getObjectByName(pick);
				if (child) {
					child.getWorldPosition(_v3);
					emit(_v3, 11145489, 16);
					child.visible = false;
				}
				if (pick === "leftArm") e.hasLeftArm = false;
				if (pick === "rightArm") e.hasRightArm = false;
				if (pick === "leftLeg") e.hasLeftLeg = false;
				if (pick === "rightLeg") e.hasRightLeg = false;
			}
		}
		if (isTitan) {
			audio.roar();
			trauma = Math.min(1, trauma + (isHardened ? .5 : .32));
			emit(titan.group.position.clone().add(_v1.set(0, 8, 0)), isHardened ? 58879 : 16763972, 22);
		}
	};
	const spawnBolt = (pos) => {
		for (let b = 0; b < 4; b++) {
			const pts = [];
			const cur = new Vector3(pos.x + (Math.random() - .5) * 8, pos.y + 140, pos.z + (Math.random() - .5) * 8);
			pts.push(cur.clone());
			while (cur.y > pos.y) {
				cur.y -= 10 + Math.random() * 8;
				cur.x += (Math.random() - .5) * 14;
				cur.z += (Math.random() - .5) * 14;
				pts.push(cur.clone());
			}
			const line = new Line(new BufferGeometry().setFromPoints(pts), new LineBasicMaterial({ color: b % 2 ? 16773544 : 11462655 }));
			scene.add(line);
			setTimeout(() => {
				scene.remove(line);
				line.geometry.dispose();
				line.material.dispose();
			}, 320);
		}
		boltLight.position.copy(pos).setY(pos.y + 10);
		boltLight.intensity = 18;
	};
	const transform = () => {
		audio.unlock();
		if (!isTitan) {
			if (energy < 22) {
				say("Enerji yetersiz");
				return;
			}
			if (mounted) dismount();
			isTitan = true;
			titan.group.position.copy(scout.group.position);
			titan.group.rotation.y = scout.group.rotation.y;
			scout.group.visible = false;
			titan.group.visible = true;
			clearHooks();
			audio.thunder();
			audio.roar();
			trauma = .9;
			if (flash.lightning) {
				flash.lightning.style.opacity = "0.92";
				setTimeout(() => {
					if (flash.lightning) flash.lightning.style.opacity = "0";
				}, 180);
			}
			spawnBolt(titan.group.position);
			emit(titan.group.position.clone().add(_v1.set(0, 6, 0)), 8978431, 48);
			say("Saldırı Devi");
		} else {
			isTitan = false;
			isHardened = false;
			titan.skinMats.forEach((m, i) => {
				m.color.setHex(titanRest[i].color);
				m.metalness = titanRest[i].metal;
				m.roughness = titanRest[i].rough;
			});
			scout.group.position.copy(titan.group.position);
			scout.group.position.y = Math.max(0, titan.group.position.y);
			titan.group.visible = false;
			scout.group.visible = true;
			emit(scout.group.position.clone().add(_v1.set(0, 4, 0)), 15658734, 50, true);
			vel.set(0, 2.5, 0);
		}
	};
	const harden = () => {
		if (!isTitan) return;
		isHardened = !isHardened;
		titan.skinMats.forEach((m, i) => {
			if (isHardened) {
				m.color.setHex(8050920);
				m.metalness = .85;
				m.roughness = .12;
			} else {
				m.color.setHex(titanRest[i].color);
				m.metalness = titanRest[i].metal;
				m.roughness = titanRest[i].rough;
			}
		});
		emit(titan.group.position.clone().add(_v1.set(0, 8, 0)), 58879, 24);
	};
	const roar = () => {
		if (!isTitan) return;
		audio.roar();
		trauma = .85;
		const origin = titan.group.position;
		enemies.forEach((e) => {
			if (origin.distanceTo(e.group.position) < 52) {
				_v1.subVectors(e.group.position, origin).setY(0).normalize();
				e.group.position.addScaledVector(_v1, 14);
				e.stunned = 3.2;
			}
		});
		emit(origin.clone().add(_v1.set(0, 4, 0)), 16755251, 36);
		shockwave.position.set(origin.x, .2, origin.z);
		shockwave.scale.setScalar(1);
		ringMat.opacity = .7;
		shockwave.visible = true;
		shockT = .9;
		spawnBolt(origin);
	};
	const heal = () => {
		const p = active().position;
		emit(p.clone().add(_v1.set(0, 2, 0)), 15658734, 24, true);
		if (nearSupply()) {
			energy = energyMax(progress);
			gas = gasMax(progress);
			blades = bladeMax(progress);
			say("İkmal alındı");
			audio.coin();
		} else {
			energy = Math.min(energyMax(progress), energy + 18);
			gas = Math.min(gasMax(progress), gas + 14);
			say("Şehirde ikmal sandığı daha doldurur");
		}
	};
	const toggleMount = () => {
		if (isTitan) return;
		if (mounted) {
			dismount();
			return;
		}
		const h = nearestHorse();
		if (!h) {
			say("Yakında at yok");
			return;
		}
		mounted = h;
		h.occupied = true;
		clearHooks();
		say("Ata bindin  ·  G in");
	};
	const startRaid = () => {
		const anchor = world.raidAnchors[Math.floor(Math.random() * world.raidAnchors.length)];
		raid = {
			name: anchor.name,
			x: anchor.x,
			z: anchor.z,
			left: 28,
			spawned: 0
		};
		audio.horn();
		say(`Titan saldırısı — ${anchor.name}!`);
		const n = 4 + Math.min(3, Math.floor(progress.level / 3));
		for (let i = 0; i < n; i++) {
			const e = spawnEnemy(20, 70, true, i === 0 && progress.level > 2 ? pickPureKind() : "normal");
			const ang = Math.random() * Math.PI * 2;
			e.group.position.set(anchor.x + Math.cos(ang) * (38 + Math.random() * 22), 0, anchor.z + Math.sin(ang) * (38 + Math.random() * 22));
		}
	};
	const spawnSpecial = () => {
		if (enemies.some((e) => e.special)) return;
		const kind = SPECIALS[Math.floor(Math.random() * SPECIALS.length)];
		const e = spawnEnemy(WALLS.maria + 40, WALLS.maria + 120, false, kind);
		say(`${SPECIAL_NAMES[kind]} görüldü!`);
		audio.horn();
		return e;
	};
	const respawn = () => {
		dismount();
		isTitan = false;
		titan.group.visible = false;
		scout.group.visible = true;
		scout.group.position.set(0, 0, WALLS.maria - 55);
		vel.set(0, 0, 0);
		energy = energyMax(progress) * .6;
		gas = gasMax(progress);
		clearHooks();
		progress.gold = Math.max(0, progress.gold - 20);
		say("Düştün · Shiganshina");
		persist();
	};
	const throwRock = (from, toward) => {
		const mesh = new Mesh(rockGeo, rockMat);
		mesh.position.copy(from).add(_v1.set(0, 8, 0));
		scene.add(mesh);
		_v2.copy(toward).sub(from).setY(0);
		if (_v2.lengthSq() < .001) _v2.set(0, 0, 1);
		_v2.normalize().multiplyScalar(26);
		_v2.y = 8;
		rocks.push({
			mesh,
			vel: _v2.clone(),
			life: 3.2
		});
	};
	const pushHud = () => {
		const p = active().position;
		onHud({
			energy,
			energyMax: energyMax(progress),
			gas,
			gasMax: gasMax(progress),
			blades,
			bladeMax: bladeMax(progress),
			kills,
			gold: progress.gold,
			level: progress.level,
			xp: progress.xp,
			xpNext: xpForLevel(progress.level),
			isTitan,
			isHardened,
			district: districtOf(p.x, p.z),
			mode: isTitan ? isHardened ? "Saldırı Devi  ·  Sertleşme" : "Saldırı Devi" : mounted ? "At sırtı" : "İnsan  ·  ODM",
			sprinting: input.sampleMove().sprint,
			hooked: hooks.some((h) => h.attached),
			mounted: !!mounted,
			nearHorse: !mounted && !!nearestHorse(),
			nearSupply: nearSupply(),
			isNight: isNight(),
			clock: clockLabel(),
			px: p.x,
			pz: p.z,
			yaw: camYaw,
			titans: enemies.map((e) => ({
				x: e.group.position.x,
				z: e.group.position.z,
				kind: e.kind
			})),
			quest: {
				title: quest.title,
				desc: quest.desc,
				progress: quest.progress,
				target: quest.target,
				gold: quest.gold
			},
			raid: raid ? {
				name: raid.name,
				left: raid.left
			} : null,
			toast,
			squadAlive: allies.filter((a) => a.hp > 0).length,
			team: progress.team,
			shop: shopCatalog(progress)
		});
	};
	const updateLighting = (dt) => {
		tod = (tod + dt / 180) % 1;
		const elev = Math.sin((tod - .25) * Math.PI * 2);
		const day = MathUtils.smoothstep(elev, -.15, .35);
		const obj = active();
		const sunX = Math.cos((tod - .25) * Math.PI * 2) * 160;
		const sunY = 40 + Math.max(8, elev * 240);
		const sunZ = Math.sin((tod - .25) * Math.PI * 2) * 80;
		world.sun.position.set(obj.position.x + sunX, sunY, obj.position.z + sunZ);
		world.sun.target.position.copy(obj.position);
		world.sun.target.updateMatrixWorld();
		world.sun.intensity = .12 + day * 1.28;
		world.sun.color.setRGB(1, .94 + day * .04, .78 + day * .18);
		world.hemi.intensity = .22 + day * .42;
		world.amb.intensity = .12 + day * .18;
		world.moon.intensity = (1 - day) * .35;
		world.moon.position.set(obj.position.x - 70, 140, obj.position.z - 40);
		const fogDay = _fogDay;
		const fogNight = _fogNight;
		world.fog.color.copy(fogDay).lerp(fogNight, 1 - day);
		scene.background = _bg.copy(world.fog.color);
		world.skyMat.color.setRGB(.28 + day * .72, .32 + day * .68, .4 + day * .6);
		world.fog.near = 50 + day * 40;
		world.fog.far = 320 + day * 220;
		renderer.toneMappingExposure = .72 + day * .48;
		const torchI = (1 - day) * 2.4;
		world.torches.forEach((t) => {
			t.intensity = torchI;
		});
		if (boltLight.intensity > 0) boltLight.intensity = Math.max(0, boltLight.intensity - dt * 28);
	};
	const update = (dt) => {
		const actions = input.consumeActions();
		if (actions.has("hook")) fireHooks();
		if (actions.has("attack")) doAttack();
		if (actions.has("transform")) transform();
		if (actions.has("heal")) heal();
		if (actions.has("roar")) roar();
		if (actions.has("harden")) harden();
		if (actions.has("mount")) toggleMount();
		const look = input.consumeLook();
		camYaw -= look.x * .0024;
		pitch -= look.y * .002;
		pitch = Math.max(-.55, Math.min(.85, pitch));
		const move = input.sampleMove();
		_fwd.set(-Math.sin(camYaw), 0, -Math.cos(camYaw));
		_right.set(Math.cos(camYaw), 0, -Math.sin(camYaw));
		const obj = active();
		const sprint = move.sprint;
		const ride = !!mounted && !isTitan;
		const speed = (isTitan ? 18 : ride ? horseSpeed(progress) : 9.5) * (sprint && !ride ? 1.75 : ride && sprint ? 1.25 : 1) * (hooks.some((h) => h.attached) ? .35 : 1);
		const grounded = obj.position.y <= .08 || ride;
		if (grounded || isTitan) {
			_v1.copy(_fwd).multiplyScalar(move.y).addScaledVector(_right, move.x);
			if (_v1.lengthSq() > .001) {
				_v1.normalize();
				obj.position.addScaledVector(_v1, speed * dt);
				yaw = Math.atan2(-_v1.x, -_v1.z);
				obj.lookAt(obj.position.x + _v1.x, obj.position.y, obj.position.z + _v1.z);
				walkT += dt * (sprint ? 10 : 6.5) * (isTitan ? .7 : ride ? 1.4 : 1);
				const swing = Math.sin(walkT) * (sprint ? .7 : .4);
				const L = limbs();
				L.leftLeg.rotation.x = ride ? 0 : swing;
				L.rightLeg.rotation.x = ride ? 0 : -swing;
				L.leftArm.rotation.x = ride ? .4 : -swing * .8 + (attackT > 0 ? -1.2 : 0);
				L.rightArm.rotation.x = ride ? .4 : swing * .8 + (attackT > 0 ? -1.4 : 0);
			} else {
				const L = limbs();
				L.leftLeg.rotation.x *= .8;
				L.rightLeg.rotation.x *= .8;
				L.leftArm.rotation.x *= .8;
				L.rightArm.rotation.x *= .8;
			}
		} else {
			_v1.copy(_fwd).multiplyScalar(move.y).addScaledVector(_right, move.x);
			vel.addScaledVector(_v1, 18 * dt);
		}
		if (attackT > 0) attackT -= dt;
		if (mounted && !isTitan) {
			mounted.group.position.x = scout.group.position.x;
			mounted.group.position.z = scout.group.position.z;
			mounted.group.rotation.y = scout.group.rotation.y;
			scout.group.position.y = 1.05;
			vel.set(0, 0, 0);
		}
		const hooked = hooks.some((h) => h.attached || h.flying);
		if (!isTitan && !mounted) {
			scout.hips.left.getWorldPosition(_v2);
			scout.hips.right.getWorldPosition(_v3);
			const origins = [_v2.clone(), _v3.clone()];
			for (let i = 0; i < 2; i++) {
				const h = hooks[i];
				if (h.flying) {
					_v1.subVectors(h.target, h.pos);
					const dist = _v1.length();
					const step = 160 * dt;
					if (dist < step) {
						h.pos.copy(h.target);
						h.flying = false;
						h.attached = true;
					} else h.pos.addScaledVector(_v1.normalize(), step);
					placeCable(h, origins[i], h.pos);
				} else if (h.attached) placeCable(h, origins[i], h.target);
			}
			if (hooks.some((h) => h.attached)) {
				const target = _v1.set(0, 0, 0);
				let n = 0;
				hooks.forEach((h) => {
					if (h.attached) {
						target.add(h.target);
						n++;
					}
				});
				target.multiplyScalar(1 / Math.max(1, n));
				_v1.subVectors(target, obj.position);
				if (_v1.length() > 3.2) {
					vel.addScaledVector(_v1.normalize(), odmForce(progress) * dt);
					gas = Math.max(0, gas - 9 * dt);
				} else {
					clearHooks();
					if (target.y > 2) obj.position.y = target.y;
				}
				if (gas <= 0) clearHooks();
			}
			obj.position.addScaledVector(vel, dt);
			vel.multiplyScalar(grounded ? .82 : .985);
			if (!hooked) vel.y -= 28 * dt;
			else vel.y -= 6 * dt;
			if (obj.position.y < 0) {
				obj.position.y = 0;
				vel.y = 0;
				if (grounded) vel.x *= .7;
				vel.z *= .7;
			}
			if (gas < gasMax(progress)) gas = Math.min(gasMax(progress), gas + 3.5 * dt);
		} else if (isTitan) {
			energy -= 2.8 * dt;
			obj.position.y = 0;
			vel.set(0, 0, 0);
			if (energy <= 0) {
				energy = 0;
				transform();
			}
			if (Math.random() < .25) emit(obj.position.clone().add(_v1.set(0, 8, 0)), isHardened ? 8972543 : 10092543, 1);
		}
		wallPush(obj.position, isTitan ? 3.2 : .6);
		obj.position.x = MathUtils.clamp(obj.position.x, -520, WORLD_LIMIT);
		obj.position.z = MathUtils.clamp(obj.position.z, -520, WORLD_LIMIT);
		if (quest.type === "reach" && inMitras(obj.position.x, obj.position.z)) completeQuestIf("reach");
		const nightMul = isNight() ? 1.28 : 1;
		enemies.forEach((e) => {
			if (e.stunned > 0) {
				e.stunned -= dt;
				return;
			}
			const dest = e.raid && raid ? _v3.set(raid.x, 0, raid.z) : obj.position;
			_v1.subVectors(dest, e.group.position);
			_v1.y = 0;
			const d = _v1.length();
			if (d > 1) _v1.multiplyScalar(1 / d);
			const spd = (e.hasLeftLeg && e.hasRightLeg ? 2.4 : .9) * e.speed * nightMul;
			if (d > (e.kind === "beast" ? 34 : 4) && d < 280) e.group.position.addScaledVector(_v1, spd * dt);
			e.group.lookAt(dest.x, e.group.position.y, dest.z);
			e.walkT += dt * spd;
			const sw = Math.sin(e.walkT) * .45;
			e.limbs.leftLeg.rotation.x = sw;
			e.limbs.rightLeg.rotation.x = -sw;
			e.limbs.leftArm.rotation.x = -sw * .7;
			e.limbs.rightArm.rotation.x = sw * .7;
			if (e.kind === "beast") {
				e.throwCd -= dt;
				if (e.throwCd <= 0 && d < 70 && d > 12) {
					e.throwCd = 3.4;
					throwRock(e.group.position, obj.position);
				}
			}
			if (e.kind === "jaw" && d < 16 && d > 5 && Math.random() < .015) e.group.position.addScaledVector(_v1, 9);
			if (e.raid && raid && d < 6) raid.left -= dt * 4;
			if (!isTitan && d < 3.4 + e.scale) {
				energy = Math.max(0, energy - (14 + e.scale * 6) * dt);
				trauma = Math.min(1, trauma + .2 * dt);
				_v2.copy(_v1).multiplyScalar(-8 * dt);
				obj.position.add(_v2);
				if (mounted) dismount();
				if (energy <= 0) respawn();
			}
		});
		for (let i = rocks.length - 1; i >= 0; i--) {
			const r = rocks[i];
			r.life -= dt;
			r.vel.y -= 18 * dt;
			r.mesh.position.addScaledVector(r.vel, dt);
			if (r.mesh.position.y < .4) {
				r.mesh.position.y = .4;
				r.vel.set(0, 0, 0);
			}
			if (!isTitan && r.mesh.position.distanceTo(obj.position) < 2.2) {
				energy = Math.max(0, energy - 22);
				trauma = .6;
				r.life = 0;
				if (energy <= 0) respawn();
			}
			if (r.life <= 0) {
				scene.remove(r.mesh);
				rocks.splice(i, 1);
			}
		}
		allies.forEach((a) => {
			if (a.hp <= 0) {
				a.scout.group.visible = false;
				return;
			}
			const target = obj.position.clone().add(a.offset);
			_v1.subVectors(target, a.scout.group.position);
			_v1.y = 0;
			if (_v1.length() > 1.4) {
				_v1.normalize();
				a.scout.group.position.addScaledVector(_v1, 8 * dt);
				a.scout.group.lookAt(a.scout.group.position.x + _v1.x, 0, a.scout.group.position.z + _v1.z);
				a.walkT += dt * 8;
				const sw = Math.sin(a.walkT) * .4;
				a.scout.limbs.leftLeg.rotation.x = sw;
				a.scout.limbs.rightLeg.rotation.x = -sw;
			}
			for (let i = enemies.length - 1; i >= 0; i--) {
				const e = enemies[i];
				if (a.scout.group.position.distanceTo(e.group.position) < 5 + e.scale) {
					e.hp -= dt * .35;
					if (e.hp <= 0) killEnemy(e, i);
				}
			}
		});
		if (grassAt.distanceTo(obj.position) > 14) {
			scatterGrass(world.grass, world.grassCount, obj.position.x, obj.position.z, 52);
			grassAt.copy(obj.position);
		}
		for (const p of particles) {
			if (p.life <= 0) continue;
			p.life -= dt;
			p.mesh.position.addScaledVector(p.vel, dt);
			if (p.steam) {
				p.mesh.scale.addScalar(dt * 1.8);
				p.mesh.material.opacity -= dt * .8;
			}
			if (p.life <= 0) p.mesh.visible = false;
		}
		if (shockT > 0) {
			shockT -= dt;
			shockwave.scale.addScalar(dt * 28);
			ringMat.opacity = Math.max(0, shockT);
			if (shockT <= 0) shockwave.visible = false;
		}
		raidCd -= dt;
		if (!raid && raidCd <= 0) {
			startRaid();
			raidCd = 70 + Math.random() * 40;
		}
		if (raid) {
			raid.left -= dt;
			if (raid.left <= 0) {
				say(`${raid.name} yaralandı`);
				progress.gold = Math.max(0, progress.gold - 15);
				raid = null;
				persist();
			}
		}
		specialCd -= dt;
		if (specialCd <= 0) {
			spawnSpecial();
			specialCd = 55 + Math.random() * 40;
		}
		if (toastT > 0) {
			toastT -= dt;
			if (toastT <= 0) toast = "";
		}
		updateLighting(dt);
		trauma = Math.max(0, trauma - dt * 1.4);
		hudAcc += dt;
		if (hudAcc > .12) {
			hudAcc = 0;
			pushHud();
		}
	};
	const render = (dt) => {
		const obj = active();
		const dist = isTitan ? 28 : mounted ? 14 : 11.5;
		const height = isTitan ? 14 : mounted ? 5.2 : 4.2;
		const lookY = isTitan ? 8 : 1.7;
		const ch = Math.cos(pitch);
		const desired = _v1.set(obj.position.x + Math.sin(camYaw) * dist * ch, obj.position.y + height + Math.sin(pitch) * dist, obj.position.z + Math.cos(camYaw) * dist * ch);
		if (!started) {
			camYaw += dt * .08;
			const ox = obj.position.x;
			const oz = obj.position.z;
			camera.position.set(ox + Math.sin(camYaw) * 26, 11, oz + Math.cos(camYaw) * 26);
			camera.lookAt(ox, 8, oz + 18);
			renderer.render(scene, camera);
			return;
		}
		const k = 1 - Math.exp(-8 * dt);
		camera.position.lerp(desired, started ? k : 1);
		const shake = trauma * trauma;
		if (shake > 0) {
			camera.position.x += (Math.random() - .5) * shake * 1.6;
			camera.position.y += (Math.random() - .5) * shake * 1.2;
		}
		camera.lookAt(obj.position.x, obj.position.y + lookY, obj.position.z);
		const wantFov = isTitan ? 58 : input.sampleMove().sprint ? 66 : 60;
		fov += (wantFov - fov) * (1 - Math.exp(-6 * dt));
		camera.fov = fov;
		camera.updateProjectionMatrix();
		renderer.render(scene, camera);
	};
	const loop = (now) => {
		if (!running) return;
		const dt = Math.min((now - last) / 1e3, .08);
		last = now;
		if (started && !paused) {
			if (hitstop > 0) hitstop -= dt;
			else update(dt);
		} else updateLighting(dt * .25);
		render(dt);
	};
	renderer.setAnimationLoop(loop);
	const onPointerDown = (e) => {
		if (!started || paused) return;
		if (e.pointerType === "mouse") try {
			canvas.requestPointerLock();
		} catch {}
		if (input.pointerLocked) return;
		drag = {
			id: e.pointerId,
			x: e.clientX,
			y: e.clientY
		};
		try {
			canvas.setPointerCapture(e.pointerId);
		} catch {}
	};
	const onPointerMove = (e) => {
		if (input.pointerLocked || !started || paused) return;
		if (e.pointerType === "mouse" && e.buttons === 1) {
			input.lookDx += e.movementX;
			input.lookDy += e.movementY;
			return;
		}
		if (!drag || drag.id !== e.pointerId) return;
		input.lookDx += e.clientX - drag.x;
		input.lookDy += e.clientY - drag.y;
		drag.x = e.clientX;
		drag.y = e.clientY;
	};
	const onPointerUp = (e) => {
		if (drag?.id === e.pointerId) drag = null;
	};
	canvas.addEventListener("pointerdown", onPointerDown);
	canvas.addEventListener("pointermove", onPointerMove);
	canvas.addEventListener("pointerup", onPointerUp);
	canvas.addEventListener("pointercancel", onPointerUp);
	const onHide = () => {
		if (document.hidden) persist();
	};
	document.addEventListener("visibilitychange", onHide);
	window.__controlsTest = {
		getYaw: () => yaw,
		getSpeed: () => {
			const m = input.sampleMove();
			return Math.hypot(m.x, m.y) * (m.sprint ? 18 : 10);
		},
		setKeys: (codes) => {
			input.setKeys(codes);
			if (codes.length) {
				started = true;
				paused = false;
			}
		},
		setSteer: (v) => {
			if (v > .1) input.setKeys(["KeyW", "KeyA"]);
			else if (v < -.1) input.setKeys(["KeyW", "KeyD"]);
			else input.setKeys(["KeyW"]);
		}
	};
	pushHud();
	return {
		dispose() {
			running = false;
			persist();
			renderer.setAnimationLoop(null);
			window.removeEventListener("resize", resize);
			document.removeEventListener("visibilitychange", onHide);
			ro.disconnect();
			canvas.removeEventListener("pointerdown", onPointerDown);
			canvas.removeEventListener("pointermove", onPointerMove);
			canvas.removeEventListener("pointerup", onPointerUp);
			canvas.removeEventListener("pointercancel", onPointerUp);
			input.dispose();
			disposeTextures(textures);
			renderer.dispose();
		},
		start() {
			started = true;
			paused = false;
			audio.unlock();
			if (allies.length === 0) {
				spawnAlly(-3.2, 2.4);
				spawnAlly(3.4, 1.8);
			}
			say(`${TEAMS[progress.team].name} göreve çıktı`);
		},
		pause() {
			paused = true;
		},
		resume() {
			paused = false;
		},
		pulse(action) {
			input.pulse(action);
		},
		setSprintToggle(on) {
			input.sprintToggle = on;
		},
		setJoystick(x, y, activeJoy) {
			input.joyX = x;
			input.joyY = y;
			input.joyActive = activeJoy;
		},
		addLook(dx, dy) {
			input.lookDx += dx;
			input.lookDy += dy;
		},
		setTeam(team) {
			progress.team = team;
			persist();
		},
		buy(id) {
			const ok = buyUpgrade(progress, id);
			if (ok) {
				gas = Math.min(gasMax(progress), gas + 10);
				blades = Math.min(bladeMax(progress), blades + 10);
				energy = Math.min(energyMax(progress), energy + 8);
				say("Ekipman geliştirildi");
				audio.coin();
				pushHud();
			}
			return ok;
		}
	};
}
//#endregion
export { createGame };
