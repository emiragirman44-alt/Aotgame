import { i as __toESM } from "../_runtime.mjs";
import { I as require_jsx_runtime, L as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Swords, c as Heart, l as Footprints, n as Wind, o as Shield, r as Volume2, s as Package, t as Zap, u as ChevronsUp } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C-jHN7lU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var WALLS = {
	sina: 150,
	rose: 270,
	maria: 410
};
var WORLD_SIZE = 1100;
var TEAMS = {
	scout: {
		name: "Keşif Birliği",
		bonus: "ODM itiş +",
		cloak: 4017974
	},
	garrison: {
		name: "Garnizon",
		bonus: "Bıçak dayanıklılığı +",
		cloak: 6048306
	},
	mp: {
		name: "Askeri Polis",
		bonus: "Para kazancı +",
		cloak: 3817301
	}
};
var EMPTY = {
	energy: 100,
	energyMax: 100,
	gas: 100,
	gasMax: 100,
	blades: 100,
	bladeMax: 100,
	kills: 0,
	gold: 40,
	level: 1,
	xp: 0,
	xpNext: 125,
	isTitan: false,
	isHardened: false,
	district: "Shiganshina  ·  Sur Maria",
	mode: "İnsan  ·  ODM",
	sprinting: false,
	hooked: false,
	mounted: false,
	nearHorse: false,
	nearSupply: false,
	isNight: false,
	clock: "Gündüz",
	px: 0,
	pz: WALLS.maria - 58,
	yaw: 0,
	titans: [],
	quest: {
		title: "Ense avı",
		desc: "Saf devlerin ensesini kes",
		progress: 0,
		target: 5,
		gold: 55
	},
	raid: null,
	toast: "",
	squadAlive: 2,
	team: "scout",
	shop: []
};
function GameView() {
	const canvasRef = (0, import_react.useRef)(null);
	const lightningRef = (0, import_react.useRef)(null);
	const impactRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const joyPtr = (0, import_react.useRef)(null);
	const lookPtr = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(EMPTY);
	const [phase, setPhase] = (0, import_react.useState)("menu");
	const [sprint, setSprint] = (0, import_react.useState)(false);
	const [team, setTeam] = (0, import_react.useState)("scout");
	const [shopOpen, setShopOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let cancelled = false;
		import("./engine-C7DcX2UP.mjs").then(({ createGame }) => {
			if (cancelled || !canvasRef.current) return;
			const handle = createGame(canvas, setHud, {
				lightning: lightningRef.current,
				impact: impactRef.current
			});
			if (cancelled) {
				handle.dispose();
				return;
			}
			gameRef.current = handle;
		});
		return () => {
			cancelled = true;
			gameRef.current?.dispose();
			gameRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.code === "KeyB" && phase === "play") {
				e.preventDefault();
				setShopOpen((o) => !o);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [phase]);
	(0, import_react.useEffect)(() => {
		const c = mapRef.current;
		if (!c) return;
		const ctx = c.getContext("2d");
		if (!ctx) return;
		const w = c.width;
		const h = c.height;
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = hud.isNight ? "rgba(8,10,14,0.72)" : "rgba(12,13,11,0.55)";
		ctx.beginPath();
		ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
		ctx.fill();
		const scale = (w / 2 - 8) / 500;
		const cx = w / 2;
		const cy = h / 2;
		ctx.strokeStyle = "rgba(236,232,220,0.45)";
		ctx.lineWidth = 1.2;
		for (const r of [
			WALLS.sina,
			WALLS.rose,
			WALLS.maria
		]) {
			ctx.beginPath();
			ctx.arc(cx, cy, r * scale, 0, Math.PI * 2);
			ctx.stroke();
		}
		hud.titans.forEach((t) => {
			ctx.fillStyle = t.kind === "armored" || t.kind === "female" || t.kind === "jaw" || t.kind === "beast" ? "#c4bba8" : "#9a3b32";
			ctx.beginPath();
			ctx.arc(cx + t.x * scale, cy + t.z * scale, t.kind === "huge" ? 3.2 : 2.2, 0, Math.PI * 2);
			ctx.fill();
		});
		ctx.fillStyle = "#ece8dc";
		const px = cx + hud.px * scale;
		const pz = cy + hud.pz * scale;
		ctx.beginPath();
		ctx.arc(px, pz, 3, 0, Math.PI * 2);
		ctx.fill();
		ctx.strokeStyle = "#ece8dc";
		ctx.beginPath();
		ctx.moveTo(px, pz);
		ctx.lineTo(px - Math.sin(hud.yaw) * 8, pz - Math.cos(hud.yaw) * 8);
		ctx.stroke();
	}, [
		hud.px,
		hud.pz,
		hud.yaw,
		hud.titans,
		hud.isNight
	]);
	const start = () => {
		gameRef.current?.setTeam(team);
		gameRef.current?.start();
		setPhase("play");
	};
	const onJoyDown = (e) => {
		e.preventDefault();
		e.currentTarget.setPointerCapture(e.pointerId);
		joyPtr.current = e.pointerId;
		steerJoy(e);
	};
	const onJoyMove = (e) => {
		if (joyPtr.current !== e.pointerId) return;
		steerJoy(e);
	};
	const onJoyUp = (e) => {
		if (joyPtr.current !== e.pointerId) return;
		joyPtr.current = null;
		gameRef.current?.setJoystick(0, 0, false);
		const knob = e.currentTarget.querySelector(".joy-knob");
		if (knob) knob.style.transform = "translate(-50%, -50%)";
	};
	const steerJoy = (e) => {
		const rec = e.currentTarget.getBoundingClientRect();
		const dx = e.clientX - (rec.left + rec.width / 2);
		const dy = e.clientY - (rec.top + rec.height / 2);
		const max = rec.width * .42;
		const mag = Math.hypot(dx, dy);
		const nx = mag > max ? dx / mag * max : dx;
		const ny = mag > max ? dy / mag * max : dy;
		const knob = e.currentTarget.querySelector(".joy-knob");
		if (knob) knob.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`;
		gameRef.current?.setJoystick(nx / max, -ny / max, true);
	};
	const onLookDown = (e) => {
		if (e.target.closest(".act, .joy-base")) return;
		lookPtr.current = {
			id: e.pointerId,
			x: e.clientX,
			y: e.clientY
		};
		e.currentTarget.setPointerCapture(e.pointerId);
	};
	const onLookMove = (e) => {
		const p = lookPtr.current;
		if (!p || p.id !== e.pointerId) return;
		const dx = e.clientX - p.x;
		const dy = e.clientY - p.y;
		p.x = e.clientX;
		p.y = e.clientY;
		gameRef.current?.addLook(dx, dy);
	};
	const onLookUp = (e) => {
		if (lookPtr.current?.id === e.pointerId) lookPtr.current = null;
	};
	const pulse = (a) => () => gameRef.current?.pulse(a);
	const energyPct = hud.energy / Math.max(1, hud.energyMax) * 100;
	const gasPct = hud.gas / Math.max(1, hud.gasMax) * 100;
	const bladePct = hud.blades / Math.max(1, hud.bladeMax) * 100;
	const xpPct = hud.xp / Math.max(1, hud.xpNext) * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "game-root",
		className: hud.isTitan ? "titan-on" : "",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "game-canvas"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flash lightning",
				ref: lightningRef
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flash impact",
				ref: impactRef
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "crosshair" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overlay",
				children: [
					phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hud-top",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "status-kicker",
									children: [
										hud.clock,
										" · ",
										TEAMS[hud.team].name
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "status-title",
									children: hud.district
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "status-meta",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Ense ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: hud.kills })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Sv. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: hud.level })] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Para ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: hud.gold })] })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "xp-track",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "xp-fill",
										style: { width: `${xpPct}%` }
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel bars",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bar-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bar-lab",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hud.isTitan ? "Titan enerji" : "Dönüşüm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(hud.energy) })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "bar-track",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bar-fill bar-energy",
											style: { width: `${Math.max(0, energyPct)}%` }
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bar-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bar-lab",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ODM gaz" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(hud.gas) })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "bar-track",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bar-fill bar-gas",
											style: { width: `${Math.max(0, gasPct)}%` }
										})
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bar-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bar-lab",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Bıçak" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: Math.round(hud.blades) })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "bar-track",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bar-fill bar-blade",
											style: { width: `${Math.max(0, bladePct)}%` }
										})
									})]
								})
							]
						})]
					}),
					phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "minimap-wrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: mapRef,
							className: "minimap",
							width: 92,
							height: 92
						})
					}),
					hud.quest && phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "quest-card",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "quest-kicker",
								children: [
									"Görev · +",
									hud.quest.gold,
									" para"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "quest-title",
								children: hud.quest.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "quest-desc",
								children: hud.quest.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bar-track quest-bar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bar-fill bar-quest",
									style: { width: `${hud.quest.progress / Math.max(1, hud.quest.target) * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "quest-count",
								children: [
									hud.quest.progress,
									"/",
									hud.quest.target
								]
							})
						]
					}),
					hud.raid && phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "raid-banner",
						children: [
							"Titan saldırısı · ",
							hud.raid.name,
							" · ",
							Math.ceil(hud.raid.left),
							"s"
						]
					}),
					hud.toast && phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "toast",
						children: hud.toast
					}),
					phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hint desk-only",
						children: "WASD · Q kanca · F kes · E dönüşüm · G at · H ikmal · B dükkân · R kükre"
					})
				]
			}),
			phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "shop-fab hit",
				type: "button",
				onClick: () => setShopOpen(true),
				children: "Dükkân"
			}),
			shopOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shop-scrim",
				onClick: () => setShopOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shop-card",
					onClick: (e) => e.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "menu-kicker",
							children: [
								"Gelişim · ",
								hud.gold,
								" para"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "shop-title",
							children: "Ekipman"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "shop-list",
							children: hud.shop.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "shop-name",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shop-desc",
								children: [
									item.desc,
									" · ",
									item.owned,
									"/",
									item.cap
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "shop-buy",
								disabled: item.owned >= item.cap || hud.gold < item.cost,
								onClick: () => gameRef.current?.buy(item.id),
								children: item.cost
							})] }, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "menu-btn shop-close",
							onClick: () => setShopOpen(false),
							children: "Kapat"
						})
					]
				})
			}),
			phase === "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "touch-layer",
				onPointerDown: onLookDown,
				onPointerMove: onLookMove,
				onPointerUp: onLookUp,
				onPointerCancel: onLookUp,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "joy-base",
						onPointerDown: onJoyDown,
						onPointerMove: onJoyMove,
						onPointerUp: onJoyUp,
						onPointerCancel: onJoyUp,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "joy-knob" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: `act act-sprint ${sprint ? "on" : ""}`,
						type: "button",
						onPointerDown: (e) => {
							e.stopPropagation();
							const next = !sprint;
							setSprint(next);
							gameRef.current?.setSprintToggle(next);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsUp, {}), "Koş"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-transform",
						type: "button",
						onPointerDown: pulse("transform"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {}), "Devi"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-hook",
						type: "button",
						onPointerDown: pulse("hook"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, {}), "ODM"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-attack",
						type: "button",
						onPointerDown: pulse("attack"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swords, {}), "Kes"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-heal",
						type: "button",
						onPointerDown: pulse("heal"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {}), "İkmal"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-mount",
						type: "button",
						onPointerDown: pulse("mount"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footprints, {}), "At"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-shop",
						type: "button",
						onPointerDown: () => setShopOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Package, {}), "Al"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-roar hidden-titan",
						type: "button",
						onPointerDown: pulse("roar"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {}), "Kükre"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "act act-harden hidden-titan",
						type: "button",
						onPointerDown: pulse("harden"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {}), "Sertleş"]
					})
				]
			}),
			phase === "menu" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "menu",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "menu-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "menu-kicker",
							children: "Sur Maria · Sur Rose · Sur Sina"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "menu-title",
							children: "Saldırı Devi"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "menu-sub",
							children: "ODM ile uç, bıçak dayanıklılığını yönet, ata bin, şehri savun. Yıldırımla Saldırı Devi’ne dönüş; Zırhlı, Dişi, Çene ve Canavar Titan onları bekliyor."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "team-pick",
							children: Object.keys(TEAMS).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `team-btn ${team === id ? "on" : ""}`,
								onClick: () => {
									setTeam(id);
									gameRef.current?.setTeam(id);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: TEAMS[id].name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: TEAMS[id].bonus })]
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "menu-btn",
							type: "button",
							onClick: start,
							children: "Göreve başla"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "menu-keys",
							children: [
								"WASD hareket · Q kanca · F kes · E dönüşüm · G at",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"H ikmal · R kükre · X sertleş · Shift koş"
							]
						})
					]
				})
			})
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameView, {});
}
//#endregion
export { WORLD_SIZE as i, TEAMS as n, WALLS as r, routes_exports as t };
