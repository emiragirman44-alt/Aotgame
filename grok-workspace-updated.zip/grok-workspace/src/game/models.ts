import * as THREE from "three";
import type { GameTextures } from "./textures";
import type { TitanKind } from "./types";

function add(
  parent: THREE.Object3D,
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  x: number,
  y: number,
  z: number,
  opts: {
    sx?: number;
    sy?: number;
    sz?: number;
    rx?: number;
    ry?: number;
    rz?: number;
    cast?: boolean;
    name?: string;
  } = {},
): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  if (opts.sx || opts.sy || opts.sz) m.scale.set(opts.sx ?? 1, opts.sy ?? 1, opts.sz ?? 1);
  if (opts.rx) m.rotation.x = opts.rx;
  if (opts.ry) m.rotation.y = opts.ry;
  if (opts.rz) m.rotation.z = opts.rz;
  m.castShadow = opts.cast !== false;
  m.receiveShadow = true;
  if (opts.name) m.name = opts.name;
  parent.add(m);
  return m;
}

export type LimbSet = {
  leftLeg: THREE.Object3D;
  rightLeg: THREE.Object3D;
  leftArm: THREE.Object3D;
  rightArm: THREE.Object3D;
};

export function createAttackTitan(textures: GameTextures): {
  group: THREE.Group;
  limbs: LimbSet;
  skinMats: THREE.MeshStandardMaterial[];
  nape: THREE.Mesh;
} {
  const group = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({
    color: 0xc45a43,
    roughness: 0.46,
    map: textures.muscle,
  });
  const muscle = new THREE.MeshStandardMaterial({
    color: 0x8a3426,
    roughness: 0.38,
    map: textures.muscle,
  });
  const dark = new THREE.MeshStandardMaterial({ color: 0x6e2418, roughness: 0.5 });
  const hair = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.92 });
  const teeth = new THREE.MeshStandardMaterial({ color: 0xf2eee6, roughness: 0.28 });
  const eye = new THREE.MeshBasicMaterial({ color: 0x3dffc0 });
  const nail = new THREE.MeshStandardMaterial({ color: 0xd8c4b0, roughness: 0.4 });
  const napeMat = new THREE.MeshStandardMaterial({ color: 0x7a1414, roughness: 0.6, emissive: 0x3a0505, emissiveIntensity: 0.4 });
  const skinMats = [skin, muscle, dark];

  const sph = (r: number, seg = 10) => new THREE.SphereGeometry(r, seg, seg);
  const cyl = (t: number, b: number, h: number, seg = 10) => new THREE.CylinderGeometry(t, b, h, seg);
  const box = (x: number, y: number, z: number) => new THREE.BoxGeometry(x, y, z);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-1.15, 6.15, 0);
  group.add(leftLeg);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(1.15, 6.15, 0);
  group.add(rightLeg);

  add(leftLeg, cyl(1.05, 0.78, 3.15, 12), muscle, 0, -1.55, 0.08);
  add(leftLeg, sph(0.7, 10), skin, 0, -3.2, 0.05);
  add(leftLeg, cyl(0.62, 0.48, 2.55, 10), skin, 0, -4.55, 0.02);
  add(leftLeg, sph(0.55, 8), muscle, -0.08, -4.35, -0.22);
  add(leftLeg, sph(0.55, 8), muscle, 0.08, -4.35, -0.22);
  add(leftLeg, box(1.15, 0.38, 2.15), skin, 0, -5.95, 0.42);
  add(leftLeg, box(0.18, 0.1, 0.28), nail, -0.35, -5.82, 1.42);
  add(leftLeg, box(0.18, 0.1, 0.28), nail, 0, -5.82, 1.48);
  add(leftLeg, box(0.18, 0.1, 0.28), nail, 0.35, -5.82, 1.42);

  add(rightLeg, cyl(1.05, 0.78, 3.15, 12), muscle, 0, -1.55, 0.08);
  add(rightLeg, sph(0.7, 10), skin, 0, -3.2, 0.05);
  add(rightLeg, cyl(0.62, 0.48, 2.55, 10), skin, 0, -4.55, 0.02);
  add(rightLeg, sph(0.55, 8), muscle, -0.08, -4.35, -0.22);
  add(rightLeg, sph(0.55, 8), muscle, 0.08, -4.35, -0.22);
  add(rightLeg, box(1.15, 0.38, 2.15), skin, 0, -5.95, 0.42);
  add(rightLeg, box(0.18, 0.1, 0.28), nail, -0.35, -5.82, 1.42);
  add(rightLeg, box(0.18, 0.1, 0.28), nail, 0, -5.82, 1.48);
  add(rightLeg, box(0.18, 0.1, 0.28), nail, 0.35, -5.82, 1.42);

  add(group, sph(1.35, 12), muscle, 0, 6.2, 0, { sx: 1.55, sy: 0.95, sz: 1.15 });
  add(group, sph(0.85, 10), muscle, -0.7, 5.85, -0.55);
  add(group, sph(0.85, 10), muscle, 0.7, 5.85, -0.55);

  const torso = new THREE.Group();
  torso.position.set(0, 6.4, 0);
  torso.rotation.x = 0.06;
  group.add(torso);

  add(torso, cyl(2.05, 1.55, 2.2, 12), skin, 0, 1.4, 0);
  add(torso, cyl(2.7, 2.05, 3.6, 12), skin, 0, 3.9, 0.05);
  add(torso, sph(1.15, 12), muscle, -0.95, 4.85, 1.05, { sx: 1.15, sy: 0.75, sz: 0.7 });
  add(torso, sph(1.15, 12), muscle, 0.95, 4.85, 1.05, { sx: 1.15, sy: 0.75, sz: 0.7 });
  add(torso, box(2.4, 0.18, 0.35), dark, 0, 5.55, 0.9);
  add(torso, box(0.22, 1.6, 0.22), dark, 0, 3.6, 1.15);
  for (let row = 0; row < 3; row++) {
    add(torso, box(1.05, 0.62, 0.7), muscle, -0.62, 2.7 - row * 0.78, 1.12);
    add(torso, box(1.05, 0.62, 0.7), muscle, 0.62, 2.7 - row * 0.78, 1.12);
  }
  add(torso, box(0.7, 1.8, 0.9), muscle, -1.7, 2.6, 0.55, { rz: 0.35 });
  add(torso, box(0.7, 1.8, 0.9), muscle, 1.7, 2.6, 0.55, { rz: -0.35 });
  for (let i = 0; i < 4; i++) {
    add(torso, box(0.55, 0.18, 0.7), dark, -2.05, 3.5 - i * 0.28, 0.7, { rz: 0.4 });
    add(torso, box(0.55, 0.18, 0.7), dark, 2.05, 3.5 - i * 0.28, 0.7, { rz: -0.4 });
  }
  add(torso, sph(1.2, 10), muscle, -1.6, 4.4, -0.55, { sx: 0.9, sy: 1.1, sz: 0.7 });
  add(torso, sph(1.2, 10), muscle, 1.6, 4.4, -0.55, { sx: 0.9, sy: 1.1, sz: 0.7 });
  add(torso, sph(0.85, 8), muscle, -0.55, 5.7, -0.7);
  add(torso, sph(0.85, 8), muscle, 0.55, 5.7, -0.7);
  add(torso, box(0.35, 2.4, 0.3), dark, 0, 3.6, -1.15);

  add(torso, cyl(0.72, 0.9, 1.15, 10), skin, 0, 6.35, 0.15);
  const nape = add(torso, box(0.9, 0.85, 0.38), napeMat, 0, 6.55, -0.85, { name: "nape" });

  const head = new THREE.Group();
  head.position.set(0, 13.35, 0.2);
  group.add(head);
  add(head, sph(1.15, 16), skin, 0, 0.15, 0, { sx: 1.05, sy: 1.28, sz: 1.12 });
  add(head, box(1.7, 0.38, 0.7), dark, 0, 0.42, 0.72);
  add(head, box(0.32, 0.4, 0.5), skin, 0, -0.05, 1.15);
  add(head, box(1.55, 0.55, 1.15), teeth, 0, -0.72, 0.45);
  for (let i = 0; i < 8; i++) {
    add(head, box(0.12, 0.32, 0.1), teeth, -0.7 + i * 0.2, -0.52, 1.0);
  }
  add(head, new THREE.ConeGeometry(0.28, 1.15, 5), skin, -1.15, 0.15, -0.1, { rz: Math.PI / 2.6 });
  add(head, new THREE.ConeGeometry(0.28, 1.15, 5), skin, 1.15, 0.15, -0.1, { rz: -Math.PI / 2.6 });
  add(head, sph(0.2, 8), eye, -0.38, 0.22, 1.05);
  add(head, sph(0.2, 8), eye, 0.38, 0.22, 1.05);
  add(head, sph(0.07, 6), new THREE.MeshBasicMaterial({ color: 0x06120e }), -0.38, 0.22, 1.2);
  add(head, sph(0.07, 6), new THREE.MeshBasicMaterial({ color: 0x06120e }), 0.38, 0.22, 1.2);
  for (let i = 0; i < 11; i++) {
    const spike = add(head, new THREE.ConeGeometry(0.55, 2.8, 5), hair, (i - 5) * 0.28, 1.15, -0.35);
    spike.rotation.x = -0.55 - Math.abs(i - 5) * 0.04;
  }
  add(head, new THREE.ConeGeometry(0.4, 2.2, 5), hair, -0.9, 0.5, -0.2, { rz: 0.5, rx: -0.3 });
  add(head, new THREE.ConeGeometry(0.4, 2.2, 5), hair, 0.9, 0.5, -0.2, { rz: -0.5, rx: -0.3 });

  const leftArm = new THREE.Group();
  leftArm.position.set(-3.35, 11.15, 0);
  group.add(leftArm);
  const rightArm = new THREE.Group();
  rightArm.position.set(3.35, 11.15, 0);
  group.add(rightArm);

  const buildArm = (arm: THREE.Group, side: number) => {
    add(arm, sph(1.35, 12), muscle, 0, 0, 0);
    add(arm, sph(0.7, 8), muscle, side * 0.15, 0.45, -0.35);
    add(arm, cyl(0.85, 0.62, 3.4, 10), skin, side * 0.15, -1.85, 0);
    add(arm, sph(0.7, 8), muscle, side * 0.05, -1.35, 0.45);
    add(arm, sph(0.55, 8), muscle, side * 0.05, -1.55, -0.4);
    add(arm, sph(0.48, 8), skin, 0, -3.55, 0);
    add(arm, cyl(0.55, 0.42, 3.1, 10), skin, 0, -5.05, 0.05);
    add(arm, sph(0.42, 8), muscle, 0, -4.55, 0.28);
    add(arm, box(0.7, 0.45, 1.05), skin, 0, -6.7, 0.15);
    for (let f = 0; f < 4; f++) {
      add(arm, box(0.14, 0.14, 0.55), skin, -0.28 + f * 0.18, -6.7, 0.7);
      add(arm, box(0.12, 0.08, 0.16), nail, -0.28 + f * 0.18, -6.7, 1.0);
    }
  };
  buildArm(leftArm, -1);
  buildArm(rightArm, 1);

  return { group, limbs: { leftLeg, rightLeg, leftArm, rightArm }, skinMats, nape };
}

export function createScout(
  textures: GameTextures,
  cloakHex = 0x3d4f36,
): {
  group: THREE.Group;
  limbs: LimbSet;
  hips: { left: THREE.Object3D; right: THREE.Object3D };
} {
  const group = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: 0xe6c2a0, roughness: 0.55 });
  const coat = new THREE.MeshStandardMaterial({ color: cloakHex, roughness: 0.7 });
  const pants = new THREE.MeshStandardMaterial({ color: 0xd8d4c8, roughness: 0.65 });
  const leather = new THREE.MeshStandardMaterial({ color: 0x3a2418, roughness: 0.6 });
  const steel = new THREE.MeshStandardMaterial({
    color: 0xb8c4cc,
    metalness: 0.85,
    roughness: 0.25,
  });
  const blade = new THREE.MeshStandardMaterial({
    color: 0xe8eef2,
    metalness: 0.95,
    roughness: 0.12,
  });
  const hair = new THREE.MeshStandardMaterial({ color: 0x1a120e, roughness: 0.9 });
  const cloakMat = new THREE.MeshStandardMaterial({
    map: textures.cloak,
    color: cloakHex,
    roughness: 0.75,
    side: THREE.DoubleSide,
  });

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.2, 0.95, 0);
  group.add(leftLeg);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.2, 0.95, 0);
  group.add(rightLeg);
  add(leftLeg, new THREE.CylinderGeometry(0.13, 0.11, 0.95, 8), pants, 0, -0.48, 0);
  add(leftLeg, new THREE.BoxGeometry(0.22, 0.12, 0.4), leather, 0, -0.95, 0.08);
  add(rightLeg, new THREE.CylinderGeometry(0.13, 0.11, 0.95, 8), pants, 0, -0.48, 0);
  add(rightLeg, new THREE.BoxGeometry(0.22, 0.12, 0.4), leather, 0, -0.95, 0.08);

  add(group, new THREE.CylinderGeometry(0.32, 0.28, 0.85, 10), coat, 0, 1.4, 0);
  add(group, new THREE.SphereGeometry(0.26, 12, 12), skin, 0, 2.05, 0);
  add(group, new THREE.SphereGeometry(0.28, 8, 8), hair, 0, 2.18, -0.04, { sy: 0.7, sz: 0.85 });
  add(group, new THREE.PlaneGeometry(0.9, 1.25), cloakMat, 0, 1.35, -0.28);

  const leftArm = new THREE.Group();
  leftArm.position.set(-0.42, 1.7, 0);
  group.add(leftArm);
  const rightArm = new THREE.Group();
  rightArm.position.set(0.42, 1.7, 0);
  group.add(rightArm);
  add(leftArm, new THREE.CylinderGeometry(0.1, 0.08, 0.7, 8), coat, 0, -0.35, 0);
  add(rightArm, new THREE.CylinderGeometry(0.1, 0.08, 0.7, 8), coat, 0, -0.35, 0);

  const hipL = new THREE.Group();
  hipL.position.set(-0.38, 1.05, 0.05);
  group.add(hipL);
  const hipR = new THREE.Group();
  hipR.position.set(0.38, 1.05, 0.05);
  group.add(hipR);
  add(hipL, new THREE.CylinderGeometry(0.12, 0.12, 0.42, 10), steel, 0, 0, 0, { rx: Math.PI / 2 });
  add(hipR, new THREE.CylinderGeometry(0.12, 0.12, 0.42, 10), steel, 0, 0, 0, { rx: Math.PI / 2 });
  add(hipL, new THREE.BoxGeometry(0.05, 0.08, 0.95), blade, 0, 0.15, 0.35);
  add(hipR, new THREE.BoxGeometry(0.05, 0.08, 0.95), blade, 0, 0.15, 0.35);
  add(group, new THREE.BoxGeometry(0.55, 0.18, 0.28), leather, 0, 1.08, 0.18);

  return { group, limbs: { leftLeg, rightLeg, leftArm, rightArm }, hips: { left: hipL, right: hipR } };
}

export type EnemyTitan = {
  group: THREE.Group;
  nape: THREE.Mesh;
  scale: number;
  stunned: number;
  hasLeftArm: boolean;
  hasRightArm: boolean;
  hasLeftLeg: boolean;
  hasRightLeg: boolean;
  speed: number;
  kind: TitanKind;
  hp: number;
  maxHp: number;
  throwCd: number;
  walkT: number;
  limbs: LimbSet;
  special: boolean;
  raid: boolean;
};

function napeMat(): THREE.MeshStandardMaterial {
  return new THREE.MeshStandardMaterial({
    color: 0xff2222,
    emissive: 0x661111,
    emissiveIntensity: 0.65,
    roughness: 0.5,
  });
}

export function createPureTitan(kind: TitanKind = "normal"): EnemyTitan {
  const group = new THREE.Group();
  let s = 0.9 + Math.random() * 0.55;
  let speed = 0.75 + Math.random() * 0.45;
  let hp = 1;
  const skinCol = kind === "fast" ? 0xd08a70 : kind === "plated" ? 0xb56a52 : 0xce7f66;
  const skin = new THREE.MeshStandardMaterial({ color: skinCol, roughness: 0.62 });
  const face = new THREE.MeshStandardMaterial({ color: 0xb5634b, roughness: 0.55 });
  const plate = new THREE.MeshStandardMaterial({
    color: 0x8a7a68,
    roughness: 0.35,
    metalness: 0.45,
  });

  if (kind === "fast") {
    s = 0.7 + Math.random() * 0.2;
    speed = 1.85 + Math.random() * 0.4;
    hp = 1;
  } else if (kind === "plated") {
    s = 1.05 + Math.random() * 0.25;
    speed = 0.48;
    hp = 2;
  } else if (kind === "huge") {
    s = 1.7 + Math.random() * 0.45;
    speed = 0.38;
    hp = 2;
  }

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.65 * s, 3.4 * s, 0);
  leftLeg.name = "leftLeg";
  group.add(leftLeg);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.65 * s, 3.4 * s, 0);
  rightLeg.name = "rightLeg";
  group.add(rightLeg);
  add(leftLeg, new THREE.CylinderGeometry(0.5 * s, 0.34 * s, 3.4 * s, 8), skin, 0, -1.7 * s, 0);
  add(rightLeg, new THREE.CylinderGeometry(0.5 * s, 0.34 * s, 3.4 * s, 8), skin, 0, -1.7 * s, 0);
  add(leftLeg, new THREE.BoxGeometry(0.7 * s, 0.22 * s, 1.1 * s), skin, 0, -3.4 * s, 0.2 * s);
  add(rightLeg, new THREE.BoxGeometry(0.7 * s, 0.22 * s, 1.1 * s), skin, 0, -3.4 * s, 0.2 * s);

  add(group, new THREE.CylinderGeometry(1.25 * s, 0.85 * s, 5.2 * s, 10), skin, 0, 6.0 * s, 0);
  add(group, new THREE.SphereGeometry(1.35 * s, 12, 12), face, 0, 9.15 * s, 0, { sx: 1.1, sy: 1.25, sz: 1.05 });
  const eye = new THREE.MeshBasicMaterial({ color: 0xf5f5f0 });
  const pupil = new THREE.MeshBasicMaterial({ color: 0x111111 });
  add(group, new THREE.SphereGeometry(0.22 * s, 8, 8), eye, -0.42 * s, 9.35 * s, 1.15 * s);
  add(group, new THREE.SphereGeometry(0.22 * s, 8, 8), eye, 0.42 * s, 9.35 * s, 1.15 * s);
  add(group, new THREE.SphereGeometry(0.1 * s, 6, 6), pupil, -0.42 * s, 9.35 * s, 1.32 * s);
  add(group, new THREE.SphereGeometry(0.1 * s, 6, 6), pupil, 0.42 * s, 9.35 * s, 1.32 * s);
  add(group, new THREE.BoxGeometry(1.4 * s, 0.28 * s, 0.7 * s), face, 0, 8.55 * s, 0.9 * s);

  const nape = add(
    group,
    new THREE.BoxGeometry(0.85 * s, 0.85 * s, 0.35 * s),
    napeMat(),
    0,
    9.05 * s,
    -1.25 * s,
    { name: "nape", cast: false },
  );

  const leftArm = new THREE.Group();
  leftArm.position.set(-1.7 * s, 7.6 * s, 0);
  leftArm.name = "leftArm";
  group.add(leftArm);
  const rightArm = new THREE.Group();
  rightArm.position.set(1.7 * s, 7.6 * s, 0);
  rightArm.name = "rightArm";
  group.add(rightArm);
  add(leftArm, new THREE.CylinderGeometry(0.48 * s, 0.38 * s, 3.6 * s, 8), skin, 0, -1.7 * s, 0);
  add(rightArm, new THREE.CylinderGeometry(0.48 * s, 0.38 * s, 3.6 * s, 8), skin, 0, -1.7 * s, 0);

  if (kind === "plated") {
    add(group, new THREE.BoxGeometry(2.4 * s, 2.2 * s, 0.35 * s), plate, 0, 7.2 * s, 1.15 * s);
    add(group, new THREE.BoxGeometry(1.6 * s, 1.4 * s, 0.3 * s), plate, 0, 9.1 * s, 1.2 * s);
    add(leftArm, new THREE.BoxGeometry(0.7 * s, 1.6 * s, 0.28 * s), plate, 0, -1.2 * s, 0.35 * s);
    add(rightArm, new THREE.BoxGeometry(0.7 * s, 1.6 * s, 0.28 * s), plate, 0, -1.2 * s, 0.35 * s);
  }
  if (kind === "fast") {
    leftArm.rotation.z = 0.35;
    rightArm.rotation.z = -0.35;
  }
  if (kind === "huge") {
    add(group, new THREE.SphereGeometry(1.7 * s, 10, 10), face, 0, 9.4 * s, 0.1 * s, { sy: 1.15 });
  }

  return {
    group,
    nape,
    scale: s,
    stunned: 0,
    hasLeftArm: true,
    hasRightArm: true,
    hasLeftLeg: true,
    hasRightLeg: true,
    speed,
    kind,
    hp,
    maxHp: hp,
    throwCd: 0,
    walkT: Math.random() * 10,
    limbs: { leftLeg, rightLeg, leftArm, rightArm },
    special: false,
    raid: false,
  };
}

export function createSpecialTitan(kind: "armored" | "female" | "jaw" | "beast"): EnemyTitan {
  const group = new THREE.Group();
  let s = 1.35;
  let speed = 0.7;
  let hp = 4;
  const skin = new THREE.MeshStandardMaterial({ color: 0xc56a52, roughness: 0.5 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x7a3a28, roughness: 0.45 });
  const plate = new THREE.MeshStandardMaterial({
    color: 0x6a5a48,
    metalness: 0.55,
    roughness: 0.32,
  });
  const crystal = new THREE.MeshStandardMaterial({
    color: 0x9ad4e8,
    metalness: 0.4,
    roughness: 0.18,
    transparent: true,
    opacity: 0.85,
  });
  const fur = new THREE.MeshStandardMaterial({ color: 0x4a3424, roughness: 0.92 });
  const hair = new THREE.MeshStandardMaterial({ color: 0xd8c46a, roughness: 0.7 });

  if (kind === "armored") {
    s = 1.55;
    speed = 0.62;
    hp = 5;
    add(group, new THREE.CylinderGeometry(2.1 * s, 1.5 * s, 6.4 * s, 10), skin, 0, 5.8 * s, 0);
    add(group, new THREE.BoxGeometry(3.6 * s, 3.8 * s, 2.6 * s), plate, 0, 6.4 * s, 0.15 * s);
    add(group, new THREE.BoxGeometry(2.4 * s, 2.2 * s, 2.2 * s), plate, 0, 10.2 * s, 0.2 * s);
    add(group, new THREE.SphereGeometry(1.2 * s, 10, 10), dark, 0, 11.6 * s, 0.15 * s);
    for (const x of [-1.4, 1.4]) {
      add(group, new THREE.BoxGeometry(1.5 * s, 4.4 * s, 1.5 * s), plate, x * s, 3.2 * s, 0);
    }
  } else if (kind === "female") {
    s = 1.25;
    speed = 1.55;
    hp = 4;
    add(group, new THREE.CylinderGeometry(1.15 * s, 0.72 * s, 6.2 * s, 10), skin, 0, 5.4 * s, 0);
    add(group, new THREE.SphereGeometry(1.05 * s, 12, 12), skin, 0, 9.1 * s, 0, { sy: 1.2 });
    add(group, new THREE.ConeGeometry(1.1 * s, 2.4 * s, 8), hair, 0, 10.3 * s, -0.15 * s);
    add(group, new THREE.BoxGeometry(1.8 * s, 1.6 * s, 0.22 * s), crystal, 0, 6.4 * s, 1.05 * s);
  } else if (kind === "jaw") {
    s = 0.72;
    speed = 2.35;
    hp = 3;
    add(group, new THREE.CylinderGeometry(1.05 * s, 0.8 * s, 3.6 * s, 10), skin, 0, 3.6 * s, 0);
    add(group, new THREE.SphereGeometry(1.35 * s, 10, 10), dark, 0, 5.9 * s, 0.35 * s, { sx: 1.25, sy: 0.9, sz: 1.35 });
    add(group, new THREE.BoxGeometry(2.2 * s, 0.7 * s, 1.8 * s), dark, 0, 5.35 * s, 0.9 * s);
    const teeth = new THREE.MeshStandardMaterial({ color: 0xf2eee6, roughness: 0.3 });
    for (let i = 0; i < 6; i++) {
      add(group, new THREE.ConeGeometry(0.12 * s, 0.55 * s, 4), teeth, (-0.7 + i * 0.28) * s, 5.15 * s, 1.6 * s, { rx: Math.PI });
    }
  } else {
    s = 1.7;
    speed = 0.42;
    hp = 4;
    add(group, new THREE.SphereGeometry(2.4 * s, 12, 10), fur, 0, 4.6 * s, 0, { sy: 1.15, sz: 0.9 });
    add(group, new THREE.SphereGeometry(1.5 * s, 10, 10), fur, 0, 8.2 * s, 0.4 * s);
    add(group, new THREE.SphereGeometry(0.35 * s, 8, 8), new THREE.MeshBasicMaterial({ color: 0xeedd88 }), -0.45 * s, 8.4 * s, 1.55 * s);
    add(group, new THREE.SphereGeometry(0.35 * s, 8, 8), new THREE.MeshBasicMaterial({ color: 0xeedd88 }), 0.45 * s, 8.4 * s, 1.55 * s);
  }

  const leftLeg = new THREE.Group();
  leftLeg.position.set(-0.85 * s, 2.6 * s, 0);
  leftLeg.name = "leftLeg";
  group.add(leftLeg);
  const rightLeg = new THREE.Group();
  rightLeg.position.set(0.85 * s, 2.6 * s, 0);
  rightLeg.name = "rightLeg";
  group.add(rightLeg);
  const legH = kind === "beast" ? 3.2 * s : 3.8 * s;
  add(leftLeg, new THREE.CylinderGeometry(0.55 * s, 0.4 * s, legH, 8), kind === "beast" ? fur : skin, 0, -legH / 2, 0);
  add(rightLeg, new THREE.CylinderGeometry(0.55 * s, 0.4 * s, legH, 8), kind === "beast" ? fur : skin, 0, -legH / 2, 0);

  const leftArm = new THREE.Group();
  leftArm.position.set(-(kind === "beast" ? 2.4 : 1.9) * s, (kind === "beast" ? 6.2 : 7.4) * s, 0);
  leftArm.name = "leftArm";
  group.add(leftArm);
  const rightArm = new THREE.Group();
  rightArm.position.set((kind === "beast" ? 2.4 : 1.9) * s, (kind === "beast" ? 6.2 : 7.4) * s, 0);
  rightArm.name = "rightArm";
  group.add(rightArm);
  const armH = kind === "beast" ? 5.2 * s : 3.8 * s;
  add(leftArm, new THREE.CylinderGeometry(0.48 * s, 0.38 * s, armH, 8), kind === "beast" ? fur : skin, 0, -armH / 2, 0);
  add(rightArm, new THREE.CylinderGeometry(0.48 * s, 0.38 * s, armH, 8), kind === "beast" ? fur : skin, 0, -armH / 2, 0);
  if (kind === "armored") {
    add(leftArm, new THREE.BoxGeometry(0.9 * s, armH * 0.7, 0.4 * s), plate, 0, -armH * 0.3, 0.2 * s);
    add(rightArm, new THREE.BoxGeometry(0.9 * s, armH * 0.7, 0.4 * s), plate, 0, -armH * 0.3, 0.2 * s);
  }

  const napeY = kind === "jaw" ? 5.8 * s : kind === "beast" ? 8.6 * s : 9.4 * s;
  const nape = add(
    group,
    new THREE.BoxGeometry(0.9 * s, 0.8 * s, 0.4 * s),
    napeMat(),
    0,
    napeY,
    -1.35 * s,
    { name: "nape", cast: false },
  );

  return {
    group,
    nape,
    scale: s,
    stunned: 0,
    hasLeftArm: true,
    hasRightArm: true,
    hasLeftLeg: true,
    hasRightLeg: true,
    speed,
    kind,
    hp,
    maxHp: hp,
    throwCd: kind === "beast" ? 1.5 : 0,
    walkT: 0,
    limbs: { leftLeg, rightLeg, leftArm, rightArm },
    special: true,
    raid: false,
  };
}

export type Horse = {
  group: THREE.Group;
  occupied: boolean;
};

export function createHorse(): Horse {
  const group = new THREE.Group();
  const hide = new THREE.MeshStandardMaterial({ color: 0x4a3424, roughness: 0.8 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x1a120e, roughness: 0.7 });
  const leather = new THREE.MeshStandardMaterial({ color: 0x5a3a22, roughness: 0.6 });
  add(group, new THREE.BoxGeometry(0.55, 0.7, 1.35), hide, 0, 0.95, 0);
  add(group, new THREE.BoxGeometry(0.32, 0.55, 0.4), hide, 0, 1.35, 0.72);
  add(group, new THREE.BoxGeometry(0.28, 0.22, 0.38), hide, 0, 1.28, 1.05);
  add(group, new THREE.BoxGeometry(0.08, 0.35, 0.08), dark, 0, 1.05, -0.72);
  add(group, new THREE.BoxGeometry(0.5, 0.12, 0.55), leather, 0, 1.32, -0.05);
  const legs: [number, number][] = [
    [-0.18, 0.45],
    [0.18, 0.45],
    [-0.18, -0.45],
    [0.18, -0.45],
  ];
  for (const [x, z] of legs) {
    add(group, new THREE.BoxGeometry(0.12, 0.7, 0.12), dark, x, 0.35, z);
  }
  return { group, occupied: false };
}

export const SPECIAL_NAMES: Record<string, string> = {
  armored: "Zırhlı Titan",
  female: "Dişi Titan",
  jaw: "Çene Titanı",
  beast: "Canavar Titan",
  fast: "Anormal (hızlı)",
  plated: "Zırhlı saf",
  huge: "Dev saf",
  normal: "Saf Dev",
};
