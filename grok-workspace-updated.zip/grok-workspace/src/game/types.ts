export type TeamId = "scout" | "garrison" | "mp";

export type TitanKind = "normal" | "fast" | "plated" | "huge" | "armored" | "female" | "jaw" | "beast";

export type QuestHud = {
  title: string;
  desc: string;
  progress: number;
  target: number;
  gold: number;
};

export type ShopItem = {
  id: string;
  name: string;
  desc: string;
  cost: number;
  owned: number;
  cap: number;
};

export type HudState = {
  energy: number;
  energyMax: number;
  gas: number;
  gasMax: number;
  blades: number;
  bladeMax: number;
  kills: number;
  gold: number;
  level: number;
  xp: number;
  xpNext: number;
  isTitan: boolean;
  isHardened: boolean;
  district: string;
  mode: string;
  sprinting: boolean;
  hooked: boolean;
  mounted: boolean;
  nearHorse: boolean;
  nearSupply: boolean;
  isNight: boolean;
  clock: string;
  px: number;
  pz: number;
  yaw: number;
  titans: { x: number; z: number; kind: TitanKind }[];
  quest: QuestHud | null;
  raid: { name: string; left: number } | null;
  toast: string;
  squadAlive: number;
  team: TeamId;
  shop: ShopItem[];
  titanUnlocked: boolean;
  titanPower: string | null;
  titanRarity: "COMMON" | "RARE" | "EPIC" | "LEGENDARY" | "MYTHIC" | null;
  raidPity: number;
};

export type GameHandle = {
  dispose: () => void;
  start: () => void;
  pause: () => void;
  resume: () => void;
  pulse: (action: GameAction) => void;
  setSprintToggle: (on: boolean) => void;
  setJoystick: (x: number, y: number, active: boolean) => void;
  addLook: (dx: number, dy: number) => void;
  setTeam: (team: TeamId) => void;
  buy: (id: string) => boolean;
};

export type GameAction =
  | "hook"
  | "attack"
  | "transform"
  | "heal"
  | "roar"
  | "harden"
  | "sprint"
  | "mount";

export const WALLS = {
  sina: 150,
  rose: 270,
  maria: 410,
} as const;

export const WORLD_SIZE = 1100;

export const TEAMS: Record<TeamId, { name: string; bonus: string; cloak: number }> = {
  scout: { name: "Keşif Birliği", bonus: "ODM itiş +", cloak: 0x3d4f36 },
  garrison: { name: "Garnizon", bonus: "Bıçak dayanıklılığı +", cloak: 0x5c4a32 },
  mp: { name: "Askeri Polis", bonus: "Para kazancı +", cloak: 0x3a3f55 },
};
