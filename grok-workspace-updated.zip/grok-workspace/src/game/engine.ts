import * as THREE from "three";
import { Input } from "./input";
import { GameAudio } from "./audio";
import { createTextures, disposeTextures, type GameTextures } from "./textures";
import {
  createAttackTitan,
  createScout,
  createPureTitan,
  createSpecialTitan,
  createHorse,
  SPECIAL_NAMES,
  type EnemyTitan,
  type Horse,
  type LimbSet,
} from "./models";
import { createWorld, scatterGrass, type World } from "./world";
import { WALLS, TEAMS, type GameAction, type GameHandle, type HudState, type TeamId, type TitanKind } from "./types";
import {
  loadProgress,
  saveProgress,
  addXp,
  goldMul,
  gasMax,
  bladeMax,
  energyMax,
  odmForce,
  horseSpeed,
  shopCatalog,
  buyUpgrade,
  xpForLevel,
  type Progress,
} from "./progress";
import { makeQuest, inMitras, type Quest } from "./quests";

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _bg = new THREE.Color();
const _fogDay = new THREE.Color(0xa9c3d4);
const _fogNight = new THREE.Color(0x12161c);
const PURE_KINDS: TitanKind[] = ["normal", "normal", "normal", "fast", "fast", "plated", "huge"];
const SPECIALS: Array<"armored" | "female" | "jaw" | "beast"> = ["armored", "female", "jaw", "beast"];

type Hook = {
  flying: boolean;
  attached: boolean;
  pos: THREE.Vector3;
  target: THREE.Vector3;
  cable: THREE.Mesh;
  tip: THREE.Mesh;
};

type Particle = {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
  steam: boolean;
};

type Rock = {
  mesh: THREE.Mesh;
  vel: THREE.Vector3;
  life: number;
};

type Ally = {
  scout: ReturnType<typeof createScout>;
  hp: number;
  offset: THREE.Vector3;
  walkT: number;
};

export function createGame(
  canvas: HTMLCanvasElement,
  onHud: (s: HudState) => void,
  flash: { lightning: HTMLElement | null; impact: HTMLElement | null },
): GameHandle {
  const quality: "high" | "low" =
    window.innerWidth < 700 || matchMedia("(pointer: coarse)").matches ? "low" : "high";

  const textures: GameTextures = createTextures();
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, 1, 0.15, 900);
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: quality === "high",
    powerPreference: "high-performance",
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, quality === "high" ? 2 : 1.35));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = quality === "high" ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;

  const world: World = createWorld(scene, textures, quality);

  const progress: Progress = loadProgress();
  const scout = createScout(textures, TEAMS[progress.team].cloak);
  scene.add(scout.group);
  const titan = createAttackTitan(textures);
  titan.group.visible = false;
  scene.add(titan.group);

  scout.group.position.set(0, 0, WALLS.maria - 55);
  titan.group.position.copy(scout.group.position);

  const input = new Input();
  input.attach(canvas);
  const audio = new GameAudio();

  const boltLight = new THREE.PointLight(0xfff3c0, 0, 80, 2);
  scene.add(boltLight);

  const ringGeo = new THREE.RingGeometry(0.6, 1.1, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: 0xffcc66,
    transparent: true,
    opacity: 0,
    side: THREE.DoubleSide,
  });
  const shockwave = new THREE.Mesh(ringGeo, ringMat);
  shockwave.rotation.x = -Math.PI / 2;
  shockwave.visible = false;
  scene.add(shockwave);
  let shockT = 0;

  const enemies: EnemyTitan[] = [];
  const horses: Horse[] = [];
  world.horseSpawns.forEach((p) => {
    const h = createHorse();
    h.group.position.copy(p);
    scene.add(h.group);
    horses.push(h);
  });

  const allies: Ally[] = [];
  const spawnAlly = (ox: number, oz: number) => {
    const s = createScout(textures, TEAMS[progress.team].cloak);
    s.group.position.set(scout.group.position.x + ox, 0, scout.group.position.z + oz);
    scene.add(s.group);
    allies.push({ scout: s, hp: 100, offset: new THREE.Vector3(ox, 0, oz), walkT: Math.random() * 4 });
  };

  const pickPureKind = (): TitanKind => PURE_KINDS[Math.floor(Math.random() * PURE_KINDS.length)];

  const spawnEnemy = (rMin: number, rMax: number, raid = false, kind?: TitanKind) => {
    const k = kind ?? pickPureKind();
    const e = k === "armored" || k === "female" || k === "jaw" || k === "beast" ? createSpecialTitan(k) : createPureTitan(k);
    const a = Math.random() * Math.PI * 2;
    const r = rMin + Math.random() * (rMax - rMin);
    e.group.position.set(Math.sin(a) * r, 0, Math.cos(a) * r);
    e.raid = raid;
    scene.add(e.group);
    world.hookables.push(e.group);
    enemies.push(e);
    return e;
  };

  for (let i = 0; i < 5; i++) spawnEnemy(WALLS.maria + 20, WALLS.maria + 90);
  for (let i = 0; i < 4; i++) spawnEnemy(WALLS.rose + 30, WALLS.maria - 30);
  for (let i = 0; i < 2; i++) spawnEnemy(WALLS.sina + 25, WALLS.rose - 25);

  const cableMat = new THREE.MeshStandardMaterial({
    color: 0xdde4ea,
    metalness: 0.9,
    roughness: 0.25,
  });
  const cableGeo = new THREE.CylinderGeometry(0.035, 0.035, 1, 5);
  const tipGeo = new THREE.ConeGeometry(0.08, 0.28, 6);
  const makeHook = (): Hook => {
    const cable = new THREE.Mesh(cableGeo, cableMat);
    const tip = new THREE.Mesh(tipGeo, cableMat);
    cable.visible = false;
    tip.visible = false;
    scene.add(cable, tip);
    return { flying: false, attached: false, pos: new THREE.Vector3(), target: new THREE.Vector3(), cable, tip };
  };
  const hooks: [Hook, Hook] = [makeHook(), makeHook()];

  const pGeo = new THREE.SphereGeometry(0.28, 6, 6);
  const particles: Particle[] = [];
  for (let i = 0; i < 180; i++) {
    const mesh = new THREE.Mesh(
      pGeo,
      new THREE.MeshBasicMaterial({ color: 0xeeeeee, transparent: true, opacity: 0.7 }),
    );
    mesh.visible = false;
    scene.add(mesh);
    particles.push({ mesh, vel: new THREE.Vector3(), life: 0, steam: false });
  }

  const rockGeo = new THREE.SphereGeometry(0.7, 6, 6);
  const rockMat = new THREE.MeshStandardMaterial({ color: 0x6a655c, roughness: 0.9 });
  const rocks: Rock[] = [];

  const raycaster = new THREE.Raycaster();
  raycaster.far = 200;

  let started = false;
  let paused = false;
  let isTitan = false;
  let isHardened = false;
  let energy = energyMax(progress);
  let gas = gasMax(progress);
  let blades = bladeMax(progress);
  let kills = progress.kills;
  let yaw = 0;
  let pitch = 0.12;
  let camYaw = Math.PI;
  let vel = new THREE.Vector3();
  let walkT = 0;
  let trauma = 0;
  let hitstop = 0;
  let attackT = 0;
  let grassAt = new THREE.Vector3(999, 0, 999);
  let hudAcc = 0;
  let last = performance.now();
  let running = true;
  let fov = 60;
  let tod = 0.38;
  let toast = "";
  let toastT = 0;
  let questIndex = 0;
  let quest: Quest = makeQuest(0, progress.level);
  let raid: { name: string; x: number; z: number; left: number; spawned: number } | null = null;
  let raidCd = 42;
  let specialCd = 28;
  let mounted: Horse | null = null;
  let nightKills = 0;
  const WORLD_LIMIT = 520;
  const titanRest = titan.skinMats.map((m) => ({
    color: m.color.getHex(),
    metal: m.metalness,
    rough: m.roughness,
  }));

  let drag: { id: number; x: number; y: number } | null = null;

  scatterGrass(world.grass, world.grassCount, scout.group.position.x, scout.group.position.z, 48);

  const resize = () => {
    const w = canvas.clientWidth || window.innerWidth;
    const h = canvas.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
  };
  resize();
  window.addEventListener("resize", resize);
  const ro = new ResizeObserver(resize);
  ro.observe(canvas.parentElement ?? canvas);

  const say = (msg: string) => {
    toast = msg;
    toastT = 3.4;
  };

  const persist = () => {
    progress.kills = kills;
    saveProgress(progress);
  };

  const emit = (pos: THREE.Vector3, color: number, n: number, steam = false) => {
    let left = n;
    for (const p of particles) {
      if (left <= 0) break;
      if (p.life > 0) continue;
      p.life = steam ? 0.7 : 0.45;
      p.steam = steam;
      p.mesh.visible = true;
      (p.mesh.material as THREE.MeshBasicMaterial).color.setHex(color);
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = steam ? 0.55 : 0.9;
      p.mesh.scale.setScalar(steam ? 1.2 : 0.7);
      p.mesh.position.copy(pos).add(_v1.set((Math.random() - 0.5) * 1.4, Math.random() * 1.2, (Math.random() - 0.5) * 1.4));
      p.vel.set((Math.random() - 0.5) * (steam ? 1.2 : 6), 1 + Math.random() * (steam ? 2 : 5), (Math.random() - 0.5) * (steam ? 1.2 : 6));
      left--;
    }
  };

  const placeCable = (hook: Hook, from: THREE.Vector3, to: THREE.Vector3) => {
    const len = from.distanceTo(to);
    hook.cable.visible = true;
    hook.tip.visible = true;
    hook.cable.position.lerpVectors(from, to, 0.5);
    hook.cable.scale.set(1, Math.max(0.1, len), 1);
    _v1.subVectors(to, from).normalize();
    hook.cable.quaternion.setFromUnitVectors(_up, _v1);
    hook.tip.position.copy(to);
    hook.tip.quaternion.copy(hook.cable.quaternion);
  };

  const clearHooks = () => {
    for (const h of hooks) {
      h.flying = false;
      h.attached = false;
      h.cable.visible = false;
      h.tip.visible = false;
    }
  };

  const active = () => (isTitan ? titan.group : scout.group);
  const limbs = (): LimbSet => (isTitan ? titan.limbs : scout.limbs);

  const districtOf = (x: number, z: number) => {
    const r = Math.hypot(x, z);
    if (r < WALLS.sina - 8) return "Mitras  ·  Sur Sina";
    if (Math.hypot(x, z - (WALLS.rose - 48)) < 55 && r < WALLS.rose) return "Trost  ·  Sur Rose";
    if (r < WALLS.rose - 8) return "Sina — Rose arası";
    if (Math.abs(z - (WALLS.maria - 55)) < 70 && Math.abs(x) < 70 && r < WALLS.maria) return "Shiganshina  ·  Sur Maria";
    if (r < WALLS.maria - 8) return "Rose — Maria arası";
    return "Maria'nın ötesi";
  };

  const clockLabel = () => {
    if (tod < 0.22) return "Gece";
    if (tod < 0.32) return "Şafak";
    if (tod < 0.68) return "Gündüz";
    if (tod < 0.78) return "Akşam";
    return "Gece";
  };

  const isNight = () => tod < 0.22 || tod > 0.78;

  const nearSupply = () => {
    const p = active().position;
    return world.supplies.some((s) => p.distanceTo(s) < 8);
  };

  const nearestHorse = (): Horse | null => {
    const p = scout.group.position;
    let best: Horse | null = null;
    let d = 4.2;
    for (const h of horses) {
      if (h.occupied) continue;
      const dist = p.distanceTo(h.group.position);
      if (dist < d) {
        d = dist;
        best = h;
      }
    }
    return best;
  };

  const wallPush = (pos: THREE.Vector3, radius: number) => {
    const r = Math.hypot(pos.x, pos.z);
    if (pos.y > 52) return;
    for (const wr of [WALLS.sina, WALLS.rose, WALLS.maria]) {
      const inner = wr - 6 - radius;
      const outer = wr + 6 + radius;
      if (r > inner && r < outer) {
        const ang = Math.atan2(pos.x, pos.z);
        if (Math.abs(ang) < 0.13) continue;
        const mid = (inner + outer) / 2;
        const target = r < mid ? inner : outer;
        pos.x = Math.sin(ang) * target;
        pos.z = Math.cos(ang) * target;
      }
    }
  };

  const dismount = () => {
    if (!mounted) return;
    mounted.occupied = false;
    scout.group.position.y = 0;
    mounted = null;
  };

  const fireHooks = () => {
    if (isTitan || gas < 8) return;
    if (mounted) dismount();
    gas -= 8;
    audio.gas();
    const origin = active().position.clone().add(_v1.set(0, 1.2, 0));
    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
    const hits = raycaster.intersectObjects(world.hookables, true);
    let target: THREE.Vector3;
    if (hits.length && hits[0].distance < 180 && hits[0].point.y > 1.2) {
      target = hits[0].point.clone();
    } else {
      camera.getWorldDirection(_v2);
      vel.addScaledVector(_v2, 18);
      emit(origin, 0xcccccc, 8, true);
      return;
    }
    const hips = [scout.hips.left, scout.hips.right];
    hips.forEach((hip, i) => {
      hip.getWorldPosition(hooks[i].pos);
      hooks[i].target.copy(target).add(_v3.set(i === 0 ? -1.2 : 1.2, 0, 0));
      hooks[i].flying = true;
      hooks[i].attached = false;
    });
    emit(origin, 0xcccccc, 10, true);
  };

  const completeQuestIf = (type: Quest["type"], amount = 1) => {
    if (quest.type !== type) return;
    quest.progress = Math.min(quest.target, quest.progress + amount);
    if (quest.progress >= quest.target) {
      const g = Math.round(quest.gold * goldMul(progress));
      progress.gold += g;
      const leveled = addXp(progress, quest.xp);
      audio.coin();
      say(`${quest.title} tamam · +${g} para` + (leveled ? " · Seviye atladın" : ""));
      questIndex += 1;
      quest = makeQuest(questIndex, progress.level);
      persist();
    }
  };

  const killEnemy = (e: EnemyTitan, i: number) => {
    emit(e.nape.getWorldPosition(_v2), 0xaa1111, 28);
    emit(_v2, 0xeeeeee, 18, true);
    trauma = Math.min(1, trauma + 0.55);
    hitstop = 0.07;
    if (flash.impact) {
      flash.impact.style.opacity = "1";
      setTimeout(() => {
        if (flash.impact) flash.impact.style.opacity = "0";
      }, 110);
    }
    const wasRaid = e.raid;
    const wasSpecial = e.special;
    scene.remove(e.group);
    const hi = world.hookables.indexOf(e.group);
    if (hi >= 0) world.hookables.splice(hi, 1);
    enemies.splice(i, 1);
    kills++;
    const pay = Math.round((wasSpecial ? 55 : 12 + e.scale * 6) * goldMul(progress));
    progress.gold += pay;
    addXp(progress, wasSpecial ? 40 : 12);
    energy = Math.min(energyMax(progress), energy + (isTitan ? 8 : 18));
    completeQuestIf("kills");
    if (wasSpecial) completeQuestIf("special");
    if (isNight()) {
      nightKills++;
      completeQuestIf("night");
    }
    persist();
    if (wasRaid && !enemies.some((x) => x.raid)) {
      if (raid) {
        const raidGold = Math.round((80 + progress.level * 18) * goldMul(progress));
        progress.gold += raidGold;
        addXp(progress, 70 + progress.level * 8);
        const unlocked = rollTitanReward();
        say(unlocked
          ? `${raid.name} tamamlandı · +${raidGold} para · ${progress.titanRarity} Titan gücü kazandın!`
          : `${raid.name} tamamlandı · +${raidGold} para · Titan gücü şansı arttı (${progress.raidPity}/10)`);
        completeQuestIf("defend");
        raid = null;
        persist();
      }
    }
    const delay = wasSpecial ? 18000 : 2600;
    setTimeout(() => {
      if (!running) return;
      spawnEnemy(WALLS.maria + 30, WALLS.maria + 110);
    }, delay);
  };

  const doAttack = () => {
    attackT = 0.28;
    const pos = active().position;
    if (!isTitan) {
      if (blades < 6) {
        audio.drySlash();
        say("Bıçaklar kırık — ikmal sandığına git");
        return;
      }
      blades = Math.max(0, blades - (8 + Math.random() * 4));
    }
    audio.slash();
    if (!isTitan) emit(pos.clone().add(_v1.set(0, 1.4, 0)), 0x88e0ff, 12);
    const range = isTitan ? (isHardened ? 28 : 20) : 9;

    for (let i = enemies.length - 1; i >= 0; i--) {
      const e = enemies[i];
      const dist = pos.distanceTo(e.group.position);
      if (dist > range + e.scale * 4) continue;
      e.nape.getWorldPosition(_v2);
      const napeDist = pos.distanceTo(_v2);
      const behind = napeDist < (isTitan ? 12 : 5.5) || (isTitan && isHardened);
      if (behind) {
        e.hp -= isTitan ? (isHardened ? 2 : 1) : 1;
        if (e.hp <= 0) killEnemy(e, i);
        else {
          emit(_v2, 0xaa1111, 16);
          e.stunned = 1.2;
          say(`${SPECIAL_NAMES[e.kind] ?? "Dev"}  ${e.hp}/${e.maxHp}`);
        }
      } else {
        const names = ["leftArm", "rightArm", "leftLeg", "rightLeg"] as const;
        const avail = names.filter((n) => {
          if (n === "leftArm") return e.hasLeftArm;
          if (n === "rightArm") return e.hasRightArm;
          if (n === "leftLeg") return e.hasLeftLeg;
          return e.hasRightLeg;
        });
        if (!avail.length) continue;
        const pick = avail[Math.floor(Math.random() * avail.length)];
        const child = e.group.getObjectByName(pick);
        if (child) {
          child.getWorldPosition(_v3);
          emit(_v3, 0xaa1111, 16);
          child.visible = false;
        }
        if (pick === "leftArm") e.hasLeftArm = false;
        if (pick === "rightArm") e.hasRightArm = false;
        if (pick === "leftLeg") e.hasLeftLeg = false;
        if (pick === "rightLeg") e.hasRightLeg = false;
      }
    }
    if (isTitan) {
      audio.roar();
      trauma = Math.min(1, trauma + (isHardened ? 0.5 : 0.32));
      emit(titan.group.position.clone().add(_v1.set(0, 8, 0)), isHardened ? 0x00e5ff : 0xffcc44, 22);
    }
  };

  const spawnBolt = (pos: THREE.Vector3) => {
    for (let b = 0; b < 4; b++) {
      const pts: THREE.Vector3[] = [];
      const cur = new THREE.Vector3(pos.x + (Math.random() - 0.5) * 8, pos.y + 140, pos.z + (Math.random() - 0.5) * 8);
      pts.push(cur.clone());
      while (cur.y > pos.y) {
        cur.y -= 10 + Math.random() * 8;
        cur.x += (Math.random() - 0.5) * 14;
        cur.z += (Math.random() - 0.5) * 14;
        pts.push(cur.clone());
      }
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({ color: b % 2 ? 0xfff1a8 : 0xaee7ff }),
      );
      scene.add(line);
      setTimeout(() => {
        scene.remove(line);
        line.geometry.dispose();
        (line.material as THREE.Material).dispose();
      }, 320);
    }
    boltLight.position.copy(pos).setY(pos.y + 10);
    boltLight.intensity = 18;
  };

  const transform = () => {
    audio.unlock();
    if (!progress.titanUnlocked) {
      say("Titan gücü kilitli — Raid yap ve nadir ödülü kazan");
      return;
    }
    if (!isTitan) {
      if (energy < 22) {
        say("Enerji yetersiz");
        return;
      }
      if (mounted) dismount();
      isTitan = true;
      titan.group.position.copy(scout.group.position);
      titan.group.rotation.y = scout.group.rotation.y;
      scout.group.visible = false;
      titan.group.visible = true;
      clearHooks();
      audio.thunder();
      audio.roar();
      trauma = 0.9;
      if (flash.lightning) {
        flash.lightning.style.opacity = "0.92";
        setTimeout(() => {
          if (flash.lightning) flash.lightning.style.opacity = "0";
        }, 180);
      }
      spawnBolt(titan.group.position);
      emit(titan.group.position.clone().add(_v1.set(0, 6, 0)), 0x88ffff, 48);
      say("Saldırı Devi");
    } else {
      isTitan = false;
      isHardened = false;
      titan.skinMats.forEach((m, i) => {
        m.color.setHex(titanRest[i].color);
        m.metalness = titanRest[i].metal;
        m.roughness = titanRest[i].rough;
      });
      scout.group.position.copy(titan.group.position);
      scout.group.position.y = Math.max(0, titan.group.position.y);
      titan.group.visible = false;
      scout.group.visible = true;
      emit(scout.group.position.clone().add(_v1.set(0, 4, 0)), 0xeeeeee, 50, true);
      vel.set(0, 2.5, 0);
    }
  };

  const harden = () => {
    if (!isTitan) return;
    isHardened = !isHardened;
    titan.skinMats.forEach((m, i) => {
      if (isHardened) {
        m.color.setHex(0x7ad8e8);
        m.metalness = 0.85;
        m.roughness = 0.12;
      } else {
        m.color.setHex(titanRest[i].color);
        m.metalness = titanRest[i].metal;
        m.roughness = titanRest[i].rough;
      }
    });
    emit(titan.group.position.clone().add(_v1.set(0, 8, 0)), 0x00e5ff, 24);
  };

  const roar = () => {
    if (!isTitan) return;
    audio.roar();
    trauma = 0.85;
    const origin = titan.group.position;
    enemies.forEach((e) => {
      if (origin.distanceTo(e.group.position) < 52) {
        _v1.subVectors(e.group.position, origin).setY(0).normalize();
        e.group.position.addScaledVector(_v1, 14);
        e.stunned = 3.2;
      }
    });
    emit(origin.clone().add(_v1.set(0, 4, 0)), 0xffaa33, 36);
    shockwave.position.set(origin.x, 0.2, origin.z);
    shockwave.scale.setScalar(1);
    ringMat.opacity = 0.7;
    shockwave.visible = true;
    shockT = 0.9;
    spawnBolt(origin);
  };

  const heal = () => {
    const p = active().position;
    emit(p.clone().add(_v1.set(0, 2, 0)), 0xeeeeee, 24, true);
    if (nearSupply()) {
      energy = energyMax(progress);
      gas = gasMax(progress);
      blades = bladeMax(progress);
      say("İkmal alındı");
      audio.coin();
    } else {
      energy = Math.min(energyMax(progress), energy + 18);
      gas = Math.min(gasMax(progress), gas + 14);
      say("Şehirde ikmal sandığı daha doldurur");
    }
  };

  const toggleMount = () => {
    if (isTitan) return;
    if (mounted) {
      dismount();
      return;
    }
    const h = nearestHorse();
    if (!h) {
      say("Yakında at yok");
      return;
    }
    mounted = h;
    h.occupied = true;
    clearHooks();
    say("Ata bindin  ·  G in");
  };

  const rollTitanReward = () => {
    progress.raidAttempts += 1;
    progress.raidPity = Math.min(10, progress.raidPity + 1);
    const baseChance = 0.035 + Math.min(0.12, progress.raidPity * 0.012);
    const guaranteed = progress.raidPity >= 10;
    if (!guaranteed && Math.random() > baseChance) {
      saveProgress(progress);
      return false;
    }
    const roll = Math.random();
    const rarity = roll < 0.02 ? "MYTHIC" : roll < 0.10 ? "LEGENDARY" : roll < 0.28 ? "EPIC" : roll < 0.62 ? "RARE" : "COMMON";
    progress.titanUnlocked = true;
    progress.titanRarity = rarity;
    progress.titanPower = rarity === "MYTHIC" ? "Kurucu Titan" : rarity === "LEGENDARY" ? "Savaşçı Titan" : rarity === "EPIC" ? "Yıldırım Titanı" : rarity === "RARE" ? "Çelik Titanı" : "Titan Gücü";
    progress.raidPity = 0;
    saveProgress(progress);
    return true;
  };

  const startRaid = () => {
    const anchor = world.raidAnchors[Math.floor(Math.random() * world.raidAnchors.length)];
    raid = { name: anchor.name, x: anchor.x, z: anchor.z, left: 45, spawned: 0 };
    audio.horn();
    const difficulty = progress.level >= 12 ? "NIGHTMARE" : progress.level >= 8 ? "EXTREME" : progress.level >= 5 ? "HARD" : progress.level >= 3 ? "NORMAL" : "EASY";
    say(`RAID ${difficulty} — ${anchor.name}!`);
    const n = 5 + Math.min(5, Math.floor(progress.level / 2));
    for (let i = 0; i < n; i++) {
      const e = spawnEnemy(20, 70, true, i === 0 && progress.level > 2 ? pickPureKind() : "normal");
      const ang = Math.random() * Math.PI * 2;
      e.group.position.set(anchor.x + Math.cos(ang) * (38 + Math.random() * 22), 0, anchor.z + Math.sin(ang) * (38 + Math.random() * 22));
    }
  };

  const spawnSpecial = () => {
    if (enemies.some((e) => e.special)) return;
    const kind = SPECIALS[Math.floor(Math.random() * SPECIALS.length)];
    const e = spawnEnemy(WALLS.maria + 40, WALLS.maria + 120, false, kind);
    say(`${SPECIAL_NAMES[kind]} görüldü!`);
    audio.horn();
    return e;
  };

  const respawn = () => {
    dismount();
    isTitan = false;
    titan.group.visible = false;
    scout.group.visible = true;
    scout.group.position.set(0, 0, WALLS.maria - 55);
    vel.set(0, 0, 0);
    energy = energyMax(progress) * 0.6;
    gas = gasMax(progress);
    clearHooks();
    progress.gold = Math.max(0, progress.gold - 20);
    say("Düştün · Shiganshina");
    persist();
  };

  const throwRock = (from: THREE.Vector3, toward: THREE.Vector3) => {
    const mesh = new THREE.Mesh(rockGeo, rockMat);
    mesh.position.copy(from).add(_v1.set(0, 8, 0));
    scene.add(mesh);
    _v2.copy(toward).sub(from).setY(0);
    if (_v2.lengthSq() < 0.001) _v2.set(0, 0, 1);
    _v2.normalize().multiplyScalar(26);
    _v2.y = 8;
    rocks.push({ mesh, vel: _v2.clone(), life: 3.2 });
  };

  const pushHud = () => {
    const p = active().position;
    onHud({
      energy,
      energyMax: energyMax(progress),
      gas,
      gasMax: gasMax(progress),
      blades,
      bladeMax: bladeMax(progress),
      kills,
      gold: progress.gold,
      level: progress.level,
      xp: progress.xp,
      xpNext: xpForLevel(progress.level),
      isTitan,
      isHardened,
      district: districtOf(p.x, p.z),
      mode: isTitan ? (isHardened ? "Saldırı Devi  ·  Sertleşme" : "Saldırı Devi") : mounted ? "At sırtı" : "İnsan  ·  ODM",
      sprinting: input.sampleMove().sprint,
      hooked: hooks.some((h) => h.attached),
      mounted: !!mounted,
      nearHorse: !mounted && !!nearestHorse(),
      nearSupply: nearSupply(),
      isNight: isNight(),
      clock: clockLabel(),
      px: p.x,
      pz: p.z,
      yaw: camYaw,
      titans: enemies.map((e) => ({ x: e.group.position.x, z: e.group.position.z, kind: e.kind })),
      quest: { title: quest.title, desc: quest.desc, progress: quest.progress, target: quest.target, gold: quest.gold },
      raid: raid ? { name: raid.name, left: raid.left } : null,
      toast,
      squadAlive: allies.filter((a) => a.hp > 0).length,
      team: progress.team,
      shop: shopCatalog(progress),
      titanUnlocked: progress.titanUnlocked,
      titanPower: progress.titanPower,
      titanRarity: progress.titanRarity,
      raidPity: progress.raidPity,
    });
  };

  const updateLighting = (dt: number) => {
    tod = (tod + dt / 180) % 1;
    const elev = Math.sin((tod - 0.25) * Math.PI * 2);
    const day = THREE.MathUtils.smoothstep(elev, -0.15, 0.35);
    const obj = active();
    const sunX = Math.cos((tod - 0.25) * Math.PI * 2) * 160;
    const sunY = 40 + Math.max(8, elev * 240);
    const sunZ = Math.sin((tod - 0.25) * Math.PI * 2) * 80;
    world.sun.position.set(obj.position.x + sunX, sunY, obj.position.z + sunZ);
    world.sun.target.position.copy(obj.position);
    world.sun.target.updateMatrixWorld();
    world.sun.intensity = 0.12 + day * 1.28;
    world.sun.color.setRGB(1, 0.94 + day * 0.04, 0.78 + day * 0.18);
    world.hemi.intensity = 0.22 + day * 0.42;
    world.amb.intensity = 0.12 + day * 0.18;
    world.moon.intensity = (1 - day) * 0.35;
    world.moon.position.set(obj.position.x - 70, 140, obj.position.z - 40);
    const fogDay = _fogDay;
    const fogNight = _fogNight;
    world.fog.color.copy(fogDay).lerp(fogNight, 1 - day);
    scene.background = _bg.copy(world.fog.color);
    world.skyMat.color.setRGB(0.28 + day * 0.72, 0.32 + day * 0.68, 0.4 + day * 0.6);
    world.fog.near = 50 + day * 40;
    world.fog.far = 320 + day * 220;
    renderer.toneMappingExposure = 0.72 + day * 0.48;
    const torchI = (1 - day) * 2.4;
    world.torches.forEach((t) => {
      t.intensity = torchI;
    });
    if (boltLight.intensity > 0) boltLight.intensity = Math.max(0, boltLight.intensity - dt * 28);
  };

  const update = (dt: number) => {
    const actions = input.consumeActions();
    if (actions.has("hook")) fireHooks();
    if (actions.has("attack")) doAttack();
    if (actions.has("transform")) transform();
    if (actions.has("heal")) heal();
    if (actions.has("roar")) roar();
    if (actions.has("harden")) harden();
    if (actions.has("mount")) toggleMount();

    const look = input.consumeLook();
    camYaw -= look.x * 0.0024;
    pitch -= look.y * 0.002;
    pitch = Math.max(-0.55, Math.min(0.85, pitch));

    const move = input.sampleMove();
    _fwd.set(-Math.sin(camYaw), 0, -Math.cos(camYaw));
    _right.set(Math.cos(camYaw), 0, -Math.sin(camYaw));

    const obj = active();
    const sprint = move.sprint;
    const ride = !!mounted && !isTitan;
    const speed =
      (isTitan ? 18 : ride ? horseSpeed(progress) : 9.5) *
      (sprint && !ride ? 1.75 : ride && sprint ? 1.25 : 1) *
      (hooks.some((h) => h.attached) ? 0.35 : 1);
    const grounded = obj.position.y <= 0.08 || ride;

    if (grounded || isTitan) {
      _v1.copy(_fwd).multiplyScalar(move.y).addScaledVector(_right, move.x);
      if (_v1.lengthSq() > 0.001) {
        _v1.normalize();
        obj.position.addScaledVector(_v1, speed * dt);
        yaw = Math.atan2(-_v1.x, -_v1.z);
        obj.lookAt(obj.position.x + _v1.x, obj.position.y, obj.position.z + _v1.z);
        walkT += dt * (sprint ? 10 : 6.5) * (isTitan ? 0.7 : ride ? 1.4 : 1);
        const swing = Math.sin(walkT) * (sprint ? 0.7 : 0.4);
        const L = limbs();
        L.leftLeg.rotation.x = ride ? 0 : swing;
        L.rightLeg.rotation.x = ride ? 0 : -swing;
        L.leftArm.rotation.x = ride ? 0.4 : -swing * 0.8 + (attackT > 0 ? -1.2 : 0);
        L.rightArm.rotation.x = ride ? 0.4 : swing * 0.8 + (attackT > 0 ? -1.4 : 0);
      } else {
        const L = limbs();
        L.leftLeg.rotation.x *= 0.8;
        L.rightLeg.rotation.x *= 0.8;
        L.leftArm.rotation.x *= 0.8;
        L.rightArm.rotation.x *= 0.8;
      }
    } else {
      _v1.copy(_fwd).multiplyScalar(move.y).addScaledVector(_right, move.x);
      vel.addScaledVector(_v1, 18 * dt);
    }

    if (attackT > 0) attackT -= dt;

    if (mounted && !isTitan) {
      mounted.group.position.x = scout.group.position.x;
      mounted.group.position.z = scout.group.position.z;
      mounted.group.rotation.y = scout.group.rotation.y;
      scout.group.position.y = 1.05;
      vel.set(0, 0, 0);
    }

    const hooked = hooks.some((h) => h.attached || h.flying);
    if (!isTitan && !mounted) {
      scout.hips.left.getWorldPosition(_v2);
      scout.hips.right.getWorldPosition(_v3);
      const origins = [_v2.clone(), _v3.clone()];
      for (let i = 0; i < 2; i++) {
        const h = hooks[i];
        if (h.flying) {
          _v1.subVectors(h.target, h.pos);
          const dist = _v1.length();
          const step = 160 * dt;
          if (dist < step) {
            h.pos.copy(h.target);
            h.flying = false;
            h.attached = true;
          } else {
            h.pos.addScaledVector(_v1.normalize(), step);
          }
          placeCable(h, origins[i], h.pos);
        } else if (h.attached) {
          placeCable(h, origins[i], h.target);
        }
      }
      if (hooks.some((h) => h.attached)) {
        const target = _v1.set(0, 0, 0);
        let n = 0;
        hooks.forEach((h) => {
          if (h.attached) {
            target.add(h.target);
            n++;
          }
        });
        target.multiplyScalar(1 / Math.max(1, n));
        _v1.subVectors(target, obj.position);
        const d = _v1.length();
        if (d > 3.2) {
          vel.addScaledVector(_v1.normalize(), odmForce(progress) * dt);
          gas = Math.max(0, gas - 9 * dt);
        } else {
          clearHooks();
          if (target.y > 2) obj.position.y = target.y;
        }
        if (gas <= 0) clearHooks();
      }
      obj.position.addScaledVector(vel, dt);
      vel.multiplyScalar(grounded ? 0.82 : 0.985);
      if (!hooked) vel.y -= 28 * dt;
      else vel.y -= 6 * dt;
      if (obj.position.y < 0) {
        obj.position.y = 0;
        vel.y = 0;
        if (grounded) vel.x *= 0.7;
        vel.z *= 0.7;
      }
      if (gas < gasMax(progress)) gas = Math.min(gasMax(progress), gas + 3.5 * dt);
    } else if (isTitan) {
      energy -= 2.8 * dt;
      obj.position.y = 0;
      vel.set(0, 0, 0);
      if (energy <= 0) {
        energy = 0;
        transform();
      }
      if (Math.random() < 0.25) emit(obj.position.clone().add(_v1.set(0, 8, 0)), isHardened ? 0x88e8ff : 0x99ffff, 1);
    }

    wallPush(obj.position, isTitan ? 3.2 : 0.6);
    obj.position.x = THREE.MathUtils.clamp(obj.position.x, -WORLD_LIMIT, WORLD_LIMIT);
    obj.position.z = THREE.MathUtils.clamp(obj.position.z, -WORLD_LIMIT, WORLD_LIMIT);

    if (quest.type === "reach" && inMitras(obj.position.x, obj.position.z)) completeQuestIf("reach");

    const nightMul = isNight() ? 1.28 : 1;
    enemies.forEach((e) => {
      if (e.stunned > 0) {
        e.stunned -= dt;
        return;
      }
      const dest = e.raid && raid ? _v3.set(raid.x, 0, raid.z) : obj.position;
      _v1.subVectors(dest, e.group.position);
      _v1.y = 0;
      const d = _v1.length();
      if (d > 1) _v1.multiplyScalar(1 / d);
      const spd = (e.hasLeftLeg && e.hasRightLeg ? 2.4 : 0.9) * e.speed * nightMul;
      const holdRange = e.kind === "beast" ? 34 : 4;
      if (d > holdRange && d < 280) e.group.position.addScaledVector(_v1, spd * dt);
      e.group.lookAt(dest.x, e.group.position.y, dest.z);
      e.walkT += dt * spd;
      const sw = Math.sin(e.walkT) * 0.45;
      e.limbs.leftLeg.rotation.x = sw;
      e.limbs.rightLeg.rotation.x = -sw;
      e.limbs.leftArm.rotation.x = -sw * 0.7;
      e.limbs.rightArm.rotation.x = sw * 0.7;

      if (e.kind === "beast") {
        e.throwCd -= dt;
        if (e.throwCd <= 0 && d < 70 && d > 12) {
          e.throwCd = 3.4;
          throwRock(e.group.position, obj.position);
        }
      }
      if (e.kind === "jaw" && d < 16 && d > 5 && Math.random() < 0.015) {
        e.group.position.addScaledVector(_v1, 9);
      }
      if (e.raid && raid && d < 6) {
        raid.left -= dt * 4;
      }
      if (!isTitan && d < 3.4 + e.scale) {
        energy = Math.max(0, energy - (14 + e.scale * 6) * dt);
        trauma = Math.min(1, trauma + 0.2 * dt);
        _v2.copy(_v1).multiplyScalar(-8 * dt);
        obj.position.add(_v2);
        if (mounted) dismount();
        if (energy <= 0) respawn();
      }
    });

    for (let i = rocks.length - 1; i >= 0; i--) {
      const r = rocks[i];
      r.life -= dt;
      r.vel.y -= 18 * dt;
      r.mesh.position.addScaledVector(r.vel, dt);
      if (r.mesh.position.y < 0.4) {
        r.mesh.position.y = 0.4;
        r.vel.set(0, 0, 0);
      }
      if (!isTitan && r.mesh.position.distanceTo(obj.position) < 2.2) {
        energy = Math.max(0, energy - 22);
        trauma = 0.6;
        r.life = 0;
        if (energy <= 0) respawn();
      }
      if (r.life <= 0) {
        scene.remove(r.mesh);
        rocks.splice(i, 1);
      }
    }

    allies.forEach((a) => {
      if (a.hp <= 0) {
        a.scout.group.visible = false;
        return;
      }
      const target = obj.position.clone().add(a.offset);
      _v1.subVectors(target, a.scout.group.position);
      _v1.y = 0;
      const d = _v1.length();
      if (d > 1.4) {
        _v1.normalize();
        a.scout.group.position.addScaledVector(_v1, 8 * dt);
        a.scout.group.lookAt(a.scout.group.position.x + _v1.x, 0, a.scout.group.position.z + _v1.z);
        a.walkT += dt * 8;
        const sw = Math.sin(a.walkT) * 0.4;
        a.scout.limbs.leftLeg.rotation.x = sw;
        a.scout.limbs.rightLeg.rotation.x = -sw;
      }
      for (let i = enemies.length - 1; i >= 0; i--) {
        const e = enemies[i];
        if (a.scout.group.position.distanceTo(e.group.position) < 5 + e.scale) {
          e.hp -= dt * 0.35;
          if (e.hp <= 0) killEnemy(e, i);
        }
      }
    });

    if (grassAt.distanceTo(obj.position) > 14) {
      scatterGrass(world.grass, world.grassCount, obj.position.x, obj.position.z, 52);
      grassAt.copy(obj.position);
    }

    for (const p of particles) {
      if (p.life <= 0) continue;
      p.life -= dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.steam) {
        p.mesh.scale.addScalar(dt * 1.8);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity -= dt * 0.8;
      }
      if (p.life <= 0) p.mesh.visible = false;
    }

    if (shockT > 0) {
      shockT -= dt;
      shockwave.scale.addScalar(dt * 28);
      ringMat.opacity = Math.max(0, shockT);
      if (shockT <= 0) shockwave.visible = false;
    }

    raidCd -= dt;
    if (!raid && raidCd <= 0) {
      startRaid();
      raidCd = 70 + Math.random() * 40;
    }
    if (raid) {
      raid.left -= dt;
      if (raid.left <= 0) {
        say(`${raid.name} yaralandı`);
        progress.gold = Math.max(0, progress.gold - 15);
        raid = null;
        persist();
      }
    }
    specialCd -= dt;
    if (specialCd <= 0) {
      spawnSpecial();
      specialCd = 55 + Math.random() * 40;
    }

    if (toastT > 0) {
      toastT -= dt;
      if (toastT <= 0) toast = "";
    }

    updateLighting(dt);
    trauma = Math.max(0, trauma - dt * 1.4);
    hudAcc += dt;
    if (hudAcc > 0.12) {
      hudAcc = 0;
      pushHud();
    }
  };

  const render = (dt: number) => {
    const obj = active();
    const dist = isTitan ? 28 : mounted ? 14 : 11.5;
    const height = isTitan ? 14 : mounted ? 5.2 : 4.2;
    const lookY = isTitan ? 8 : 1.7;
    const ch = Math.cos(pitch);
    const desired = _v1.set(
      obj.position.x + Math.sin(camYaw) * dist * ch,
      obj.position.y + height + Math.sin(pitch) * dist,
      obj.position.z + Math.cos(camYaw) * dist * ch,
    );
    if (!started) {
      camYaw += dt * 0.08;
      const ox = obj.position.x;
      const oz = obj.position.z;
      camera.position.set(ox + Math.sin(camYaw) * 26, 11, oz + Math.cos(camYaw) * 26);
      camera.lookAt(ox, 8, oz + 18);
      renderer.render(scene, camera);
      return;
    }
    const k = 1 - Math.exp(-8 * dt);
    camera.position.lerp(desired, started ? k : 1);
    const shake = trauma * trauma;
    if (shake > 0) {
      camera.position.x += (Math.random() - 0.5) * shake * 1.6;
      camera.position.y += (Math.random() - 0.5) * shake * 1.2;
    }
    camera.lookAt(obj.position.x, obj.position.y + lookY, obj.position.z);
    const wantFov = isTitan ? 58 : input.sampleMove().sprint ? 66 : 60;
    fov += (wantFov - fov) * (1 - Math.exp(-6 * dt));
    camera.fov = fov;
    camera.updateProjectionMatrix();
    renderer.render(scene, camera);
  };

  const loop = (now: number) => {
    if (!running) return;
    const dt = Math.min((now - last) / 1000, 0.08);
    last = now;
    if (started && !paused) {
      if (hitstop > 0) hitstop -= dt;
      else update(dt);
    } else {
      updateLighting(dt * 0.25);
    }
    render(dt);
  };
  renderer.setAnimationLoop(loop);

  const onPointerDown = (e: PointerEvent) => {
    if (!started || paused) return;
    if (e.pointerType === "mouse") {
      try {
        canvas.requestPointerLock();
      } catch {
        /* ignore */
      }
    }
    if (input.pointerLocked) return;
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY };
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
  };
  const onPointerMove = (e: PointerEvent) => {
    if (input.pointerLocked || !started || paused) return;
    if (e.pointerType === "mouse" && e.buttons === 1) {
      input.lookDx += e.movementX;
      input.lookDy += e.movementY;
      return;
    }
    if (!drag || drag.id !== e.pointerId) return;
    input.lookDx += e.clientX - drag.x;
    input.lookDy += e.clientY - drag.y;
    drag.x = e.clientX;
    drag.y = e.clientY;
  };
  const onPointerUp = (e: PointerEvent) => {
    if (drag?.id === e.pointerId) drag = null;
  };
  canvas.addEventListener("pointerdown", onPointerDown);
  canvas.addEventListener("pointermove", onPointerMove);
  canvas.addEventListener("pointerup", onPointerUp);
  canvas.addEventListener("pointercancel", onPointerUp);

  const onHide = () => {
    if (document.hidden) persist();
  };
  document.addEventListener("visibilitychange", onHide);

  const probe = {
    getYaw: () => yaw,
    getSpeed: () => {
      const m = input.sampleMove();
      return Math.hypot(m.x, m.y) * (m.sprint ? 18 : 10);
    },
    setKeys: (codes: string[]) => {
      input.setKeys(codes);
      if (codes.length) {
        started = true;
        paused = false;
      }
    },
    setSteer: (v: number) => {
      if (v > 0.1) input.setKeys(["KeyW", "KeyA"]);
      else if (v < -0.1) input.setKeys(["KeyW", "KeyD"]);
      else input.setKeys(["KeyW"]);
    },
  };
  (window as unknown as { __controlsTest: typeof probe }).__controlsTest = probe;

  pushHud();

  return {
    dispose() {
      running = false;
      persist();
      renderer.setAnimationLoop(null);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onHide);
      ro.disconnect();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      canvas.removeEventListener("pointerup", onPointerUp);
      canvas.removeEventListener("pointercancel", onPointerUp);
      input.dispose();
      disposeTextures(textures);
      renderer.dispose();
    },
    start() {
      started = true;
      paused = false;
      audio.unlock();
      if (allies.length === 0) {
        spawnAlly(-3.2, 2.4);
        spawnAlly(3.4, 1.8);
      }
      say(`${TEAMS[progress.team].name} göreve çıktı`);
    },
    pause() {
      paused = true;
    },
    resume() {
      paused = false;
    },
    pulse(action: GameAction) {
      input.pulse(action);
    },
    setSprintToggle(on: boolean) {
      input.sprintToggle = on;
    },
    setJoystick(x: number, y: number, activeJoy: boolean) {
      input.joyX = x;
      input.joyY = y;
      input.joyActive = activeJoy;
    },
    addLook(dx: number, dy: number) {
      input.lookDx += dx;
      input.lookDy += dy;
    },
    setTeam(team: TeamId) {
      progress.team = team;
      persist();
    },
    buy(id: string) {
      const ok = buyUpgrade(progress, id);
      if (ok) {
        gas = Math.min(gasMax(progress), gas + 10);
        blades = Math.min(bladeMax(progress), blades + 10);
        energy = Math.min(energyMax(progress), energy + 8);
        say("Ekipman geliştirildi");
        audio.coin();
        pushHud();
      }
      return ok;
    },
  };
}
