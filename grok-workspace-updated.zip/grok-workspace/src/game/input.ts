import type { GameAction } from "./types";

const GAME_CODES = new Set([
  "KeyW",
  "KeyA",
  "KeyS",
  "KeyD",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
  "ShiftLeft",
  "ShiftRight",
  "KeyQ",
  "KeyF",
  "KeyE",
  "KeyH",
  "KeyR",
  "KeyX",
  "KeyG",
  "Space",
  "KeyP",
]);

export class Input {
  keys = new Set<string>();
  injected = new Set<string>();
  queued = new Set<GameAction>();
  joyX = 0;
  joyY = 0;
  joyActive = false;
  sprintToggle = false;
  lookDx = 0;
  lookDy = 0;
  pointerLocked = false;
  private unbind: Array<() => void> = [];

  attach(target: HTMLElement) {
    const onDown = (e: KeyboardEvent) => {
      if (GAME_CODES.has(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      if (e.code === "KeyQ") this.queued.add("hook");
      if (e.code === "KeyF") this.queued.add("attack");
      if (e.code === "KeyE" || e.code === "Space") this.queued.add("transform");
      if (e.code === "KeyH") this.queued.add("heal");
      if (e.code === "KeyR") this.queued.add("roar");
      if (e.code === "KeyX") this.queued.add("harden");
      if (e.code === "KeyG") this.queued.add("mount");
    };
    const onUp = (e: KeyboardEvent) => {
      this.keys.delete(e.code);
    };
    const clear = () => this.keys.clear();
    const onMouse = (e: MouseEvent) => {
      if (!this.pointerLocked) return;
      this.lookDx += e.movementX;
      this.lookDy += e.movementY;
    };
    const onLockChange = () => {
      this.pointerLocked = document.pointerLockElement === target;
    };

    window.addEventListener("keydown", onDown);
    window.addEventListener("keyup", onUp);
    window.addEventListener("blur", clear);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) clear();
    });
    document.addEventListener("mousemove", onMouse);
    document.addEventListener("pointerlockchange", onLockChange);

    this.unbind.push(() => {
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      window.removeEventListener("blur", clear);
      document.removeEventListener("mousemove", onMouse);
      document.removeEventListener("pointerlockchange", onLockChange);
    });
  }

  pulse(action: GameAction) {
    this.queued.add(action);
  }

  consumeLook(): { x: number; y: number } {
    const x = this.lookDx;
    const y = this.lookDy;
    this.lookDx = 0;
    this.lookDy = 0;
    return { x, y };
  }

  consumeActions(): Set<GameAction> {
    const q = this.queued;
    this.queued = new Set();
    return q;
  }

  sampleMove(): { x: number; y: number; sprint: boolean } {
    const codes = this.codes();
    let x = 0;
    let y = 0;
    if (codes.has("KeyA") || codes.has("ArrowLeft")) x -= 1;
    if (codes.has("KeyD") || codes.has("ArrowRight")) x += 1;
    if (codes.has("KeyW") || codes.has("ArrowUp")) y += 1;
    if (codes.has("KeyS") || codes.has("ArrowDown")) y -= 1;
    if (this.joyActive) {
      x = this.joyX;
      y = this.joyY;
    }
    const mag = Math.hypot(x, y);
    if (mag > 1) {
      x /= mag;
      y /= mag;
    }
    const sprint = this.sprintToggle || codes.has("ShiftLeft") || codes.has("ShiftRight");
    return { x, y, sprint };
  }

  codes(): Set<string> {
    if (this.injected.size === 0) return this.keys;
    const s = new Set(this.keys);
    this.injected.forEach((c) => s.add(c));
    return s;
  }

  setKeys(codes: string[]) {
    this.injected = new Set(codes);
  }

  dispose() {
    this.unbind.forEach((fn) => fn());
    this.unbind = [];
  }
}
