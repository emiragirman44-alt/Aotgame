import { WALLS } from "./types";

export type QuestType = "kills" | "defend" | "reach" | "special" | "night";

export type Quest = {
  id: string;
  type: QuestType;
  title: string;
  desc: string;
  progress: number;
  target: number;
  gold: number;
  xp: number;
};

const POOL: Omit<Quest, "progress" | "gold" | "xp">[] = [
  {
    id: "k5",
    type: "kills",
    title: "Ense avı",
    desc: "Saf devlerin ensesini kes",
    target: 5,
  },
  {
    id: "k8",
    type: "kills",
    title: "Temizlik",
    desc: "Sekiz dev düşür",
    target: 8,
  },
  {
    id: "def",
    type: "defend",
    title: "Şehri tut",
    desc: "Bir titan saldırısını savuştur",
    target: 1,
  },
  {
    id: "mitras",
    type: "reach",
    title: "Mitras'a rapor",
    desc: "Sur Sina içine gir",
    target: 1,
  },
  {
    id: "spec",
    type: "special",
    title: "Özel hedef",
    desc: "Zırhlı, Dişi, Çene veya Canavar Titan'ı düşür",
    target: 1,
  },
  {
    id: "night",
    type: "night",
    title: "Gece nöbeti",
    desc: "Gece boyunca iki dev kes",
    target: 2,
  },
];

export function makeQuest(index: number, level: number): Quest {
  const base = POOL[index % POOL.length];
  const scale = 1 + level * 0.12;
  return {
    ...base,
    progress: 0,
    gold: Math.round((55 + level * 12) * scale),
    xp: Math.round((40 + level * 10) * scale),
  };
}

export function inMitras(x: number, z: number): boolean {
  return Math.hypot(x, z) < WALLS.sina - 12;
}
