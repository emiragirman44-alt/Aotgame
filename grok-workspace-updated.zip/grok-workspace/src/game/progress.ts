import { TEAMS, type ShopItem, type TeamId } from "./types";

const KEY = "aot-campaign-v2";
const SAVE_VERSION = 2;

export type Progress = {
  version: number;
  gold: number;
  xp: number;
  level: number;
  kills: number;
  team: TeamId;
  gasBonus: number;
  bladeBonus: number;
  odmBonus: number;
  energyBonus: number;
  horseBonus: number;
  titanUnlocked: boolean;
  titanPower: string | null;
  titanRarity: "COMMON" | "RARE" | "EPIC" | "LEGENDARY" | "MYTHIC" | null;
  raidAttempts: number;
  raidPity: number;
};

const defaults = (): Progress => ({
  version: SAVE_VERSION,
  gold: 40,
  xp: 0,
  level: 1,
  kills: 0,
  team: "scout",
  gasBonus: 0,
  bladeBonus: 0,
  odmBonus: 0,
  energyBonus: 0,
  horseBonus: 0,
  titanUnlocked: false,
  titanPower: null,
  titanRarity: null,
  raidAttempts: 0,
  raidPity: 0,
});

export function xpForLevel(level: number): number {
  return 80 + level * 45;
}

export function loadProgress(): Progress {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaults();
    const parsed = JSON.parse(raw) as Partial<Progress>;
    return { ...defaults(), ...parsed, version: SAVE_VERSION };
  } catch {
    return defaults();
  }
}

export function saveProgress(p: Progress): void {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...p, version: SAVE_VERSION }));
  } catch {
    /* quota / private mode */
  }
}

export function addXp(p: Progress, amount: number): boolean {
  p.xp += amount;
  let leveled = false;
  while (p.xp >= xpForLevel(p.level)) {
    p.xp -= xpForLevel(p.level);
    p.level += 1;
    p.gold += 25 + p.level * 4;
    leveled = true;
  }
  return leveled;
}

export function goldMul(p: Progress): number {
  return p.team === "mp" ? 1.25 : 1;
}

export function gasMax(p: Progress): number {
  return 100 + p.gasBonus;
}

export function bladeMax(p: Progress): number {
  const team = p.team === "garrison" ? 20 : 0;
  return 100 + p.bladeBonus + team;
}

export function energyMax(p: Progress): number {
  return 100 + p.energyBonus;
}

export function odmForce(p: Progress): number {
  const team = p.team === "scout" ? 8 : 0;
  return 42 + p.odmBonus + team;
}

export function horseSpeed(p: Progress): number {
  return 22 + p.horseBonus;
}

export function shopCatalog(p: Progress): ShopItem[] {
  return [
    {
      id: "gas",
      name: "Gaz tankı",
      desc: "+25 kapasite",
      cost: 70 + p.gasBonus * 2,
      owned: p.gasBonus / 25,
      cap: 3,
    },
    {
      id: "blade",
      name: "Ultra çelik bıçak",
      desc: "+20 dayanıklılık",
      cost: 65 + p.bladeBonus * 2,
      owned: p.bladeBonus / 20,
      cap: 3,
    },
    {
      id: "odm",
      name: "ODM itiş",
      desc: "Daha güçlü kanca",
      cost: 110 + p.odmBonus * 4,
      owned: p.odmBonus / 8,
      cap: 3,
    },
    {
      id: "energy",
      name: "Titan çekirdeği",
      desc: "+20 dönüşüm enerjisi",
      cost: 130 + p.energyBonus * 3,
      owned: p.energyBonus / 20,
      cap: 3,
    },
    {
      id: "horse",
      name: "Savaş eyeri",
      desc: "At hızı +",
      cost: 90 + p.horseBonus * 6,
      owned: p.horseBonus / 5,
      cap: 2,
    },
  ];
}

export function buyUpgrade(p: Progress, id: string): boolean {
  const item = shopCatalog(p).find((x) => x.id === id);
  if (!item || item.owned >= item.cap || p.gold < item.cost) return false;
  p.gold -= item.cost;
  if (id === "gas") p.gasBonus += 25;
  if (id === "blade") p.bladeBonus += 20;
  if (id === "odm") p.odmBonus += 8;
  if (id === "energy") p.energyBonus += 20;
  if (id === "horse") p.horseBonus += 5;
  saveProgress(p);
  return true;
}

export { TEAMS };
