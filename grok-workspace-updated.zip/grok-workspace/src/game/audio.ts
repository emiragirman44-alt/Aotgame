export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfx: GainNode | null = null;
  roarBuf: AudioBuffer | null = null;
  private loading = false;

  private visBound = false;

  unlock() {
    if (!this.ctx) {
      this.ctx = new AudioContext({ latencyHint: "interactive" });
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.85;
      this.master.connect(this.ctx.destination);
      this.sfx = this.ctx.createGain();
      this.sfx.gain.value = 0.9;
      this.sfx.connect(this.master);
      void this.loadRoar();
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    if (!this.visBound) {
      this.visBound = true;
      document.addEventListener("visibilitychange", () => {
        if (!document.hidden && this.ctx?.state === "suspended") void this.ctx.resume();
      });
    }
  }

  private async loadRoar() {
    if (this.loading || this.roarBuf || !this.ctx) return;
    this.loading = true;
    for (const url of ["/sfx/titan-roar.ogg", "/sfx/titan-roar.mp3"]) {
      try {
        const res = await fetch(url);
        if (!res.ok) continue;
        const arr = await res.arrayBuffer();
        this.roarBuf = await this.ctx.decodeAudioData(arr.slice(0));
        return;
      } catch {
        /* try next */
      }
    }
  }

  private envGain(duration: number, peak = 0.4): GainNode | null {
    if (!this.ctx || !this.sfx) return null;
    const g = this.ctx.createGain();
    const now = this.ctx.currentTime;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(peak, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.01, now + duration);
    g.connect(this.sfx);
    return g;
  }

  roar() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx || !this.sfx) return;
    const now = ctx.currentTime;
    if (this.roarBuf) {
      const src = ctx.createBufferSource();
      src.buffer = this.roarBuf;
      src.playbackRate.value = 0.92 + Math.random() * 0.1;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(0.52, now + 0.04);
      g.gain.exponentialRampToValueAtTime(0.01, now + Math.min(6.2, this.roarBuf.duration));
      src.connect(g);
      g.connect(this.sfx);
      src.start(now);
      return;
    }
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(48, now);
    osc.frequency.exponentialRampToValueAtTime(210, now + 0.5);
    osc.frequency.exponentialRampToValueAtTime(36, now + 3.4);
    const f = ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(1200, now);
    const g = this.envGain(3.4, 0.55);
    if (!g) return;
    osc.connect(f);
    f.connect(g);
    osc.start(now);
    osc.stop(now + 3.4);
  }

  slash() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "square";
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(140, now + 0.18);
    const g = this.envGain(0.2, 0.18);
    if (!g) return;
    osc.connect(g);
    osc.start(now);
    osc.stop(now + 0.2);
  }

  drySlash() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(90, now + 0.12);
    const g = this.envGain(0.12, 0.12);
    if (!g) return;
    osc.connect(g);
    osc.start(now);
    osc.stop(now + 0.12);
  }

  gas() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const noise = ctx.createBuffer(1, ctx.sampleRate * 0.25, ctx.sampleRate);
    const data = noise.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource();
    src.buffer = noise;
    const f = ctx.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 1400;
    const g = this.envGain(0.22, 0.2);
    if (!g) return;
    src.connect(f);
    f.connect(g);
    src.start(now);
    src.stop(now + 0.25);
  }

  thunder() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(90, now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.8);
    const g = this.envGain(0.85, 0.5);
    if (!g) return;
    osc.connect(g);
    osc.start(now);
    osc.stop(now + 0.85);
  }

  horn() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.setValueAtTime(140, now + 0.35);
    const g = this.envGain(1.1, 0.28);
    if (!g) return;
    osc.connect(g);
    osc.start(now);
    osc.stop(now + 1.1);
  }

  coin() {
    this.unlock();
    const ctx = this.ctx;
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(1320, now + 0.08);
    const g = this.envGain(0.18, 0.12);
    if (!g) return;
    osc.connect(g);
    osc.start(now);
    osc.stop(now + 0.18);
  }
}
