import * as THREE from "three";

export type GameTextures = {
  grass: THREE.CanvasTexture;
  dirt: THREE.CanvasTexture;
  brick: THREE.CanvasTexture;
  stone: THREE.CanvasTexture;
  wood: THREE.CanvasTexture;
  leaves: THREE.CanvasTexture;
  roof: THREE.CanvasTexture;
  muscle: THREE.CanvasTexture;
  cobble: THREE.CanvasTexture;
  bladeGrass: THREE.CanvasTexture;
  cloak: THREE.CanvasTexture;
  sky: THREE.CanvasTexture;
  all: THREE.CanvasTexture[];
};

function canvas(size: number): { c: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d");
  if (!ctx) throw new Error("2d context");
  return { c, ctx };
}

function tex(c: HTMLCanvasElement, repeatX = 1, repeatY = 1, nearest = false): THREE.CanvasTexture {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 8;
  t.colorSpace = THREE.SRGBColorSpace;
  if (nearest) {
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
  } else {
    t.needsUpdate = true;
  }
  t.needsUpdate = true;
  return t;
}

function speckle(
  ctx: CanvasRenderingContext2D,
  size: number,
  count: number,
  color: string,
  radius: number,
) {
  ctx.fillStyle = color;
  for (let i = 0; i < count; i++) {
    ctx.beginPath();
    ctx.arc(Math.random() * size, Math.random() * size, Math.random() * radius, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function createTextures(): GameTextures {
  const all: THREE.CanvasTexture[] = [];
  const push = (t: THREE.CanvasTexture) => {
    all.push(t);
    return t;
  };

  // High-res grass field
  {
    const { c, ctx } = canvas(1024);
    ctx.fillStyle = "#3d5c28";
    ctx.fillRect(0, 0, 1024, 1024);
    for (let i = 0; i < 2400; i++) {
      const g = 70 + Math.random() * 70;
      ctx.fillStyle = `rgb(${40 + Math.random() * 30},${g},${28 + Math.random() * 24})`;
      ctx.beginPath();
      ctx.ellipse(
        Math.random() * 1024,
        Math.random() * 1024,
        6 + Math.random() * 18,
        3 + Math.random() * 8,
        Math.random() * Math.PI,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }
    speckle(ctx, 1024, 600, "rgba(20,40,10,0.25)", 4);
    var grass = push(tex(c, 70, 70));
  }

  // Dirt
  {
    const { c, ctx } = canvas(512);
    ctx.fillStyle = "#5a4632";
    ctx.fillRect(0, 0, 512, 512);
    speckle(ctx, 512, 900, "#6b533c", 7);
    speckle(ctx, 512, 500, "#4a3828", 5);
    var dirt = push(tex(c, 8, 8));
  }

  // Brick (district houses)
  {
    const { c, ctx } = canvas(512);
    ctx.fillStyle = "#6a5646";
    ctx.fillRect(0, 0, 512, 512);
    const bh = 28;
    const bw = 56;
    for (let y = 0; y < 512; y += bh) {
      const off = (y / bh) % 2 === 0 ? 0 : bw / 2;
      for (let x = -bw; x < 512; x += bw) {
        const shade = 90 + Math.random() * 35;
        ctx.fillStyle = `rgb(${shade + 20},${shade - 10},${shade - 28})`;
        ctx.fillRect(x + off + 2, y + 2, bw - 4, bh - 4);
      }
    }
    var brick = push(tex(c, 2, 2));
  }

  // Wall stone — large blocks like Maria/Rose/Sina
  {
    const { c, ctx } = canvas(1024);
    ctx.fillStyle = "#7a7468";
    ctx.fillRect(0, 0, 1024, 1024);
    const bh = 48;
    const bw = 96;
    for (let y = 0; y < 1024; y += bh) {
      const off = (y / bh) % 2 === 0 ? 0 : bw / 2;
      for (let x = -bw; x < 1024; x += bw) {
        const n = 118 + Math.random() * 28;
        ctx.fillStyle = `rgb(${n},${n - 6},${n - 16})`;
        ctx.fillRect(x + off + 3, y + 3, bw - 6, bh - 6);
        ctx.strokeStyle = "rgba(40,38,32,0.35)";
        ctx.strokeRect(x + off + 3, y + 3, bw - 6, bh - 6);
      }
    }
    speckle(ctx, 1024, 1200, "rgba(30,28,24,0.18)", 3);
    var stone = push(tex(c, 8, 2));
  }

  // Wood
  {
    const { c, ctx } = canvas(256);
    ctx.fillStyle = "#5a3a22";
    ctx.fillRect(0, 0, 256, 256);
    for (let x = 0; x < 256; x += 8) {
      ctx.fillStyle = Math.random() > 0.5 ? "#6b4528" : "#4a3018";
      ctx.fillRect(x, 0, 6, 256);
    }
    var wood = push(tex(c, 1, 1, true));
  }

  // Leaves
  {
    const { c, ctx } = canvas(256);
    ctx.fillStyle = "#2f5a24";
    ctx.fillRect(0, 0, 256, 256);
    speckle(ctx, 256, 400, "#3d7a30", 10);
    speckle(ctx, 256, 200, "#1e3d16", 8);
    var leaves = push(tex(c, 1, 1, true));
  }

  // Roof clay
  {
    const { c, ctx } = canvas(256);
    ctx.fillStyle = "#7a2e24";
    ctx.fillRect(0, 0, 256, 256);
    for (let y = 0; y < 256; y += 10) {
      ctx.fillStyle = y % 20 === 0 ? "#8a3a2c" : "#6a241c";
      ctx.fillRect(0, y, 256, 8);
    }
    var roof = push(tex(c, 1, 1));
  }

  // Titan muscle fibers
  {
    const { c, ctx } = canvas(512);
    ctx.fillStyle = "#8a3426";
    ctx.fillRect(0, 0, 512, 512);
    ctx.strokeStyle = "#5c1e14";
    ctx.lineWidth = 2;
    for (let i = 0; i < 512; i += 7) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.bezierCurveTo(160, i + Math.random() * 16, 320, i - Math.random() * 16, 512, i + Math.random() * 10);
      ctx.stroke();
    }
    speckle(ctx, 512, 200, "rgba(40,10,8,0.25)", 4);
    var muscle = push(tex(c, 2, 2));
  }

  // Cobble plaza
  {
    const { c, ctx } = canvas(512);
    ctx.fillStyle = "#6a655c";
    ctx.fillRect(0, 0, 512, 512);
    for (let y = 0; y < 512; y += 22) {
      for (let x = 0; x < 512; x += 22) {
        const n = 90 + Math.random() * 40;
        ctx.fillStyle = `rgb(${n},${n - 4},${n - 12})`;
        ctx.fillRect(x + 1, y + 1, 20, 20);
      }
    }
    var cobble = push(tex(c, 6, 6));
  }

  // Grass blade (alpha)
  {
    const { c, ctx } = canvas(128);
    ctx.clearRect(0, 0, 128, 128);
    for (let i = 0; i < 7; i++) {
      const x = 64 + (i - 3) * 10;
      ctx.strokeStyle = `rgba(${40 + i * 6},${110 + i * 8},${40},0.92)`;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x, 124);
      ctx.quadraticCurveTo(x + (i - 3) * 8, 60, x + (i - 3) * 4, 8);
      ctx.stroke();
    }
    var bladeGrass = push(tex(c, 1, 1));
  }

  // Wings of Freedom cloak emblem
  {
    const { c, ctx } = canvas(256);
    ctx.fillStyle = "#3d4a34";
    ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = "#e8e2d0";
    ctx.fillStyle = "#e8e2d0";
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(128, 70);
    ctx.lineTo(70, 190);
    ctx.lineTo(128, 150);
    ctx.lineTo(186, 190);
    ctx.closePath();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(128, 48);
    ctx.quadraticCurveTo(40, 110, 48, 200);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(128, 48);
    ctx.quadraticCurveTo(216, 110, 208, 200);
    ctx.stroke();
    var cloak = push(tex(c, 1, 1));
  }

  // Sky gradient
  {
    const { c, ctx } = canvas(512);
    const g = ctx.createLinearGradient(0, 0, 0, 512);
    g.addColorStop(0, "#8fb4cc");
    g.addColorStop(0.45, "#a9c3d4");
    g.addColorStop(0.72, "#c5c2a8");
    g.addColorStop(1, "#d7c9a4");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 512, 512);
    var sky = push(tex(c, 1, 1));
  }

  return {
    grass,
    dirt,
    brick,
    stone,
    wood,
    leaves,
    roof,
    muscle,
    cobble,
    bladeGrass,
    cloak,
    sky,
    all,
  };
}

export function disposeTextures(t: GameTextures) {
  t.all.forEach((x) => x.dispose());
}
