import * as THREE from "three";
import { WALLS, WORLD_SIZE } from "./types";
import type { GameTextures } from "./textures";

export type World = {
  hookables: THREE.Object3D[];
  grass: THREE.InstancedMesh;
  grassCount: number;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  amb: THREE.AmbientLight;
  moon: THREE.DirectionalLight;
  sky: THREE.Mesh;
  skyMat: THREE.MeshBasicMaterial;
  torches: THREE.PointLight[];
  supplies: THREE.Vector3[];
  horseSpawns: THREE.Vector3[];
  raidAnchors: { name: string; x: number; z: number }[];
  signs: { name: string; x: number; z: number }[];
  fog: THREE.Fog;
};

const _m = new THREE.Matrix4();
const _p = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _e = new THREE.Euler();

function setInst(
  mesh: THREE.InstancedMesh,
  i: number,
  x: number,
  y: number,
  z: number,
  sx: number,
  sy: number,
  sz: number,
  ry = 0,
) {
  _p.set(x, y, z);
  _e.set(0, ry, 0);
  _q.setFromEuler(_e);
  _s.set(sx, sy, sz);
  _m.compose(_p, _q, _s);
  mesh.setMatrixAt(i, _m);
}

export function createWorld(
  scene: THREE.Scene,
  textures: GameTextures,
  quality: "high" | "low",
): World {
  const hookables: THREE.Object3D[] = [];
  const signs: { name: string; x: number; z: number }[] = [];
  const supplies: THREE.Vector3[] = [];
  const horseSpawns: THREE.Vector3[] = [];
  const raidAnchors: { name: string; x: number; z: number }[] = [];
  const torches: THREE.PointLight[] = [];

  scene.background = new THREE.Color(0x8fb4cc);
  const fog = new THREE.Fog(0xa9c3d4, 80, quality === "high" ? 560 : 400);
  scene.fog = fog;

  const hemi = new THREE.HemisphereLight(0xc5d8ea, 0x3d4a28, 0.62);
  scene.add(hemi);
  const amb = new THREE.AmbientLight(0xffffff, 0.28);
  scene.add(amb);
  const sun = new THREE.DirectionalLight(0xfff1d0, 1.35);
  sun.position.set(160, 280, 90);
  sun.castShadow = true;
  sun.shadow.mapSize.set(quality === "high" ? 2048 : 1024, quality === "high" ? 2048 : 1024);
  sun.shadow.camera.near = 10;
  sun.shadow.camera.far = 520;
  const sh = 110;
  sun.shadow.camera.left = -sh;
  sun.shadow.camera.right = sh;
  sun.shadow.camera.top = sh;
  sun.shadow.camera.bottom = -sh;
  sun.shadow.bias = -0.00025;
  sun.shadow.normalBias = 0.035;
  scene.add(sun);
  scene.add(sun.target);

  const moon = new THREE.DirectionalLight(0x9bb4d4, 0.0);
  moon.position.set(-80, 120, -40);
  scene.add(moon);

  const skyMat = new THREE.MeshBasicMaterial({ map: textures.sky, side: THREE.BackSide });
  const sky = new THREE.Mesh(new THREE.SphereGeometry(700, 24, 16), skyMat);
  scene.add(sky);

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, 1, 1),
    new THREE.MeshStandardMaterial({ map: textures.grass, roughness: 0.92 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  const cobbleMat = new THREE.MeshStandardMaterial({ map: textures.cobble, roughness: 0.85 });
  const plaza = (x: number, z: number, r: number) => {
    const m = new THREE.Mesh(new THREE.CircleGeometry(r, 32), cobbleMat);
    m.rotation.x = -Math.PI / 2;
    m.position.set(x, 0.04, z);
    m.receiveShadow = true;
    scene.add(m);
  };
  plaza(0, WALLS.maria - 55, 48);
  plaza(0, WALLS.rose - 48, 36);
  plaza(0, 0, 42);

  const stoneMat = new THREE.MeshStandardMaterial({
    map: textures.stone,
    roughness: 0.78,
    color: 0xc8c2b4,
  });
  const brickMat = new THREE.MeshStandardMaterial({ map: textures.brick, roughness: 0.82 });
  const roofMat = new THREE.MeshStandardMaterial({ map: textures.roof, roughness: 0.7 });
  const woodMat = new THREE.MeshStandardMaterial({ map: textures.wood, roughness: 0.75 });
  const leafMat = new THREE.MeshStandardMaterial({ map: textures.leaves, roughness: 0.8 });
  const crateMat = new THREE.MeshStandardMaterial({ color: 0x6a5238, roughness: 0.7, map: textures.wood });

  const wallHeight = 50;
  const wallThick = 12;
  const segGeo = new THREE.BoxGeometry(1, 1, 1);
  const crenGeo = new THREE.BoxGeometry(1, 1, 1);

  const wallSpecs = [
    { name: "SUR SINA", r: WALLS.sina, segs: 72, color: 0xd2ccc0 },
    { name: "SUR ROSE", r: WALLS.rose, segs: 96, color: 0xc4bdb0 },
    { name: "SUR MARIA", r: WALLS.maria, segs: 120, color: 0xb7b0a3 },
  ];

  for (const spec of wallSpecs) {
    const gateWidth = 0.12;
    const usable: number[] = [];
    for (let i = 0; i < spec.segs; i++) {
      const a = (i / spec.segs) * Math.PI * 2;
      const da = Math.abs(Math.atan2(Math.sin(a), Math.cos(a)));
      if (da < gateWidth) continue;
      usable.push(i);
    }
    const wall = new THREE.InstancedMesh(segGeo, stoneMat, usable.length);
    wall.castShadow = true;
    wall.receiveShadow = true;
    wall.name = spec.name;
    const arc = (Math.PI * 2 * spec.r) / spec.segs;
    usable.forEach((i, idx) => {
      const a = (i / spec.segs) * Math.PI * 2;
      const x = Math.sin(a) * spec.r;
      const z = Math.cos(a) * spec.r;
      setInst(wall, idx, x, wallHeight / 2, z, wallThick, wallHeight, arc * 1.08, a);
    });
    wall.instanceMatrix.needsUpdate = true;
    scene.add(wall);
    hookables.push(wall);

    const cren = new THREE.InstancedMesh(crenGeo, stoneMat, usable.length);
    cren.castShadow = true;
    usable.forEach((i, idx) => {
      const a = (i / spec.segs) * Math.PI * 2;
      const x = Math.sin(a) * spec.r;
      const z = Math.cos(a) * spec.r;
      if (idx % 2 === 0) {
        setInst(cren, idx, x, wallHeight + 2.2, z, wallThick * 0.9, 4.4, arc * 0.55, a);
      } else {
        setInst(cren, idx, x, wallHeight + 0.6, z, wallThick * 0.9, 1.2, arc * 0.55, a);
      }
    });
    cren.instanceMatrix.needsUpdate = true;
    scene.add(cren);
    hookables.push(cren);

    for (const side of [-1, 1]) {
      const a = side * 0.13;
      const x = Math.sin(a) * spec.r;
      const z = Math.cos(a) * spec.r;
      const tower = new THREE.Mesh(new THREE.BoxGeometry(16, 62, 16), stoneMat);
      tower.position.set(x, 31, z);
      tower.castShadow = true;
      tower.receiveShadow = true;
      scene.add(tower);
      hookables.push(tower);
    }

    const sign = makeSign(spec.name);
    sign.position.set(0, 28, spec.r - 8);
    scene.add(sign);
    signs.push({ name: spec.name, x: 0, z: spec.r });
  }

  const bMax = quality === "high" ? 180 : 100;
  const positions: { x: number; z: number; w: number; h: number; d: number; ry: number }[] = [];

  const spawnZ = WALLS.maria - 55;
  const placeCluster = (cx: number, cz: number, n: number, spread: number, minR = 0, maxR = 9999) => {
    let tries = 0;
    while (positions.length < bMax && n > 0 && tries < n * 8) {
      tries++;
      const x = cx + (Math.random() - 0.5) * spread;
      const z = cz + (Math.random() - 0.5) * spread;
      const r = Math.hypot(x, z);
      if (r < minR || r > maxR) continue;
      const nearWall = [WALLS.sina, WALLS.rose, WALLS.maria].some((wr) => Math.abs(r - wr) < 18);
      if (nearWall) continue;
      if (Math.hypot(x, z) < 18) continue;
      if (Math.hypot(x, z - spawnZ) < 32) continue;
      if (Math.hypot(x, z - (WALLS.rose - 48)) < 24) continue;
      n--;
      positions.push({
        x,
        z,
        w: 8 + Math.random() * 8,
        h: 10 + Math.random() * 16,
        d: 8 + Math.random() * 8,
        ry: Math.random() * Math.PI,
      });
    }
  };

  placeCluster(0, 0, 28, 90, 22, WALLS.sina - 22);
  placeCluster(0, WALLS.maria - 52, 34, 78, WALLS.maria - 95, WALLS.maria - 22);
  placeCluster(0, WALLS.rose - 48, 26, 64, WALLS.rose - 90, WALLS.rose - 22);
  placeCluster(0, 0, 22, 400, WALLS.sina + 22, WALLS.rose - 22);
  placeCluster(0, 0, 18, 520, WALLS.rose + 22, WALLS.maria - 22);

  const bodies = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), brickMat, positions.length);
  const roofs = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), roofMat, positions.length);
  bodies.castShadow = true;
  bodies.receiveShadow = true;
  roofs.castShadow = true;
  positions.forEach((b, i) => {
    setInst(bodies, i, b.x, b.h / 2, b.z, b.w, b.h, b.d, b.ry);
    setInst(roofs, i, b.x, b.h + 1.2, b.z, b.w * 1.12, 2.4, b.d * 1.12, b.ry);
  });
  bodies.instanceMatrix.needsUpdate = true;
  roofs.instanceMatrix.needsUpdate = true;
  scene.add(bodies);
  scene.add(roofs);
  hookables.push(bodies, roofs);

  const palace = new THREE.Group();
  const keep = new THREE.Mesh(new THREE.BoxGeometry(28, 36, 22), stoneMat);
  keep.position.y = 18;
  keep.castShadow = true;
  palace.add(keep);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(8, 12, 10), roofMat);
  dome.position.y = 40;
  palace.add(dome);
  for (const sx of [-16, 16]) {
    const t = new THREE.Mesh(new THREE.BoxGeometry(8, 44, 8), stoneMat);
    t.position.set(sx, 22, 0);
    t.castShadow = true;
    palace.add(t);
  }
  palace.position.set(0, 0, -18);
  scene.add(palace);
  hookables.push(palace);

  const treeN = quality === "high" ? 140 : 70;
  const trunks = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), woodMat, treeN);
  const canopies = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), leafMat, treeN);
  trunks.castShadow = true;
  canopies.castShadow = true;
  let ti = 0;
  let guard = 0;
  while (ti < treeN && guard < treeN * 12) {
    guard++;
    const a = Math.random() * Math.PI * 2;
    const r = 40 + Math.random() * 480;
    const x = Math.cos(a) * r;
    const z = Math.sin(a) * r;
    const rr = Math.hypot(x, z);
    if ([WALLS.sina, WALLS.rose, WALLS.maria].some((w) => Math.abs(rr - w) < 16)) continue;
    if (rr < 30) continue;
    const th = 5 + Math.random() * 4;
    setInst(trunks, ti, x, th / 2, z, 1.3, th, 1.3, 0);
    setInst(canopies, ti, x, th + 2.2, z, 4.6 + Math.random(), 3.6, 4.6 + Math.random(), 0);
    ti++;
  }
  trunks.count = ti;
  canopies.count = ti;
  trunks.instanceMatrix.needsUpdate = true;
  canopies.instanceMatrix.needsUpdate = true;
  scene.add(trunks);
  scene.add(canopies);
  hookables.push(trunks, canopies);

  const grassN = quality === "high" ? 6500 : 2200;
  const bladeGeo = new THREE.PlaneGeometry(0.85, 1.6);
  bladeGeo.translate(0, 0.75, 0);
  const bladeMat = new THREE.MeshStandardMaterial({
    map: textures.bladeGrass,
    transparent: true,
    alphaTest: 0.35,
    side: THREE.DoubleSide,
    roughness: 0.9,
  });
  const grass = new THREE.InstancedMesh(bladeGeo, bladeMat, grassN);
  grass.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  scene.add(grass);

  const addSupply = (x: number, z: number) => {
    const crate = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.1, 1.2), crateMat);
    crate.position.set(x, 0.55, z);
    crate.castShadow = true;
    scene.add(crate);
    const flag = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 2.4, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x2a281f }),
    );
    flag.position.set(x + 0.9, 1.2, z);
    scene.add(flag);
    supplies.push(new THREE.Vector3(x, 0, z));
  };
  addSupply(8, WALLS.maria - 48);
  addSupply(-6, WALLS.rose - 42);
  addSupply(10, 12);

  horseSpawns.push(
    new THREE.Vector3(-10, 0, WALLS.maria - 62),
    new THREE.Vector3(14, 0, WALLS.maria - 50),
    new THREE.Vector3(-18, 0, WALLS.rose - 40),
    new THREE.Vector3(16, 0, WALLS.rose - 55),
    new THREE.Vector3(-22, 0, 18),
    new THREE.Vector3(20, 0, -8),
  );

  raidAnchors.push(
    { name: "Shiganshina", x: 0, z: WALLS.maria - 55 },
    { name: "Trost", x: 0, z: WALLS.rose - 48 },
    { name: "Mitras", x: 0, z: 8 },
  );

  const torchPos = [
    [8, WALLS.maria - 8],
    [-8, WALLS.maria - 8],
    [8, WALLS.rose - 8],
    [-8, WALLS.rose - 8],
    [6, WALLS.sina - 8],
    [-6, WALLS.sina - 8],
    [0, WALLS.maria - 55],
    [0, WALLS.rose - 48],
  ];
  for (const [tx, tz] of torchPos) {
    const light = new THREE.PointLight(0xffb066, 0, 28, 2);
    light.position.set(tx, 4.5, tz);
    scene.add(light);
    torches.push(light);
  }

  return {
    hookables,
    grass,
    grassCount: grassN,
    sun,
    hemi,
    amb,
    moon,
    sky,
    skyMat,
    torches,
    supplies,
    horseSpawns,
    raidAnchors,
    signs,
    fog,
  };
}

export function scatterGrass(
  grass: THREE.InstancedMesh,
  count: number,
  cx: number,
  cz: number,
  radius: number,
) {
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * radius;
    const x = cx + Math.cos(a) * r;
    const z = cz + Math.sin(a) * r;
    const s = 0.7 + Math.random() * 1.1;
    _p.set(x, 0, z);
    _e.set(0, Math.random() * Math.PI, (Math.random() - 0.5) * 0.2);
    _q.setFromEuler(_e);
    _s.set(s, s, s);
    _m.compose(_p, _q, _s);
    grass.setMatrixAt(i, _m);
  }
  grass.instanceMatrix.needsUpdate = true;
}

function makeSign(text: string): THREE.Mesh {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 128;
  const ctx = c.getContext("2d")!;
  ctx.fillStyle = "#2a281f";
  ctx.fillRect(0, 0, 512, 128);
  ctx.strokeStyle = "#d8d0c0";
  ctx.lineWidth = 8;
  ctx.strokeRect(8, 8, 496, 112);
  ctx.fillStyle = "#ece8dc";
  ctx.font = "700 48px Cinzel, serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 256, 68);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  const mat = new THREE.MeshBasicMaterial({ map: t });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(22, 5.5), mat);
  return mesh;
}
