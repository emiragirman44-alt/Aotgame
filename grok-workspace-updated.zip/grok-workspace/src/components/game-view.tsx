import { useEffect, useRef, useState } from "react";
import {
  Heart,
  Shield,
  Swords,
  Wind,
  Zap,
  ChevronsUp,
  Volume2,
  Footprints,
  Package,
} from "lucide-react";
import { WALLS, TEAMS, type GameHandle, type HudState, type TeamId } from "@/game/types";

const EMPTY: HudState = {
  energy: 100,
  energyMax: 100,
  gas: 100,
  gasMax: 100,
  blades: 100,
  bladeMax: 100,
  kills: 0,
  gold: 40,
  level: 1,
  xp: 0,
  xpNext: 125,
  isTitan: false,
  isHardened: false,
  district: "Shiganshina  ·  Sur Maria",
  mode: "İnsan  ·  ODM",
  sprinting: false,
  hooked: false,
  mounted: false,
  nearHorse: false,
  nearSupply: false,
  isNight: false,
  clock: "Gündüz",
  px: 0,
  pz: WALLS.maria - 58,
  yaw: 0,
  titans: [],
  quest: { title: "Ense avı", desc: "Saf devlerin ensesini kes", progress: 0, target: 5, gold: 55 },
  raid: null,
  toast: "",
  squadAlive: 2,
  team: "scout",
  shop: [],
  titanUnlocked: false,
  titanPower: null,
  titanRarity: null,
  raidPity: 0,
};

export function GameView() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lightningRef = useRef<HTMLDivElement>(null);
  const impactRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameHandle | null>(null);
  const joyPtr = useRef<number | null>(null);
  const lookPtr = useRef<{ id: number; x: number; y: number } | null>(null);
  const [hud, setHud] = useState<HudState>(EMPTY);
  const [phase, setPhase] = useState<"menu" | "play">("menu");
  const [sprint, setSprint] = useState(false);
  const [team, setTeam] = useState<TeamId>("scout");
  const [shopOpen, setShopOpen] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    void import("@/game/engine").then(({ createGame }) => {
      if (cancelled || !canvasRef.current) return;
      const handle = createGame(canvas, setHud, {
        lightning: lightningRef.current,
        impact: impactRef.current,
      });
      if (cancelled) {
        handle.dispose();
        return;
      }
      gameRef.current = handle;
    });
    return () => {
      cancelled = true;
      gameRef.current?.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "KeyB" && phase === "play") {
        e.preventDefault();
        setShopOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase]);

  useEffect(() => {
    const c = mapRef.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const w = c.width;
    const h = c.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = hud.isNight ? "rgba(8,10,14,0.72)" : "rgba(12,13,11,0.55)";
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    const scale = (w / 2 - 8) / 500;
    const cx = w / 2;
    const cy = h / 2;
    ctx.strokeStyle = "rgba(236,232,220,0.45)";
    ctx.lineWidth = 1.2;
    for (const r of [WALLS.sina, WALLS.rose, WALLS.maria]) {
      ctx.beginPath();
      ctx.arc(cx, cy, r * scale, 0, Math.PI * 2);
      ctx.stroke();
    }
    hud.titans.forEach((t) => {
      ctx.fillStyle = t.kind === "armored" || t.kind === "female" || t.kind === "jaw" || t.kind === "beast" ? "#c4bba8" : "#9a3b32";
      ctx.beginPath();
      ctx.arc(cx + t.x * scale, cy + t.z * scale, t.kind === "huge" ? 3.2 : 2.2, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.fillStyle = "#ece8dc";
    const px = cx + hud.px * scale;
    const pz = cy + hud.pz * scale;
    ctx.beginPath();
    ctx.arc(px, pz, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ece8dc";
    ctx.beginPath();
    ctx.moveTo(px, pz);
    ctx.lineTo(px - Math.sin(hud.yaw) * 8, pz - Math.cos(hud.yaw) * 8);
    ctx.stroke();
  }, [hud.px, hud.pz, hud.yaw, hud.titans, hud.isNight]);

  const start = () => {
    gameRef.current?.setTeam(team);
    gameRef.current?.start();
    setPhase("play");
  };

  const onJoyDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    joyPtr.current = e.pointerId;
    steerJoy(e);
  };
  const onJoyMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPtr.current !== e.pointerId) return;
    steerJoy(e);
  };
  const onJoyUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (joyPtr.current !== e.pointerId) return;
    joyPtr.current = null;
    gameRef.current?.setJoystick(0, 0, false);
    const knob = e.currentTarget.querySelector(".joy-knob") as HTMLElement | null;
    if (knob) knob.style.transform = "translate(-50%, -50%)";
  };
  const steerJoy = (e: React.PointerEvent<HTMLDivElement>) => {
    const rec = e.currentTarget.getBoundingClientRect();
    const dx = e.clientX - (rec.left + rec.width / 2);
    const dy = e.clientY - (rec.top + rec.height / 2);
    const max = rec.width * 0.42;
    const mag = Math.hypot(dx, dy);
    const nx = mag > max ? (dx / mag) * max : dx;
    const ny = mag > max ? (dy / mag) * max : dy;
    const knob = e.currentTarget.querySelector(".joy-knob") as HTMLElement | null;
    if (knob) knob.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`;
    gameRef.current?.setJoystick(nx / max, -ny / max, true);
  };

  const onLookDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest(".act, .joy-base")) return;
    lookPtr.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onLookMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const p = lookPtr.current;
    if (!p || p.id !== e.pointerId) return;
    const dx = e.clientX - p.x;
    const dy = e.clientY - p.y;
    p.x = e.clientX;
    p.y = e.clientY;
    gameRef.current?.addLook(dx, dy);
  };
  const onLookUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (lookPtr.current?.id === e.pointerId) lookPtr.current = null;
  };

  const pulse = (a: Parameters<GameHandle["pulse"]>[0]) => () => gameRef.current?.pulse(a);
  const energyPct = (hud.energy / Math.max(1, hud.energyMax)) * 100;
  const gasPct = (hud.gas / Math.max(1, hud.gasMax)) * 100;
  const bladePct = (hud.blades / Math.max(1, hud.bladeMax)) * 100;
  const xpPct = (hud.xp / Math.max(1, hud.xpNext)) * 100;

  return (
    <div id="game-root" className={hud.isTitan ? "titan-on" : ""}>
      <canvas ref={canvasRef} className="game-canvas" />
      <div className="flash lightning" ref={lightningRef} />
      <div className="flash impact" ref={impactRef} />
      <div className="crosshair" />

      <div className="overlay">
        {phase === "play" && (
        <div className="hud-top">
          <div className="panel">
            <div className="status-kicker">
              {hud.clock} · {TEAMS[hud.team].name}
            </div>
            <div className="status-title">{hud.district}</div>
            <div className="status-meta">
              <span>
                Ense <b>{hud.kills}</b>
              </span>
              <span>
                Sv. <b>{hud.level}</b>
              </span>
              <span>
                Para <b>{hud.gold}</b>
              </span>
            </div>
            <div className="xp-track">
              <div className="xp-fill" style={{ width: `${xpPct}%` }} />
            </div>
          </div>
          <div className="panel bars">
            <div className="bar-row">
              <div className="bar-lab">
                <span>{hud.isTitan ? "Titan enerji" : "Dönüşüm"}</span>
                <span>{Math.round(hud.energy)}</span>
              </div>
              <div className="bar-track">
                <div className="bar-fill bar-energy" style={{ width: `${Math.max(0, energyPct)}%` }} />
              </div>
            </div>
            <div className="bar-row">
              <div className="bar-lab">
                <span>ODM gaz</span>
                <span>{Math.round(hud.gas)}</span>
              </div>
              <div className="bar-track">
                <div className="bar-fill bar-gas" style={{ width: `${Math.max(0, gasPct)}%` }} />
              </div>
            </div>
            <div className="bar-row">
              <div className="bar-lab">
                <span>Bıçak</span>
                <span>{Math.round(hud.blades)}</span>
              </div>
              <div className="bar-track">
                <div className="bar-fill bar-blade" style={{ width: `${Math.max(0, bladePct)}%` }} />
              </div>
            </div>
          </div>
        </div>
        )}

        {phase === "play" && (
        <div className="minimap-wrap">
          <canvas ref={mapRef} className="minimap" width={92} height={92} />
        </div>
        )}

        {phase === "play" && (
          <div className="titan-status">
            <div className="titan-status-kicker">Titan Gücü</div>
            <div className="titan-status-title">{hud.titanUnlocked ? hud.titanPower : "KİLİTLİ"}</div>
            <div className="titan-status-sub">{hud.titanUnlocked ? `${hud.titanRarity ?? "RARE"} · Raid ödülü` : `Raid Pity ${hud.raidPity}/10`}</div>
          </div>
        )}

        {hud.quest && phase === "play" && (
          <div className="quest-card">
            <div className="quest-kicker">Görev · +{hud.quest.gold} para</div>
            <div className="quest-title">{hud.quest.title}</div>
            <div className="quest-desc">{hud.quest.desc}</div>
            <div className="bar-track quest-bar">
              <div
                className="bar-fill bar-quest"
                style={{ width: `${(hud.quest.progress / Math.max(1, hud.quest.target)) * 100}%` }}
              />
            </div>
            <div className="quest-count">
              {hud.quest.progress}/{hud.quest.target}
            </div>
          </div>
        )}

        {hud.raid && phase === "play" && (
          <div className="raid-banner">
            Titan saldırısı · {hud.raid.name} · {Math.ceil(hud.raid.left)}s
          </div>
        )}

        {hud.toast && phase === "play" && <div className="toast">{hud.toast}</div>}

        {phase === "play" && (
          <div className="hint desk-only">
            WASD · Q kanca · F kes · E dönüşüm · G at · H ikmal · B dükkân · R kükre
          </div>
        )}
      </div>

      {phase === "play" && (
        <button className="shop-fab hit" type="button" onClick={() => setShopOpen(true)}>
          Dükkân
        </button>
      )}

      {shopOpen && (
        <div className="shop-scrim" onClick={() => setShopOpen(false)}>
          <div className="shop-card" onClick={(e) => e.stopPropagation()}>
            <div className="menu-kicker">Gelişim · {hud.gold} para</div>
            <h2 className="shop-title">Ekipman</h2>
            <ul className="shop-list">
              {hud.shop.map((item) => (
                <li key={item.id}>
                  <div>
                    <div className="shop-name">{item.name}</div>
                    <div className="shop-desc">
                      {item.desc} · {item.owned}/{item.cap}
                    </div>
                  </div>
                  <button
                    type="button"
                    className="shop-buy"
                    disabled={item.owned >= item.cap || hud.gold < item.cost}
                    onClick={() => gameRef.current?.buy(item.id)}
                  >
                    {item.cost}
                  </button>
                </li>
              ))}
            </ul>
            <button type="button" className="menu-btn shop-close" onClick={() => setShopOpen(false)}>
              Kapat
            </button>
          </div>
        </div>
      )}

      {phase === "play" && (
        <div
          className="touch-layer"
          onPointerDown={onLookDown}
          onPointerMove={onLookMove}
          onPointerUp={onLookUp}
          onPointerCancel={onLookUp}
        >
          <div
            className="joy-base"
            onPointerDown={onJoyDown}
            onPointerMove={onJoyMove}
            onPointerUp={onJoyUp}
            onPointerCancel={onJoyUp}
          >
            <div className="joy-knob" />
          </div>
          <button
            className={`act act-sprint ${sprint ? "on" : ""}`}
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              const next = !sprint;
              setSprint(next);
              gameRef.current?.setSprintToggle(next);
            }}
          >
            <ChevronsUp />
            Koş
          </button>
          <button className="act act-transform swapped" type="button" onPointerDown={pulse("transform")}>
            <Zap />
            Devi
          </button>
          <button className="act act-hook" type="button" onPointerDown={pulse("hook")}>
            <Wind />
            ODM
          </button>
          <button className="act act-attack swapped" type="button" onPointerDown={pulse("attack")}>
            <Swords />
            Kes
          </button>
          <button className="act act-heal" type="button" onPointerDown={pulse("heal")}>
            <Heart />
            İkmal
          </button>
          <button className="act act-mount" type="button" onPointerDown={pulse("mount")}>
            <Footprints />
            At
          </button>
          <button className="act act-shop" type="button" onPointerDown={() => setShopOpen(true)}>
            <Package />
            Al
          </button>
          <button className="act act-roar hidden-titan" type="button" onPointerDown={pulse("roar")}>
            <Volume2 />
            Kükre
          </button>
          <button className="act act-harden hidden-titan" type="button" onPointerDown={pulse("harden")}>
            <Shield />
            Sertleş
          </button>
        </div>
      )}

      {phase === "menu" && (
        <div className="menu">
          <div className="menu-card">
            <div className="menu-kicker">Sur Maria · Sur Rose · Sur Sina</div>
            <h1 className="menu-title">Saldırı Devi</h1>
            <p className="menu-sub">
              ODM ile uç, bıçak dayanıklılığını yönet, ata bin, şehri savun. Yıldırımla Saldırı Devi’ne dönüş;
              Zırhlı, Dişi, Çene ve Canavar Titan onları bekliyor.
            </p>
            <div className="team-pick">
              {(Object.keys(TEAMS) as TeamId[]).map((id) => (
                <button
                  key={id}
                  type="button"
                  className={`team-btn ${team === id ? "on" : ""}`}
                  onClick={() => {
                    setTeam(id);
                    gameRef.current?.setTeam(id);
                  }}
                >
                  <span>{TEAMS[id].name}</span>
                  <small>{TEAMS[id].bonus}</small>
                </button>
              ))}
            </div>
            <button className="menu-btn" type="button" onClick={start}>
              Göreve başla
            </button>
            <div className="menu-keys">
              WASD hareket · Q kanca · F kes · E dönüşüm · G at
              <br />
              H ikmal · R kükre · X sertleş · Shift koş
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
